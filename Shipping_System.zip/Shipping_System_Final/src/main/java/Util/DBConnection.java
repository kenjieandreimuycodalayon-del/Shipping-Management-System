package Util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Central place to obtain a JDBC connection to the MySQL database.
 * Requires the MySQL Connector/J jar (mysql-connector-j) on the classpath.
 */
public final class DBConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/lodestar_shipping?useSSL=false&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    private DBConnection() {
    }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL JDBC driver not found on the classpath. "
                    + "Add mysql-connector-j to the project's libraries.", e);
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
