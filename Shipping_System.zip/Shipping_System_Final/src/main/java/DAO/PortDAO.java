package DAO;

import Model.Port;
import Util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PortDAO {

    public int insert(Connection conn, Port p) throws SQLException {
        String sql = "INSERT INTO ports (port_name, registered_name, primary_capability, status, "
                + "dispatch_limit, cargo_item_limit, permit_authority, permit_no, submitted_date, "
                + "approved_date, expiration_date, last_renewal) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, p);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    p.setId(keys.getInt(1));
                    return p.getId();
                }
            }
        }
        return -1;
    }

    public void update(Port p) throws SQLException {
        String sql = "UPDATE ports SET port_name=?, registered_name=?, primary_capability=?, status=?, "
                + "dispatch_limit=?, cargo_item_limit=?, permit_authority=?, permit_no=?, submitted_date=?, "
                + "approved_date=?, expiration_date=?, last_renewal=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, p);
            ps.setInt(13, p.getId());
            ps.executeUpdate();
        }
    }

    /**
     * Called once, right after insert(), with the code generated from the real
     * id.
     */
    public void updatePortCode(Connection conn, int portId, String portCode) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("UPDATE ports SET port_code=? WHERE id=?")) {
            ps.setString(1, portCode);
            ps.setInt(2, portId);
            ps.executeUpdate();
        }
    }

    public void updatePermitNo(Connection conn, int portId, String permitNo) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("UPDATE ports SET permit_no=? WHERE id=?")) {
            ps.setString(1, permitNo);
            ps.setInt(2, portId);
            ps.executeUpdate();
        }
    }

    public void updateStatus(Connection conn, int portId, Port.Status status) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("UPDATE ports SET status=? WHERE id=?")) {
            ps.setString(1, status.name());
            ps.setInt(2, portId);
            ps.executeUpdate();
        }
    }

    public void updateStatus(int portId, Port.Status status) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            updateStatus(conn, portId, status);
        }
    }

    public void markApproved(Connection conn, int portId, int permitApplicationId, LocalDate approvedDate)
            throws SQLException {
        String sql = "UPDATE ports SET status='ACTIVE', approved_date=?, "
                + "permit_no=(SELECT permit_no FROM permit_applications WHERE id=?) WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, Date.valueOf(approvedDate));
            ps.setInt(2, permitApplicationId);
            ps.setInt(3, portId);
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM ports WHERE id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public Port findById(int id) throws SQLException {
        String sql = "SELECT * FROM ports WHERE id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public List<Port> findAll() throws SQLException {
        return findByStatus(null);
    }

    /**
     * Pass null to return every port regardless of status.
     */
    public List<Port> findByStatus(Port.Status status) throws SQLException {
        String sql = "SELECT * FROM ports" + (status != null ? " WHERE status=?" : "") + " ORDER BY port_name";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            if (status != null) {
                ps.setString(1, status.name());
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Port> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }

    public List<Port> search(String keyword) throws SQLException {
        String sql = "SELECT * FROM ports WHERE port_name LIKE ? OR registered_name LIKE ? OR port_code LIKE ? "
                + "ORDER BY port_name";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + keyword + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            try (ResultSet rs = ps.executeQuery()) {
                List<Port> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }

    private void bind(PreparedStatement ps, Port p) throws SQLException {
        ps.setString(1, p.getPortName());
        ps.setString(2, p.getRegisteredName());
        ps.setString(3, p.getPrimaryCapability());
        ps.setString(4, p.getStatus() != null ? p.getStatus().name() : Port.Status.PENDING.name());
        ps.setInt(5, p.getDispatchLimit());
        ps.setInt(6, p.getCargoItemLimit());
        ps.setString(7, p.getPermitAuthority());
        ps.setString(8, p.getPermitNo());
        ps.setDate(9, toSqlDate(p.getSubmittedDate()));
        ps.setDate(10, toSqlDate(p.getApprovedDate()));
        ps.setDate(11, toSqlDate(p.getExpirationDate()));
        ps.setDate(12, toSqlDate(p.getLastRenewal()));
    }

    private Port map(ResultSet rs) throws SQLException {
        Port p = new Port();
        p.setId(rs.getInt("id"));
        p.setPortCode(rs.getString("port_code"));
        p.setPortName(rs.getString("port_name"));
        p.setRegisteredName(rs.getString("registered_name"));
        p.setPrimaryCapability(rs.getString("primary_capability"));
        p.setStatus(Port.Status.valueOf(rs.getString("status")));
        p.setDispatchLimit(rs.getInt("dispatch_limit"));
        p.setCargoItemLimit(rs.getInt("cargo_item_limit"));
        p.setPermitAuthority(rs.getString("permit_authority"));
        p.setPermitNo(rs.getString("permit_no"));
        p.setSubmittedDate(toLocalDate(rs.getDate("submitted_date")));
        p.setApprovedDate(toLocalDate(rs.getDate("approved_date")));
        p.setExpirationDate(toLocalDate(rs.getDate("expiration_date")));
        p.setLastRenewal(toLocalDate(rs.getDate("last_renewal")));
        return p;
    }

    private Date toSqlDate(LocalDate d) {
        return d != null ? Date.valueOf(d) : null;
    }

    private LocalDate toLocalDate(Date d) {
        return d != null ? d.toLocalDate() : null;
    }
}
