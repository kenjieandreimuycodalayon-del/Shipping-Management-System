/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import Model.Cargo;
import Model.Port;
import Model.Vessel;
import Service.CargoService;
import Service.PortService;
import Service.VesselService;
import UI.TemplateUI;
import Util.Session;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Frame;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Kenji
 */
public class PortArchive extends javax.swing.JPanel {

    private final CargoService cargoService = new CargoService();
    private final PortService portService = new PortService();
    private final VesselService vesselService = new VesselService();

    // parallel to the table rows so a selection maps back to a Cargo
    private List<Cargo> currentCargo = new ArrayList<>();

    /**
     * Creates new form Archive
     */
    public PortArchive() {
        initComponents();
        
        applyModernStyle();

        // archived cargo can also be RETURNED; labels keep the project's "Recieved" spelling
        comboStat.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"All", "Recieved", "Returned", "Cancelled"}));
        archTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        archTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    insMan.doClick();
                }
            }
        });
        comboStat.addActionListener(e -> loadArchive());

        // Do NOT load in the constructor: PortPanel builds all its screens at app start,
        // before anyone has logged in, so Session.getPortId() would still be null.
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadArchive();
            }
        });
    }
    
    private void applyModernStyle() {
        TemplateUI.stylePage(jPanel2, jPanel3, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel5 (Port Permits)
        roundedPanel5.setBackground(UIManager.getColor("Table.background"));
        roundedPanel5.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");

        TemplateUI.styleTextField(portArchiveSearch, "Search...");
        TemplateUI.styleComboBox(comboStat);
        TemplateUI.styleButton(insMan, true);
        TemplateUI.styleButton(refArchive, true);
        TemplateUI.styleSection(jLabel1);
        jScrollPane1.setBorder(null);
        TemplateUI.styleTable(archTable, 5, 2);
    }

    private String codeOf(Port p, int portId) {
        if (p == null) {
            return "#" + portId;
        }
        return p.getPortCode() != null ? p.getPortCode() : "#" + p.getId();
    }

    private Cargo.Status comboToStatus(String label) {
        if (label == null || "All".equalsIgnoreCase(label)) {
            return null;
        }
        return "Recieved".equals(label) ? Cargo.Status.RECEIVED : Cargo.Status.valueOf(label.toUpperCase());
    }

    private void loadArchive() {
        Integer me = Session.getPortId();
        if (me == null) {
            return;
        }
        try {
            Map<Integer, Port> ports = new HashMap<>();
            for (Port p : portService.findAll()) {
                ports.put(p.getId(), p);
            }
            Map<Integer, Vessel> vessels = new HashMap<>();
            for (Vessel v : vesselService.findByStatus(null)) {
                vessels.put(v.getId(), v);
            }

            currentCargo = cargoService.archivedForPort(me,
                    comboToStatus((String) comboStat.getSelectedItem()),
                    portArchiveSearch.getText().trim());

            Object[][] data = new Object[currentCargo.size()][6];
            for (int i = 0; i < currentCargo.size(); i++) {
                Cargo c = currentCargo.get(i);
                Vessel v = c.getVesselId() != null ? vessels.get(c.getVesselId()) : null;
                data[i][0] = c.getCargoCode();
                data[i][1] = codeOf(ports.get(c.getOriginPortId()), c.getOriginPortId());
                data[i][2] = codeOf(ports.get(c.getDestinationPortId()), c.getDestinationPortId());
                data[i][3] = v != null ? v.getVesselName() : "—"; // cancelled cargo may never have had a vessel
                data[i][4] = c.getDateEnded();
                data[i][5] = c.getStatus();
            }
            archTable.setModel(new DefaultTableModel(data,
                    new String[]{"Cargo ID", "Origin Port", "Destination Port", "Assigned Vessel", "Date Ended", "Status"}) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            });
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load archive: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        roundedPanel4 = new JSwing.RoundedPanel();
        jLabel7 = new javax.swing.JLabel();
        portArchiveSearch = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        comboStat = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        roundedPanel5 = new JSwing.RoundedPanel();
        insMan = new javax.swing.JButton();
        refArchive = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        archTable = new javax.swing.JTable();

        setLayout(new java.awt.BorderLayout());

        jPanel2.setMaximumSize(new java.awt.Dimension(1060, 650));
        jPanel2.setMinimumSize(new java.awt.Dimension(1060, 650));
        jPanel2.setPreferredSize(new java.awt.Dimension(1060, 650));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Historical Logistics Archives");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        roundedPanel4.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel4.setMaximumSize(new java.awt.Dimension(323, 75));
        roundedPanel4.setMinimumSize(new java.awt.Dimension(323, 75));

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Search:");

        portArchiveSearch.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        portArchiveSearch.addActionListener(this::portArchiveSearchActionPerformed);

        jLabel8.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("Status");

        comboStat.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        comboStat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Recieved", "Cancelled" }));

        javax.swing.GroupLayout roundedPanel4Layout = new javax.swing.GroupLayout(roundedPanel4);
        roundedPanel4.setLayout(roundedPanel4Layout);
        roundedPanel4Layout.setHorizontalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(portArchiveSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboStat, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(357, Short.MAX_VALUE))
        );
        roundedPanel4Layout.setVerticalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(portArchiveSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(comboStat, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jLabel6.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Search & Filter");

        jLabel10.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("Actions");

        roundedPanel5.setBackground(new java.awt.Color(255, 255, 255));

        insMan.setBackground(new java.awt.Color(0, 0, 102));
        insMan.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        insMan.setForeground(new java.awt.Color(255, 255, 255));
        insMan.setText("                 Inspect Manifest");
        insMan.setBorder(null);
        insMan.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        insMan.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        insMan.addActionListener(this::insManActionPerformed);

        refArchive.setBackground(new java.awt.Color(0, 0, 102));
        refArchive.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        refArchive.setForeground(new java.awt.Color(255, 255, 255));
        refArchive.setText("                  Refresh Archive");
        refArchive.setBorder(null);
        refArchive.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        refArchive.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        refArchive.addActionListener(this::refArchiveActionPerformed);

        javax.swing.GroupLayout roundedPanel5Layout = new javax.swing.GroupLayout(roundedPanel5);
        roundedPanel5.setLayout(roundedPanel5Layout);
        roundedPanel5Layout.setHorizontalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(insMan, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(refArchive, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel5Layout.setVerticalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(insMan, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(refArchive, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        jLabel11.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 102));
        jLabel11.setText("Cargo Inventory");

        archTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Cargo ID", "Origin Port", "Destination Port", "Assigned Vessel", "Date Ended", "Status"
            }
        ));
        jScrollPane1.setViewportView(archTable);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1)
                            .addComponent(roundedPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(roundedPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(50, 50, 50))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 41, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1060, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel1Layout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void portArchiveSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_portArchiveSearchActionPerformed
        loadArchive();
    }//GEN-LAST:event_portArchiveSearchActionPerformed

    private void refArchiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refArchiveActionPerformed
        loadArchive();
    }//GEN-LAST:event_refArchiveActionPerformed

    private void insManActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insManActionPerformed
        int row = archTable.getSelectedRow();
        if (row < 0 || row >= currentCargo.size()) {
            JOptionPane.showMessageDialog(this, "Select a cargo row first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        InspectManifestDialog dialog = new InspectManifestDialog(
                (Frame) SwingUtilities.getWindowAncestor(this), currentCargo.get(row).getId());
        dialog.setVisible(true);
    }//GEN-LAST:event_insManActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable archTable;
    private javax.swing.JComboBox<String> comboStat;
    private javax.swing.JButton insMan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField portArchiveSearch;
    private javax.swing.JButton refArchive;
    private JSwing.RoundedPanel roundedPanel4;
    private JSwing.RoundedPanel roundedPanel5;
    // End of variables declaration//GEN-END:variables
}
