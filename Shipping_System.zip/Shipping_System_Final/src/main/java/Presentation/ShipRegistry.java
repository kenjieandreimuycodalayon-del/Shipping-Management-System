/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import Model.Vessel;
import Service.VesselService;
import UI.TemplateUI;
import Util.Session;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Frame;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class ShipRegistry extends javax.swing.JPanel {

    private final VesselService vesselService = new VesselService();
    /** true while the Carrier combo is being rebuilt, so its events don't trigger a reload */
    private boolean loading = false;

    /**
     * Creates new form ShipRegistry
     */
    public ShipRegistry() {
        initComponents();
        applyModernStyle();

        // the generated combos were copied from Cargo Operations; vessels have their own statuses
        shipRegistryStat.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"All", "Pending", "Approved", "Rejected", "Active", "Inactive"}));
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]{"All"}));

        regShip.addActionListener(e -> onRegisterShip());
        refFleet.addActionListener(e -> loadFleet());
        shipRegistryStat.addActionListener(e -> loadFleet());
        jComboBox1.addActionListener(e -> loadFleet());

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadFleet();
            }
        });
    }
    
    private void applyModernStyle() {
        TemplateUI.stylePage(jPanel1, jPanel2, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel5 (Port Permits)
        roundedPanel5.setBackground(UIManager.getColor("Table.background"));
        roundedPanel5.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");
        roundedPanel4.setBackground(UIManager.getColor("Table.background"));
        roundedPanel4.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");
        
        TemplateUI.styleTextField(shipRegistrySearch, "Search...");
        TemplateUI.styleComboBox(jComboBox1);
        TemplateUI.styleComboBox(shipRegistryStat);
        
        TemplateUI.styleButton(regShip, true);
        TemplateUI.styleButton(refFleet, true);

        
        TemplateUI.styleSection(jLabel1);
        jScrollPane1.setBorder(null);
        TemplateUI.styleTable(fleetTable, 4, 2);
        
    }

    private void onRegisterShip() {
        RequestShipRegistrationDialog dialog
                = new RequestShipRegistrationDialog((Frame) SwingUtilities.getWindowAncestor(this));
        dialog.setVisible(true);
        if (dialog.isSucceeded()) {
            loadFleet();
        }
    }

    private void loadFleet() {
        if (loading) {
            return;
        }
        Integer me = Session.getPortId();
        if (me == null) {
            return;
        }
        try {
            // Carrier combo: the carrier lines found in THIS port's fleet
            Set<String> carriers = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            for (Vessel v : vesselService.findForPort(me, null, null)) {
                if (v.getCarrierLine() != null && !v.getCarrierLine().isBlank()) {
                    carriers.add(v.getCarrierLine());
                }
            }
            String previous = (String) jComboBox1.getSelectedItem();
            loading = true;
            try {
                jComboBox1.removeAllItems();
                jComboBox1.addItem("All");
                for (String c : carriers) {
                    jComboBox1.addItem(c);
                }
                jComboBox1.setSelectedItem(previous != null ? previous : "All");
            } finally {
                loading = false;
            }

            String keyword = shipRegistrySearch.getText().trim();
            List<Vessel> vessels = vesselService.findForPort(me,
                    statusToEnum((String) shipRegistryStat.getSelectedItem()), keyword);
            final String carrier = (String) jComboBox1.getSelectedItem();
            if (carrier != null && !"All".equalsIgnoreCase(carrier)) {
                vessels.removeIf(v -> !carrier.equalsIgnoreCase(v.getCarrierLine()));
            }

            Object[][] data = new Object[vessels.size()][6];
            for (int i = 0; i < vessels.size(); i++) {
                Vessel v = vessels.get(i);
                data[i][0] = v.getImoNumber();
                data[i][1] = v.getVesselName();
                data[i][2] = v.getCarrierLine();
                data[i][3] = v.getMaxCapacityTons();
                data[i][4] = v.getStatus();
                data[i][5] = v.getAdminRemarks() != null && !v.getAdminRemarks().isBlank() ? v.getAdminRemarks() : "\u2014";
            }
            fleetTable.setModel(new DefaultTableModel(data,
                    new String[]{"IMO Number", "Vessel Name", "Carrier / Line", "Max Cap (Tons)", "Status", "Admin Remarks"}) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            });
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load fleet: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private Vessel.Status statusToEnum(String label) {
        if (label == null || "All".equalsIgnoreCase(label)) {
            return null;
        }
        try {
            return Vessel.Status.valueOf(label.toUpperCase());
        } catch (IllegalArgumentException ex) {
            return null;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        roundedPanel5 = new JSwing.RoundedPanel();
        regShip = new javax.swing.JButton();
        refFleet = new javax.swing.JButton();
        roundedPanel4 = new JSwing.RoundedPanel();
        jLabel7 = new javax.swing.JLabel();
        shipRegistrySearch = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        shipRegistryStat = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        fleetTable = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(1060, 650));
        setMinimumSize(new java.awt.Dimension(1060, 650));
        setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Fleet Registry & Ship Management");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1)
                .addContainerGap(586, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        roundedPanel5.setBackground(new java.awt.Color(255, 255, 255));

        regShip.setBackground(new java.awt.Color(0, 0, 102));
        regShip.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        regShip.setForeground(new java.awt.Color(255, 255, 255));
        regShip.setText("        Request Ship Registration");
        regShip.setBorder(null);
        regShip.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        regShip.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        regShip.addActionListener(this::regShipActionPerformed);

        refFleet.setBackground(new java.awt.Color(0, 0, 102));
        refFleet.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        refFleet.setForeground(new java.awt.Color(255, 255, 255));
        refFleet.setText("                  Refresh Fleet");
        refFleet.setBorder(null);
        refFleet.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        refFleet.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        refFleet.addActionListener(this::refFleetActionPerformed);

        javax.swing.GroupLayout roundedPanel5Layout = new javax.swing.GroupLayout(roundedPanel5);
        roundedPanel5.setLayout(roundedPanel5Layout);
        roundedPanel5Layout.setHorizontalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(regShip, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(refFleet, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel5Layout.setVerticalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(regShip, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(refFleet, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        roundedPanel4.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel4.setMaximumSize(new java.awt.Dimension(323, 75));
        roundedPanel4.setMinimumSize(new java.awt.Dimension(323, 75));

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Search:");

        shipRegistrySearch.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        shipRegistrySearch.addActionListener(this::shipRegistrySearchActionPerformed);

        jLabel8.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("Carrier:");

        jComboBox1.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Inbound", "Outbound" }));
        jComboBox1.addActionListener(this::jComboBox1ActionPerformed);

        shipRegistryStat.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        shipRegistryStat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Prepared", "Dispatched", "Recieved", "Returned" }));
        shipRegistryStat.addActionListener(this::shipRegistryStatActionPerformed);

        jLabel9.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("Status:");

        javax.swing.GroupLayout roundedPanel4Layout = new javax.swing.GroupLayout(roundedPanel4);
        roundedPanel4.setLayout(roundedPanel4Layout);
        roundedPanel4Layout.setHorizontalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(shipRegistrySearch, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(95, 95, 95)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(shipRegistryStat, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(54, Short.MAX_VALUE))
        );
        roundedPanel4Layout.setVerticalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(shipRegistrySearch, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(shipRegistryStat, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jLabel5.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("Search & Filter");

        jLabel6.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Actions");

        fleetTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "IMO Number", "Vessel Name", "Carrier / Line", "Max Cap (Tons)", "Status"
            }
        ));
        jScrollPane1.setViewportView(fleetTable);

        jLabel10.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("Fleet Table");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(roundedPanel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(roundedPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(50, 50, 50))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void shipRegistrySearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shipRegistrySearchActionPerformed
         loadFleet();
    }//GEN-LAST:event_shipRegistrySearchActionPerformed

    private void regShipActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regShipActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regShipActionPerformed

    private void refFleetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refFleetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_refFleetActionPerformed

    private void jComboBox1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox1ActionPerformed

    private void shipRegistryStatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shipRegistryStatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_shipRegistryStatActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable fleetTable;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton refFleet;
    private javax.swing.JButton regShip;
    private JSwing.RoundedPanel roundedPanel4;
    private JSwing.RoundedPanel roundedPanel5;
    private javax.swing.JTextField shipRegistrySearch;
    private javax.swing.JComboBox<String> shipRegistryStat;
    // End of variables declaration//GEN-END:variables
}
