package Model;

/**
 * One entry in the "To" dropdown. userId == BROADCAST means "all active ports"
 * (admin only).
 */
public class MessageContact {

    public static final int BROADCAST = -1;

    private final int userId;
    private final String label;
    private final User.Role role;

    public MessageContact(int userId, String label, User.Role role) {
        this.userId = userId;
        this.label = label;
        this.role = role;
    }

    public int getUserId() {
        return userId;
    }

    public User.Role getRole() {
        return role;
    }

    @Override
    public String toString() {
        return label;
    }
}
