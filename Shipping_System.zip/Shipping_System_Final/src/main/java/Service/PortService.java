package Service;

import DAO.PermitApplicationDAO;
import DAO.PortDAO;
import Model.PermitApplication;
import Model.PermitReview;
import Model.Port;
import Util.DBConnection;
import Util.IdGenerator;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class PortService {

    private final PortDAO portDAO = new PortDAO();
    private final PermitApplicationDAO permitDAO = new PermitApplicationDAO();

    /**
     * Port Management -> "Add Port". Port + first permit application in one
     * transaction. NOTE: this still creates no login; see PATCH_NOTES.md.
     */
    public int registerPort(Port port) throws SQLException {
        if (port.getDispatchLimit() < 0 || port.getCargoItemLimit() < 0) {
            throw new IllegalStateException("Limits cannot be negative.");
        }
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                port.setStatus(Port.Status.PENDING);
                port.setSubmittedDate(LocalDate.now());
                int portId = portDAO.insert(conn, port);
                if (portId < 0) {
                    throw new SQLException("Port insert returned no id.");
                }
                String portCode = IdGenerator.portCode(port.getPortName(), portId);
                port.setPortCode(portCode);
                portDAO.updatePortCode(conn, portId, portCode);

                PermitApplication application = new PermitApplication();
                application.setPortId(portId);
                application.setDateSubmitted(LocalDate.now());
                application.setStatus(PermitApplication.Status.PENDING);
                int permitId = permitDAO.insert(conn, application);
                if (permitId < 0) {
                    throw new SQLException("Permit insert returned no id.");
                }
                String permitNo = IdGenerator.permitNo(permitId);
                application.setPermitNo(permitNo);
                permitDAO.updatePermitNo(conn, permitId, permitNo);
                portDAO.updatePermitNo(conn, portId, permitNo);
                port.setPermitNo(permitNo);

                conn.commit();
                return portId;
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            }
        }
    }

    public List<PermitReview> pendingPermitReviews() throws SQLException {
        return permitDAO.findReviewsByStatus(PermitApplication.Status.PENDING);
    }

    public byte[] permitDocument(int permitId) throws SQLException {
        return permitDAO.findDocument(permitId);
    }

    /** Permit -> APPROVED and port -> ACTIVE (+ approved_date, permit_no) atomically. */
    public void approvePermit(int permitApplicationId, int portId, String remarks) throws SQLException {
        LocalDate today = LocalDate.now();
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                permitDAO.updateStatus(conn, permitApplicationId, PermitApplication.Status.APPROVED, today, remarks);
                portDAO.markApproved(conn, portId, permitApplicationId, today);
                conn.commit();
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            }
        }
    }

    public void rejectPermit(int permitApplicationId, int portId, String remarks) throws SQLException {
        LocalDate today = LocalDate.now();
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                permitDAO.updateStatus(conn, permitApplicationId, PermitApplication.Status.REJECTED, today, remarks);
                portDAO.updateStatus(conn, portId, Port.Status.SUSPENDED);
                conn.commit();
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            }
        }
    }

    /** Port Management -> "Suspend Permit". Only ACTIVE ports can be suspended. */
    public void revokePermit(int portId) throws SQLException {
        Port port = portDAO.findById(portId);
        if (port == null || port.getStatus() != Port.Status.ACTIVE) {
            throw new IllegalStateException("Only ACTIVE ports can be suspended.");
        }
        portDAO.updateStatus(portId, Port.Status.SUSPENDED);
    }

    /**
     * Port Management -> "Validate Permit": SUSPENDED -> ACTIVE again.
     * A port whose permit is still waiting for review is approved in Pending
     * Approvals instead, and a port whose latest permit was rejected (or has
     * expired) cannot be switched back on from here.
     */
    public void validatePermit(int portId) throws SQLException {
        Port port = portDAO.findById(portId);
        if (port == null) {
            throw new IllegalStateException("Port not found.");
        }
        if (port.getStatus() != Port.Status.SUSPENDED) {
            throw new IllegalStateException("Only SUSPENDED ports can be validated.\n"
                    + "New ports are approved in Pending Approvals.");
        }
        List<PermitApplication> history = permitDAO.findByPortId(portId); // newest first
        if (!history.isEmpty()) {
            switch (history.get(0).getStatus()) {
                case PENDING:
                    throw new IllegalStateException(
                            "This port's permit is still waiting for review.\nApprove it in Pending Approvals.");
                case REJECTED:
                    throw new IllegalStateException(
                            "This port's latest permit was rejected, so it cannot be reactivated here.");
                default:
                    break;
            }
        }
        if (port.getExpirationDate() != null && port.getExpirationDate().isBefore(LocalDate.now())) {
            throw new IllegalStateException("This port's permit expired on " + port.getExpirationDate() + ".");
        }
        portDAO.updateStatus(portId, Port.Status.ACTIVE);
    }

    public List<PermitApplication> pendingPermitApplications() throws SQLException {
        return permitDAO.findByStatus(PermitApplication.Status.PENDING);
    }

    public List<PermitApplication> permitHistory(int portId) throws SQLException {
        return permitDAO.findByPortId(portId);
    }

    public Port findById(int id) throws SQLException {
        return portDAO.findById(id);
    }

    public List<Port> findAll() throws SQLException {
        return portDAO.findAll();
    }

    public List<Port> findByStatus(Port.Status status) throws SQLException {
        return portDAO.findByStatus(status);
    }

    public List<Port> search(String keyword) throws SQLException {
        return (keyword == null || keyword.isBlank()) ? portDAO.findAll() : portDAO.search(keyword);
    }

    public void updateProfile(Port port) throws SQLException {
        portDAO.update(port);
    }
}