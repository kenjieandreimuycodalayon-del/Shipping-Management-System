package Model;

public class Vessel {

    public enum Status { PENDING, APPROVED, REJECTED, ACTIVE, INACTIVE }

    private int id;
    private String imoNumber;
    private String vesselName;
    private String carrierLine;
    private double maxCapacityTons;
    private Status status;
    private String requestedBy;
    private Integer portId;
    private String documentName;
    private byte[] documentData;
    private boolean hasDocument;
    private String adminRemarks;

    public Vessel() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getImoNumber() { return imoNumber; }
    public void setImoNumber(String imoNumber) { this.imoNumber = imoNumber; }

    public String getVesselName() { return vesselName; }
    public void setVesselName(String vesselName) { this.vesselName = vesselName; }

    public String getCarrierLine() { return carrierLine; }
    public void setCarrierLine(String carrierLine) { this.carrierLine = carrierLine; }

    public double getMaxCapacityTons() { return maxCapacityTons; }
    public void setMaxCapacityTons(double maxCapacityTons) { this.maxCapacityTons = maxCapacityTons; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public String getRequestedBy() { return requestedBy; }
    public void setRequestedBy(String requestedBy) { this.requestedBy = requestedBy; }

    public Integer getPortId() { return portId; }
    public void setPortId(Integer portId) { this.portId = portId; }
    
    public String getDocumentName() { return documentName; }
    public void setDocumentName(String documentName) { this.documentName = documentName; }

    public byte[] getDocumentData() { return documentData; }
    public void setDocumentData(byte[] documentData) { this.documentData = documentData; }

    public boolean isHasDocument() { return hasDocument; }
    public void setHasDocument(boolean hasDocument) { this.hasDocument = hasDocument; }
    
    public String getAdminRemarks() { return adminRemarks; }
    public void setAdminRemarks(String adminRemarks) { this.adminRemarks = adminRemarks; }

    @Override
    public String toString() {
        return vesselName + " (" + imoNumber + ")";
    }
}
