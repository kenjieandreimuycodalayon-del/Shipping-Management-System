package DAO;

import Model.Vessel;
import Util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VesselDAO {

    /** Everything except the document blob; has_document says whether one was uploaded. */
    private static final String COLUMNS = "id, imo_number, vessel_name, carrier_line, max_capacity_tons, status, "
            + "requested_by, port_id, document_name, (document_data IS NOT NULL) AS has_document, admin_remarks";

    public int insert(Vessel v) throws SQLException {
        String sql = "INSERT INTO vessels (imo_number, vessel_name, carrier_line, max_capacity_tons, status, "
                + "requested_by, port_id, document_name, document_data) VALUES (?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, v);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    v.setId(keys.getInt(1));
                    return v.getId();
                }
            }
        }
        return -1;
    }

    public void updateStatus(int id, Vessel.Status status) throws SQLException {
        String sql = "UPDATE vessels SET status=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status.name());
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    /** Admin decision on a vessel request: new status + the admin's remarks (null = none). */
    public void updateStatus(int id, Vessel.Status status, String remarks) throws SQLException {
        String sql = "UPDATE vessels SET status=?, admin_remarks=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status.name());
            ps.setString(2, remarks);
            ps.setInt(3, id);
            ps.executeUpdate();
        }
    }

    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM vessels WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public Vessel findById(int id) throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM vessels WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** Loaded on demand, only when the admin opens a vessel request. */
    public byte[] findDocument(int vesselId) throws SQLException {
        String sql = "SELECT document_data FROM vessels WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, vesselId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getBytes(1) : null;
            }
        }
    }

    public List<Vessel> findByStatus(Vessel.Status status) throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM vessels" + (status != null ? " WHERE status=?" : "")
                + " ORDER BY vessel_name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            if (status != null) {
                ps.setString(1, status.name());
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Vessel> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }

    /** Vessels owned by ONE port. Pass null for status / keyword to skip that filter. */
    public List<Vessel> findByPort(int portId, Vessel.Status status, String keyword) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT " + COLUMNS + " FROM vessels WHERE port_id=?");
        List<Object> params = new ArrayList<>();
        params.add(portId);
        if (status != null) {
            sql.append(" AND status=?");
            params.add(status.name());
        }
        if (keyword != null && !keyword.isBlank()) {
            sql.append(" AND (vessel_name LIKE ? OR imo_number LIKE ? OR carrier_line LIKE ?)");
            String like = "%" + keyword + "%";
            params.add(like);
            params.add(like);
            params.add(like);
        }
        sql.append(" ORDER BY vessel_name");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Vessel> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }

    public List<Vessel> search(String keyword) throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM vessels WHERE vessel_name LIKE ? OR imo_number LIKE ? "
                + "OR carrier_line LIKE ? ORDER BY vessel_name";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            String like = "%" + keyword + "%";
            ps.setString(1, like);
            ps.setString(2, like);
            ps.setString(3, like);
            try (ResultSet rs = ps.executeQuery()) {
                List<Vessel> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }

    private void bind(PreparedStatement ps, Vessel v) throws SQLException {
        ps.setString(1, v.getImoNumber());
        ps.setString(2, v.getVesselName());
        ps.setString(3, v.getCarrierLine());
        ps.setDouble(4, v.getMaxCapacityTons());
        ps.setString(5, v.getStatus() != null ? v.getStatus().name() : Vessel.Status.PENDING.name());
        ps.setString(6, v.getRequestedBy());
        if (v.getPortId() != null) {
            ps.setInt(7, v.getPortId());
        } else {
            ps.setNull(7, Types.INTEGER);
        }
        ps.setString(8, v.getDocumentName());
        if (v.getDocumentData() != null) {
            ps.setBytes(9, v.getDocumentData());
        } else {
            ps.setNull(9, Types.LONGVARBINARY);
        }
    }

    private Vessel map(ResultSet rs) throws SQLException {
        Vessel v = new Vessel();
        v.setId(rs.getInt("id"));
        v.setImoNumber(rs.getString("imo_number"));
        v.setVesselName(rs.getString("vessel_name"));
        v.setCarrierLine(rs.getString("carrier_line"));
        v.setMaxCapacityTons(rs.getDouble("max_capacity_tons"));
        v.setStatus(Vessel.Status.valueOf(rs.getString("status")));
        v.setRequestedBy(rs.getString("requested_by"));
        int portId = rs.getInt("port_id");
        v.setPortId(rs.wasNull() ? null : portId);
        v.setDocumentName(rs.getString("document_name"));
        v.setHasDocument(rs.getBoolean("has_document"));
        v.setAdminRemarks(rs.getString("admin_remarks"));
        return v;
    }
}