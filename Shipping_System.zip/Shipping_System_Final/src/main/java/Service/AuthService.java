package Service;

import DAO.PermitApplicationDAO;
import DAO.PortDAO;
import DAO.UserDAO;
import Model.PermitApplication;
import Model.Port;
import Model.User;

import java.sql.SQLException;
import java.util.List;

/**
 * NOTE: passwords are compared as plain text to match the current seed data and
 * RegistrationService. Swap in a real hash (e.g. BCrypt) before production.
 */
public class AuthService {

    private final UserDAO userDAO = new UserDAO();
    private final PortDAO portDAO = new PortDAO();
    private final PermitApplicationDAO permitDAO = new PermitApplicationDAO();

    public User login(String username, String password) throws SQLException {
        String id = username.trim();
        User user = userDAO.findByUsername(id);
        if (user == null && id.contains("@")) {
            user = userDAO.findByEmail(id.toLowerCase());
        }
        if (user == null || !password.equals(user.getPasswordHash())) {
            return null;
        }

        if (user.getRole() == User.Role.PORT) {
            Port port = user.getPortId() != null ? portDAO.findById(user.getPortId()) : null;
            if (port == null) {
                throw new IllegalStateException("No port is linked to this account.");
            }
            switch (port.getStatus()) {
                case ACTIVE:
                    break;
                case PENDING:
                    throw new IllegalStateException(
                            "Your registration is still pending admin approval.\nPlease try again later.");
                case SUSPENDED:
                    throw new IllegalStateException(suspendedMessage(port.getId()));
                default:
                    throw new IllegalStateException(
                            "Your port account has been terminated.\nPlease contact the administrator.");
            }
        }
        return user;
    }

    /**
     * Shows the admin's rejection reason when the latest permit was rejected.
     */
    private String suspendedMessage(int portId) throws SQLException {
        List<PermitApplication> history = permitDAO.findByPortId(portId); // newest first
        if (!history.isEmpty() && history.get(0).getStatus() == PermitApplication.Status.REJECTED) {
            String remarks = history.get(0).getAdminRemarks();
            return "Your permit application was rejected."
                    + (remarks != null && !remarks.isBlank() ? "\nReason: " + remarks : "")
                    + "\nPlease contact the administrator.";
        }
        return "Your port account is suspended.\nPlease contact the administrator.";
    }
}
