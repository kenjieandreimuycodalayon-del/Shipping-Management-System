/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import Model.Cargo;
import Model.Port;
import Model.Vessel;
import Service.CargoService;
import Service.PortService;
import Service.VesselService;
import UI.TemplateUI;
import Util.Session;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Frame;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Kenji
 */
public class DispatchQueue extends javax.swing.JPanel {

    private final CargoService cargoService = new CargoService();
    private final PortService portService = new PortService();
    private final VesselService vesselService = new VesselService();

    // parallel to the table rows so a selection maps back to a Cargo
    private List<Cargo> readyList = new ArrayList<>();
    private List<Cargo> transitList = new ArrayList<>();
    private final Map<Integer, Vessel> vesselsById = new HashMap<>();

    /**
     * Creates new form DispatchQueue
     */
    public DispatchQueue() {
        initComponents();
        applyModernStyle();
        dispatch.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        active.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        dispatch.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    inspectMnfst.doClick();
                }
            }
        });
        // Do NOT load in the constructor: PortPanel builds all its screens at app start,
        // before anyone has logged in, so Session.getPortId() would still be null.
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadQueue();
            }
        });
    }

    private void applyModernStyle() {
        TemplateUI.stylePage(jPanel1, jPanel2, jLabel1);

        TemplateUI.styleButton(yesDispatch, true);
        TemplateUI.styleButton(inspectMnfst, true);
        TemplateUI.styleButton(updateRoute, true);
        TemplateUI.styleButton(arrived, true);

        TemplateUI.styleSection(jLabel1);

        jScrollPane1.setBorder(null);
        TemplateUI.styleTable(dispatch, 5, 2);

        jScrollPane2.setBorder(null);
        TemplateUI.styleTable(active, 5, 2);

    }

    private String codeOf(Port p, int portId) {
        if (p == null) {
            return "#" + portId;
        }
        return p.getPortCode() != null ? p.getPortCode() : "#" + p.getId();
    }

    private DefaultTableModel readOnlyModel(Object[][] data, String[] columns) {
        return new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private void loadQueue() {
        Integer me = Session.getPortId();
        if (me == null) {
            return;
        }
        try {
            Map<Integer, Port> ports = new HashMap<>();
            for (Port p : portService.findAll()) {
                ports.put(p.getId(), p);
            }
            vesselsById.clear();
            for (Vessel v : vesselService.findByStatus(null)) {
                vesselsById.put(v.getId(), v);
            }

            // Ready for Dispatch
            readyList = cargoService.readyForDispatch(me);
            Object[][] ready = new Object[readyList.size()][6];
            for (int i = 0; i < readyList.size(); i++) {
                Cargo c = readyList.get(i);
                ready[i][0] = c.getCargoCode();
                ready[i][1] = codeOf(ports.get(c.getDestinationPortId()), c.getDestinationPortId());
                ready[i][2] = String.format("%,d", (long) c.getWeightKg());
                ready[i][3] = c.getProducts() == null ? "" : c.getProducts().size() + " item(s)";
                ready[i][4] = c.getDatePrepared();
                ready[i][5] = c.getPriority();
            }
            dispatch.setModel(readOnlyModel(ready,
                    new String[]{"Cargo ID", "Destination Port", "Weight (kg)", "Products", "Date Prepared", "Priority"}));

            // Active In-Transit (sent by this port or heading to it)
            transitList = cargoService.activeInTransit(me);
            Object[][] transit = new Object[transitList.size()][6];
            for (int i = 0; i < transitList.size(); i++) {
                Cargo c = transitList.get(i);
                Vessel v = c.getVesselId() != null ? vesselsById.get(c.getVesselId()) : null;
                transit[i][0] = c.getCargoCode();
                transit[i][1] = codeOf(ports.get(c.getOriginPortId()), c.getOriginPortId());
                transit[i][2] = codeOf(ports.get(c.getDestinationPortId()), c.getDestinationPortId());
                transit[i][3] = v != null ? v.getVesselName() : "—";
                transit[i][4] = c.getDepartureDate();
                transit[i][5] = c.getEstimatedEta();
            }
            active.setModel(readOnlyModel(transit,
                    new String[]{"Cargo ID", "Origin Port", "Destination Port", "Vessel Name", "Departure", "Est. ETA"}));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load dispatch queue: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Cargo selectedFrom(javax.swing.JTable table, List<Cargo> rows, String what) {
        int row = table.getSelectedRow();
        if (row < 0 || row >= rows.size()) {
            JOptionPane.showMessageDialog(this, "Select " + what + " first.", "No Selection",
                    JOptionPane.WARNING_MESSAGE);
            return null;
        }
        return rows.get(row);
    }

    private Frame owner() {
        return (Frame) SwingUtilities.getWindowAncestor(this);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        dispatch = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        active = new javax.swing.JTable();
        yesDispatch = new javax.swing.JButton();
        inspectMnfst = new javax.swing.JButton();
        updateRoute = new javax.swing.JButton();
        arrived = new javax.swing.JButton();

        setMaximumSize(new java.awt.Dimension(1060, 650));
        setMinimumSize(new java.awt.Dimension(1060, 650));
        setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Dispatch Queue & Route Management");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1)
                .addContainerGap(546, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jLabel6.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Ready for Dispatch");

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Active In-Transit");

        dispatch.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Cargo ID", "Destination Port", "Weight (kg)", "Products", "Date Prepared", "Priority"
            }
        ));
        jScrollPane1.setViewportView(dispatch);
        if (dispatch.getColumnModel().getColumnCount() > 0) {
            dispatch.getColumnModel().getColumn(0).setMinWidth(100);
            dispatch.getColumnModel().getColumn(0).setPreferredWidth(100);
            dispatch.getColumnModel().getColumn(0).setMaxWidth(100);
        }

        active.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Cargo ID", "Origin Port", "Destination Port", "Vessel Name", "Departure", "Est. ETA"
            }
        ));
        jScrollPane2.setViewportView(active);
        if (active.getColumnModel().getColumnCount() > 0) {
            active.getColumnModel().getColumn(0).setMinWidth(100);
            active.getColumnModel().getColumn(0).setPreferredWidth(100);
            active.getColumnModel().getColumn(0).setMaxWidth(100);
        }

        yesDispatch.setBackground(new java.awt.Color(0, 0, 102));
        yesDispatch.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        yesDispatch.setForeground(new java.awt.Color(255, 255, 255));
        yesDispatch.setText(" Assign Vessel & Dispatch");
        yesDispatch.setBorder(null);
        yesDispatch.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        yesDispatch.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        yesDispatch.addActionListener(this::yesDispatchActionPerformed);

        inspectMnfst.setBackground(new java.awt.Color(0, 0, 102));
        inspectMnfst.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        inspectMnfst.setForeground(new java.awt.Color(255, 255, 255));
        inspectMnfst.setText(" Inspect Manifest");
        inspectMnfst.setBorder(null);
        inspectMnfst.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        inspectMnfst.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        inspectMnfst.addActionListener(this::inspectMnfstActionPerformed);

        updateRoute.setBackground(new java.awt.Color(0, 0, 102));
        updateRoute.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        updateRoute.setForeground(new java.awt.Color(255, 255, 255));
        updateRoute.setText(" Update Route / ETA");
        updateRoute.setBorder(null);
        updateRoute.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        updateRoute.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        updateRoute.addActionListener(this::updateRouteActionPerformed);

        arrived.setBackground(new java.awt.Color(0, 0, 102));
        arrived.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        arrived.setForeground(new java.awt.Color(255, 255, 255));
        arrived.setText(" Log Dock Arrival");
        arrived.setBorder(null);
        arrived.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        arrived.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        arrived.addActionListener(this::arrivedActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(updateRoute, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(arrived, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(yesDispatch, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(inspectMnfst, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 960, Short.MAX_VALUE)
                        .addComponent(jScrollPane2)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(yesDispatch, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                    .addComponent(inspectMnfst, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE))
                .addGap(12, 12, 12)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(updateRoute, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                    .addComponent(arrived, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE))
                .addGap(23, 23, 23))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void inspectMnfstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_inspectMnfstActionPerformed
        Cargo cargo;
        if (dispatch.getSelectedRow() >= 0) {
            cargo = selectedFrom(dispatch, readyList, "a cargo");
        } else {
            cargo = selectedFrom(active, transitList, "a cargo");
        }
        if (cargo == null) {
            return;
        }
        InspectManifestDialog dialog = new InspectManifestDialog(owner(), cargo.getId());
        dialog.setVisible(true);
    }//GEN-LAST:event_inspectMnfstActionPerformed

    private void yesDispatchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_yesDispatchActionPerformed
        Integer me = Session.getPortId();
        Cargo cargo = selectedFrom(dispatch, readyList, "a cargo in Ready for Dispatch");
        if (me == null || cargo == null) {
            return;
        }
        try {
            List<Vessel> fleet = vesselService.availableFleet(me);
            if (fleet.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Your port has no ACTIVE vessels.\nRegister a vessel in Ship Registry and wait for admin approval.",
                        "Assign Vessel", JOptionPane.WARNING_MESSAGE);
                return;
            }
            AssignVesselDialog dialog = new AssignVesselDialog(owner(), cargo, fleet, false);
            dialog.setVisible(true);
            if (!dialog.isConfirmed()) {
                return;
            }
            cargoService.dispatch(me, cargo.getId(), dialog.getVessel().getId(),
                    dialog.getDeparture(), dialog.getEta());
            JOptionPane.showMessageDialog(this,
                    "Cargo " + cargo.getCargoCode() + " dispatched on " + dialog.getVessel().getVesselName() + ".",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Dispatch Cargo", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        loadQueue();
    }//GEN-LAST:event_yesDispatchActionPerformed

    private void updateRouteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateRouteActionPerformed
        Integer me = Session.getPortId();
        Cargo cargo = selectedFrom(active, transitList, "a cargo in Active In-Transit");
        if (me == null || cargo == null) {
            return;
        }
        if (cargo.getOriginPortId() != me) {
            JOptionPane.showMessageDialog(this, "Only the origin port can update the route / ETA.",
                    "Update Route / ETA", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            // ACTIVE fleet, plus the cargo's current vessel even if it is no longer ACTIVE
            List<Vessel> fleet = new ArrayList<>(vesselService.availableFleet(me));
            Vessel current = cargo.getVesselId() != null ? vesselsById.get(cargo.getVesselId()) : null;
            if (current != null && fleet.stream().noneMatch(v -> v.getId() == current.getId())) {
                fleet.add(current);
            }
            if (fleet.isEmpty()) {
                JOptionPane.showMessageDialog(this, "There are no vessels available.",
                        "Update Route / ETA", JOptionPane.WARNING_MESSAGE);
                return;
            }
            AssignVesselDialog dialog = new AssignVesselDialog(owner(), cargo, fleet, true);
            dialog.setVisible(true);
            if (!dialog.isConfirmed()) {
                return;
            }
            cargoService.updateRoute(me, cargo.getId(), dialog.getVessel().getId(),
                    dialog.getDeparture(), dialog.getEta());
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Update Route / ETA", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        loadQueue();
    }//GEN-LAST:event_updateRouteActionPerformed

    private void arrivedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_arrivedActionPerformed
        Integer me = Session.getPortId();
        Cargo cargo = selectedFrom(active, transitList, "a cargo in Active In-Transit");
        if (me == null || cargo == null) {
            return;
        }
        if (cargo.getDestinationPortId() != me) {
            JOptionPane.showMessageDialog(this, "Only the destination port can log the dock arrival.",
                    "Log Dock Arrival", JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Log dock arrival for " + cargo.getCargoCode() + "? The cargo will be marked RECEIVED.",
                "Confirm Arrival", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            cargoService.logArrival(me, cargo.getId());
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Log Dock Arrival", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
        loadQueue();
    }//GEN-LAST:event_arrivedActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable active;
    private javax.swing.JButton arrived;
    private javax.swing.JTable dispatch;
    private javax.swing.JButton inspectMnfst;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton updateRoute;
    private javax.swing.JButton yesDispatch;
    // End of variables declaration//GEN-END:variables
}
