package Presentation;

import Service.RegistrationService;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.SQLException;
import java.util.concurrent.ExecutionException;
import Model.PermitInfo;
import UI.TemplateUI;
import java.awt.Frame;

public class RegisterPanel extends javax.swing.JPanel {

    private static final long MAX_PERMIT_BYTES = 5L * 1024 * 1024;
    private static final String NO_FILE_TEXT = "No file selected";

    private final Runnable onBackToLogin;
    private final RegistrationService registrationService = new RegistrationService();

    private byte[] permitBytes;
    private String permitFileName;
    private JLabel permitFileLabel;
    private JLabel permitThumb;
    private JComboBox<String> capabilityBox;
    private PermitInfo permitInfo;

    public RegisterPanel() {
        this(null);
    }

    /**
     * @param onBackToLogin called after a successful registration / "Already
     * have an account?"
     */
    public RegisterPanel(Runnable onBackToLogin) {
        this.onBackToLogin = onBackToLogin;
        initComponents();
        applyModernStyle();

        fillInfoButton.setText("Register");
        jPasswordField1.setText("");
        jPasswordField2.setText("");
        buildPermitUploader();

        jLabel1.setText("");                       // removes the stray "jLabel1" text
        jPanel1.setBackground(java.awt.Color.WHITE);
        removeAll();
        setLayout(new BorderLayout());
        add(UI.ResponsiveShell.loginSplit(jLabel1.getIcon(), jPanel1), BorderLayout.CENTER);

    }

    private void applyModernStyle() {
        TemplateUI.stylePage(jPanel1, jPanel2, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel5 (Port Permits)
        roundedPanel1.setBackground(UIManager.getColor("Table.background"));
        roundedPanel1.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");
        roundedPanel2.setBackground(UIManager.getColor("Table.background"));
        roundedPanel2.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");

        TemplateUI.styleTextField(jTextField1, null);
        TemplateUI.styleTextField(jTextField2, null);
        TemplateUI.stylePasswordField(jPasswordField1);
        TemplateUI.stylePasswordField(jPasswordField2);
        TemplateUI.styleTextField(jTextField3, "e.g. xyz_port");

        TemplateUI.styleButton(fillInfoButton, true);
        TemplateUI.styleButton(loginButton1, true);
    }

    private void onFillInfo() {
        PermitInfoDialog dialog = new PermitInfoDialog(
                (Frame) SwingUtilities.getWindowAncestor(this), jTextField1.getText().trim(), permitInfo);
        dialog.setVisible(true);
        if (dialog.isConfirmed()) {
            permitInfo = dialog.getPermitInfo();
            fillInfoButton.setText("Edit Information");
        }
    }

    private void buildPermitUploader() {
        roundedPanel2.removeAll();
        roundedPanel2.setLayout(new BorderLayout(12, 0));
        roundedPanel2.setBorder(BorderFactory.createEmptyBorder(12, 22, 12, 22));

        // ---- left: title, file name, choose button ----
        permitFileLabel = new JLabel(NO_FILE_TEXT);
        permitFileLabel.setFont(new Font("Gadugi", Font.PLAIN, 13));
        permitFileLabel.setForeground(Color.WHITE);

        JButton browse = new JButton("Choose Photo...");
        browse.setFont(new Font("Gadugi", Font.BOLD, 14));
        browse.setForeground(new Color(0, 0, 83));
        browse.setBackground(Color.WHITE);
        browse.setContentAreaFilled(true);
        browse.setOpaque(true);
        browse.setBorder(null);
        browse.setFocusPainted(false);
        browse.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        browse.setPreferredSize(new Dimension(160, 32));
        browse.setMaximumSize(new Dimension(160, 32));
        browse.addActionListener(e -> onChoosePermit());

        JPanel left = new JPanel();
        left.setOpaque(false);
        left.setLayout(new BoxLayout(left, BoxLayout.Y_AXIS));
        left.setPreferredSize(new Dimension(180, 86));
        jLabel11.setAlignmentX(LEFT_ALIGNMENT);
        permitFileLabel.setAlignmentX(LEFT_ALIGNMENT);
        browse.setAlignmentX(LEFT_ALIGNMENT);
        left.add(jLabel11);
        left.add(Box.createVerticalStrut(6));
        left.add(permitFileLabel);
        left.add(Box.createVerticalStrut(8));
        left.add(browse);

        TemplateUI.styleButton(browse, true);

        // ---- middle: capability dropdown ----
        JLabel capLabel = new JLabel("Primary Capability");
        capLabel.setFont(new Font("Gadugi", Font.BOLD, 14));
        capLabel.setForeground(Color.WHITE);

        capabilityBox = new JComboBox<>(new String[]{
            "Select capability...",
            "Container Handling",
            "Bulk Cargo",
            "Liquid Bulk / Tankers",
            "General Cargo",
            "Roll-on/Roll-off (RoRo)",
            "Refrigerated Cargo",
            "Passenger / Ferry"
        });
        capabilityBox.setFont(new Font("Gadugi", Font.PLAIN, 13));
        capabilityBox.setPreferredSize(new Dimension(210, 32));
        capabilityBox.setMaximumSize(new Dimension(210, 32));

        JPanel middle = new JPanel();
        middle.setOpaque(false);
        middle.setLayout(new BoxLayout(middle, BoxLayout.Y_AXIS));
        middle.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        capLabel.setAlignmentX(LEFT_ALIGNMENT);
        capabilityBox.setAlignmentX(LEFT_ALIGNMENT);
        middle.add(capLabel);
        middle.add(Box.createVerticalStrut(6));
        middle.add(capabilityBox);

        TemplateUI.styleComboBox(capabilityBox);

        // ---- right: thumbnail ----
        permitThumb = new JLabel("No preview", SwingConstants.CENTER);
        permitThumb.setFont(new Font("Gadugi", Font.PLAIN, 12));
        permitThumb.setForeground(Color.WHITE);
        permitThumb.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        permitThumb.setPreferredSize(new Dimension(110, 86));

        roundedPanel2.add(left, BorderLayout.WEST);
        roundedPanel2.add(middle, BorderLayout.CENTER);
        roundedPanel2.add(permitThumb, BorderLayout.EAST);
        roundedPanel2.revalidate();
        roundedPanel2.repaint();

    }

    private void onChoosePermit() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Select Permit Photo");
        fc.setFileFilter(new FileNameExtensionFilter("Images (JPG, PNG)", "jpg", "jpeg", "png"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File f = fc.getSelectedFile();
        if (f.length() > MAX_PERMIT_BYTES) {
            JOptionPane.showMessageDialog(this, "Photo must be 5 MB or smaller.",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            byte[] bytes = Files.readAllBytes(f.toPath());
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(bytes));
            if (img == null) {
                JOptionPane.showMessageDialog(this, "That file is not a valid image.",
                        "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
            permitBytes = bytes;
            permitFileName = f.getName();
            permitFileLabel.setText(f.getName());

            double scale = Math.min(106.0 / img.getWidth(), 82.0 / img.getHeight());
            int w = Math.max(1, (int) (img.getWidth() * scale));
            int h = Math.max(1, (int) (img.getHeight() * scale));
            permitThumb.setText(null);
            permitThumb.setIcon(new ImageIcon(img.getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not read file: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearForm() {
        jTextField1.setText("");
        jTextField2.setText("");
        jPasswordField1.setText("");
        jPasswordField2.setText("");
        jTextField3.setText("");
        capabilityBox.setSelectedIndex(0);
        permitBytes = null;
        permitFileName = null;
        permitFileLabel.setText(NO_FILE_TEXT);
        permitThumb.setIcon(null);
        permitThumb.setText("No preview");
        permitInfo = null;
        fillInfoButton.setText("Fill Up Information");
        
        
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        loginScreenCard = new javax.swing.JPanel();
        coverPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        icon1 = new javax.swing.JButton();
        noAccount = new javax.swing.JButton();
        fillInfoButton = new javax.swing.JButton();
        roundedPanel1 = new JSwing.RoundedPanel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jPasswordField1 = new javax.swing.JPasswordField();
        jLabel10 = new javax.swing.JLabel();
        jPasswordField2 = new javax.swing.JPasswordField();
        jLabel12 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        roundedPanel2 = new JSwing.RoundedPanel();
        jLabel11 = new javax.swing.JLabel();
        loginButton1 = new javax.swing.JButton();

        setMaximumSize(new java.awt.Dimension(1280, 720));
        setMinimumSize(new java.awt.Dimension(1280, 720));
        setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(204, 204, 204));
        jPanel2.setMaximumSize(new java.awt.Dimension(1280, 720));
        jPanel2.setMinimumSize(new java.awt.Dimension(1280, 720));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/Login Coverpage.png"))); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout coverPanelLayout = new javax.swing.GroupLayout(coverPanel);
        coverPanel.setLayout(coverPanelLayout);
        coverPanelLayout.setHorizontalGroup(
            coverPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 600, Short.MAX_VALUE)
        );
        coverPanelLayout.setVerticalGroup(
            coverPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(coverPanelLayout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.setMaximumSize(new java.awt.Dimension(660, 720));
        jPanel1.setMinimumSize(new java.awt.Dimension(660, 720));

        jLabel2.setBackground(new java.awt.Color(0, 51, 153));
        jLabel2.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 0, 102));
        jLabel2.setText("Register Port");

        icon1.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        icon1.setForeground(new java.awt.Color(255, 255, 255));
        icon1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/New Logo.png"))); // NOI18N
        icon1.setText("  ");
        icon1.setBorder(null);
        icon1.setContentAreaFilled(false);
        icon1.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        icon1.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        icon1.setMaximumSize(new java.awt.Dimension(75, 75));
        icon1.setMinimumSize(new java.awt.Dimension(75, 75));
        icon1.setVerifyInputWhenFocusTarget(false);

        noAccount.setFont(new java.awt.Font("Gadugi", 0, 12)); // NOI18N
        noAccount.setForeground(new java.awt.Color(0, 0, 204));
        noAccount.setText("Already have an account? Click here.");
        noAccount.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(255, 255, 255)));
        noAccount.setBorderPainted(false);
        noAccount.setContentAreaFilled(false);
        noAccount.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        noAccount.setFocusPainted(false);
        noAccount.addActionListener(this::noAccountActionPerformed);

        fillInfoButton.setBackground(new java.awt.Color(0, 0, 83));
        fillInfoButton.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        fillInfoButton.setForeground(new java.awt.Color(255, 255, 255));
        fillInfoButton.setText("Fill-up Information Form");
        fillInfoButton.setBorder(javax.swing.BorderFactory.createTitledBorder(""));
        fillInfoButton.setBorderPainted(false);
        fillInfoButton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        fillInfoButton.setFocusPainted(false);
        fillInfoButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        fillInfoButton.addActionListener(this::fillInfoButtonActionPerformed);

        roundedPanel1.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel1.setMaximumSize(new java.awt.Dimension(578, 233));
        roundedPanel1.setMinimumSize(new java.awt.Dimension(578, 233));

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Company Name");

        jLabel8.setBackground(new java.awt.Color(255, 255, 255));
        jLabel8.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("Email");

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("Password");

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("Confirm Password");

        jLabel12.setBackground(new java.awt.Color(255, 255, 255));
        jLabel12.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 102));
        jLabel12.setText("Username");

        jTextField3.addActionListener(this::jTextField3ActionPerformed);

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12)
                    .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel10)
                        .addComponent(jTextField1, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)
                        .addComponent(jLabel8)
                        .addComponent(jLabel7)
                        .addComponent(jLabel9)
                        .addComponent(jTextField2)
                        .addComponent(jPasswordField1)
                        .addComponent(jPasswordField2)
                        .addComponent(jTextField3, javax.swing.GroupLayout.DEFAULT_SIZE, 450, Short.MAX_VALUE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel12)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPasswordField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        roundedPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 102));
        jLabel11.setText("Upload Permit");

        javax.swing.GroupLayout roundedPanel2Layout = new javax.swing.GroupLayout(roundedPanel2);
        roundedPanel2.setLayout(roundedPanel2Layout);
        roundedPanel2Layout.setHorizontalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jLabel11)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel2Layout.setVerticalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel11)
                .addContainerGap(72, Short.MAX_VALUE))
        );

        loginButton1.setBackground(new java.awt.Color(0, 0, 83));
        loginButton1.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        loginButton1.setForeground(new java.awt.Color(255, 255, 255));
        loginButton1.setText("Login");
        loginButton1.setBorder(null);
        loginButton1.setBorderPainted(false);
        loginButton1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        loginButton1.setFocusPainted(false);
        loginButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        loginButton1.addActionListener(this::loginButton1ActionPerformed);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(235, 235, 235)
                        .addComponent(icon1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(roundedPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(roundedPanel1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(50, 50, 50))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(249, 249, 249)
                .addComponent(jLabel2)
                .addGap(0, 281, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(120, 120, 120)
                                .addComponent(loginButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 141, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(94, 94, 94)
                                .addComponent(noAccount)))
                        .addGap(111, 111, 111))
                    .addComponent(fillInfoButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 399, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(134, 134, 134))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(icon1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(roundedPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(fillInfoButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(loginButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(noAccount)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout loginScreenCardLayout = new javax.swing.GroupLayout(loginScreenCard);
        loginScreenCard.setLayout(loginScreenCardLayout);
        loginScreenCardLayout.setHorizontalGroup(
            loginScreenCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginScreenCardLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(coverPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        loginScreenCardLayout.setVerticalGroup(
            loginScreenCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(loginScreenCardLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(loginScreenCardLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(loginScreenCardLayout.createSequentialGroup()
                        .addComponent(coverPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(loginScreenCardLayout.createSequentialGroup()
                        .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(39, 39, 39))))
        );

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(loginScreenCard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(loginScreenCard, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        add(jPanel2, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void fillInfoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fillInfoButtonActionPerformed
        onFillInfo();
    }//GEN-LAST:event_fillInfoButtonActionPerformed

    private void noAccountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_noAccountActionPerformed
        if (onBackToLogin != null) {
            onBackToLogin.run();
        }
    }//GEN-LAST:event_noAccountActionPerformed

    private void loginButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButton1ActionPerformed
        String company = jTextField1.getText().trim();
        String username = jTextField3.getText().trim();
        String email = jTextField2.getText().trim();
        String password = new String(jPasswordField1.getPassword());
        String confirm = new String(jPasswordField2.getPassword());

        String error = null;
        if (company.isEmpty() || username.isEmpty() || email.isEmpty() || password.isEmpty()) {
            error = "Please fill in all fields.";
        } else if (!username.matches("^[A-Za-z0-9._-]{4,50}$")) {
            error = "Username must be 4-50 characters: letters, numbers, dot, dash or underscore (no spaces).";
        } else if (!email.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            error = "Please enter a valid email address.";
        } else if (password.length() < 6) {
            error = "Password must be at least 6 characters.";
        } else if (!password.equals(confirm)) {
            error = "Passwords do not match.";
        } else if (capabilityBox.getSelectedIndex() == 0) {
            error = "Please select your port's primary capability.";
        } else if (permitInfo == null) {
            error = "Please fill up your permit information.";
        } else if (permitBytes == null) {
            error = "Please upload a photo of your permit.";
        }
        if (error != null) {
            JOptionPane.showMessageDialog(this, error, "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        final String capability = (String) capabilityBox.getSelectedItem();
        final String fileName = permitFileName;
        final byte[] bytes = permitBytes;
        fillInfoButton.setEnabled(false);
        final PermitInfo info = permitInfo;

        new SwingWorker<Void, Void>() {
            @Override
            protected Void doInBackground() throws Exception {
                registrationService.registerPort(company, username, email, password, capability, info, fileName, bytes);
                return null;
            }

            @Override
            protected void done() {
                fillInfoButton.setEnabled(true);
                try {
                    get();
                    JOptionPane.showMessageDialog(RegisterPanel.this,
                            "Registration submitted.\n\nStatus: PENDING admin approval.",
                            "Success", JOptionPane.INFORMATION_MESSAGE);
                    clearForm();
                    if (onBackToLogin != null) {
                        onBackToLogin.run();
                    }
                } catch (InterruptedException ex) {
                    Thread.currentThread().interrupt();
                } catch (ExecutionException ex) {
                    Throwable cause = ex.getCause();
                    if (cause instanceof IllegalStateException) {
                        JOptionPane.showMessageDialog(RegisterPanel.this, cause.getMessage(),
                                "Validation", JOptionPane.WARNING_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(RegisterPanel.this, "Database error: " + cause.getMessage(),
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        }.execute();
    }//GEN-LAST:event_loginButton1ActionPerformed

    private void jTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField3ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel coverPanel;
    private javax.swing.JButton fillInfoButton;
    private javax.swing.JButton icon1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPasswordField jPasswordField1;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JButton loginButton1;
    private javax.swing.JPanel loginScreenCard;
    private javax.swing.JButton noAccount;
    private JSwing.RoundedPanel roundedPanel1;
    private JSwing.RoundedPanel roundedPanel2;
    // End of variables declaration//GEN-END:variables
}
