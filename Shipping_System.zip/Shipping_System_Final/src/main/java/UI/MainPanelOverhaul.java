package UI;

import com.formdev.flatlaf.FlatClientProperties;
import javax.swing.*;
import java.awt.*;

public final class MainPanelOverhaul {

    private MainPanelOverhaul() {
    }

    public static final String FONT = "Segoe UI";
    public static final Color TOP_BAR_BG = new Color(26, 44, 117);
    public static final Color SIDEBAR_BG = new Color(0, 0, 83);
    public static final Color NAV_ACTIVE_BG = new Color(40, 60, 150);
    public static final Color TEXT_WHITE = new Color(255, 255, 255);

    public static Font font(int style, int size) {
        return new Font(FONT, style, size);
    }

    public static void styleHeaderPanel(JPanel topPanel, JLabel titleLabel) {
        if (topPanel != null) {
            topPanel.setBackground(TOP_BAR_BG);
        }
        if (titleLabel != null) {
            titleLabel.setFont(font(Font.BOLD, 22));
            titleLabel.setForeground(TEXT_WHITE);
        }
    }

    public static void styleSidebar(JPanel sidePanel) {
        if (sidePanel != null) {
            sidePanel.setBackground(SIDEBAR_BG);
        }
    }

    public static void styleNavButton(JButton button, boolean active) {
        if (button == null) {
            return;
        }

        button.setFont(font(Font.BOLD, 15));
        button.setForeground(TEXT_WHITE);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
        button.setContentAreaFilled(true);

        if (active) {
            button.setBackground(NAV_ACTIVE_BG);
            button.putClientProperty(FlatClientProperties.STYLE,
                    "background: #283c96; arc: 10; borderWidth: 0; focusWidth: 0;");
        } else {
            button.setBackground(SIDEBAR_BG);
            button.putClientProperty(FlatClientProperties.STYLE,
                    "background: #000053; arc: 10; borderWidth: 0; focusWidth: 0;");
        }
    }

    public static void styleLogoutButton(JButton btnLogout) {
        if (btnLogout == null) {
            return;
        }

        btnLogout.setFont(font(Font.BOLD, 12));
        btnLogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnLogout.putClientProperty(FlatClientProperties.STYLE,
                "background: #b42828; foreground: #ffffff; arc: 10; borderWidth: 0; focusWidth: 0;");
    }

    /**
     * Updates dynamic selection state across single buttons or text+icon pairs.
     */
    public static void updateSidebarSelection(JButton activeBtn, JButton[] textButtons, JButton[] iconButtons) {
        for (int i = 0; i < textButtons.length; i++) {
            boolean isActive = (textButtons[i] == activeBtn || (iconButtons != null && i < iconButtons.length && iconButtons[i] == activeBtn));

            styleNavButton(textButtons[i], isActive);
            if (iconButtons != null && i < iconButtons.length && iconButtons[i] != null) {
                styleNavButton(iconButtons[i], isActive);
            }
        }
    }

    public static void styleIconButton(JButton button) {
        if (button == null) {
            return;
        }

        button.setText("");                                   // drop the "  " label
        button.setHorizontalAlignment(SwingConstants.CENTER);  // center the icon
        button.setMargin(new Insets(0, 0, 0, 0));
        button.setContentAreaFilled(true);
        button.setOpaque(true);
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.putClientProperty(FlatClientProperties.STYLE,
                "background: #ffffff; "
                + "hoverBackground: #eef0f8; "
                + "pressedBackground: #dde1f0; "
                + "arc: 12; borderWidth: 0; focusWidth: 0; margin: 0,0,0,0;");
    }

    public static void buildSidebar(JPanel side, JButton[] icons, JButton[] texts) {
        final int ROW_H = 52, ICON_W = 50, TEXT_W = 141, GAP = 18;

        side.removeAll();
        side.setLayout(new GridBagLayout());
        side.setPreferredSize(new Dimension(220, 650));

        for (int i = 0; i < texts.length; i++) {
            JButton icon = icons[i];
            JButton text = texts[i];

            icon.setText("");
            icon.setHorizontalAlignment(SwingConstants.CENTER);
            icon.setVerticalAlignment(SwingConstants.CENTER);
            icon.setBorder(null);
            icon.setPreferredSize(new Dimension(ICON_W, ROW_H));

            text.setText(text.getText().trim());   // no more space-padded labels
            text.setHorizontalAlignment(SwingConstants.LEADING);
            text.setBorder(BorderFactory.createEmptyBorder(0, 14, 0, 8));
            text.setPreferredSize(new Dimension(TEXT_W, ROW_H));

            JPanel row = new JPanel(new BorderLayout(6, 0));
            row.setOpaque(false);
            row.add(icon, BorderLayout.WEST);
            row.add(text, BorderLayout.CENTER);

            GridBagConstraints gc = new GridBagConstraints();
            gc.gridx = 0;
            gc.gridy = i;
            gc.weightx = 1;
            gc.fill = GridBagConstraints.HORIZONTAL;
            gc.anchor = GridBagConstraints.NORTHWEST;
            gc.insets = new Insets(i == 0 ? 20 : GAP, 9, 0, 9);
            side.add(row, gc);
        }

        GridBagConstraints filler = new GridBagConstraints();
        filler.gridx = 0;
        filler.gridy = texts.length;
        filler.weighty = 1;
        side.add(Box.createVerticalGlue(), filler);

        side.revalidate();
        side.repaint();
    }
}
