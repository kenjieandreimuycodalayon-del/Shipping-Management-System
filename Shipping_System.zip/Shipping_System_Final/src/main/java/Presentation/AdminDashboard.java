/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import UI.DashboardUI;
import Model.Cargo;
import Model.Port;
import Model.Vessel;
import Service.CargoService;
import Service.PortService;
import Service.VesselService;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Model.User;
import Service.MessageService;
import UI.MainPanelOverhaul;
import Util.Session;

/**
 *
 * @author Kenji
 */
public class AdminDashboard extends javax.swing.JPanel {

    private static final int RECENT_LIMIT = 10;
    private static final String[] MOVEMENT_COLUMNS
            = {"Cargo ID", "Origin Port", "Destination Port", "Vessel", "Weight (kg)", "Status"};

    private final PortService portService = new PortService();
    private final VesselService vesselService = new VesselService();
    private final CargoService cargoService = new CargoService();

    /**
     * Creates new form AdminDashboard
     */
    public AdminDashboard() {
        initComponents();

        applyModernStyle();
        MainPanelOverhaul.styleIconButton(adminMsg);

        // refresh every time the Dashboard card is shown (an approval may have changed the numbers)...
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadOverview();
            }
        });
        // ...and once now so it is not empty on first view
        loadOverview();
    }

    private String codeOf(Port p, int portId) {
        if (p == null) {
            return "#" + portId;
        }
        return p.getPortCode() != null ? p.getPortCode() : "#" + p.getId();
    }

    private DefaultTableModel readOnlyModel(Object[][] data, String[] columns) {
        return new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private void applyModernStyle() {
        DashboardUI.stylePage(adminPanel, adminTitle, jLabel1, adminDes1);
        roundedPanel8.setBackground(adminPanel.getBackground());
        DashboardUI.styleButton(refreshSysOv, false);
        DashboardUI.styleButton(exportSum, false);
        DashboardUI.styleButton(reviewPerm, true);
        DashboardUI.styleStatCard(roundedPanel5, jLabel2, jTextField3, DashboardUI.BLUE);    // Total Ports
        DashboardUI.styleStatCard(roundedPanel1, jLabel3, jTextField10, DashboardUI.AMBER);  // Pending Approvals
        DashboardUI.styleStatCard(roundedPanel2, jLabel4, jTextField11, DashboardUI.GREEN);  // Cargo In Transit
        DashboardUI.styleStatCard(roundedPanel3, jLabel11, jTextField12, DashboardUI.RED);   // Terminated Ports
        DashboardUI.styleSection(adminLab1);
        adminDashScroll.setBorder(null);
        DashboardUI.styleTable(portDashTable, 5, 4);
    }

    /**
     * Fills the four stat boxes and the Recent Cargo Movements table.
     */
    private void loadOverview() {
        try {
            List<Port> allPorts = portService.findAll();
            Map<Integer, Port> ports = new HashMap<>();
            for (Port p : allPorts) {
                ports.put(p.getId(), p);
            }
            Map<Integer, Vessel> vessels = new HashMap<>();
            for (Vessel v : vesselService.findByStatus(null)) {
                vessels.put(v.getId(), v);
            }

            // Pending Approvals = port permits + vessel registrations (the two tabs of Central Approvals Hub)
            int pending = portService.pendingPermitReviews().size() + vesselService.pendingRegistrations().size();

            jTextField3.setText(String.valueOf(allPorts.size()));
            jTextField10.setText(String.valueOf(pending));
            jTextField11.setText(String.valueOf(cargoService.activeInTransit().size()));
            jTextField12.setText(String.valueOf(portService.findByStatus(Port.Status.TERMINATED).size()));

            List<Cargo> recent = cargoService.recent(RECENT_LIMIT);
            Object[][] data = new Object[recent.size()][6];
            for (int i = 0; i < recent.size(); i++) {
                Cargo c = recent.get(i);
                Vessel v = c.getVesselId() != null ? vessels.get(c.getVesselId()) : null;
                data[i][0] = c.getCargoCode();
                data[i][1] = codeOf(ports.get(c.getOriginPortId()), c.getOriginPortId());
                data[i][2] = codeOf(ports.get(c.getDestinationPortId()), c.getDestinationPortId());
                data[i][3] = v != null ? v.getVesselName() : "\u2014";
                data[i][4] = String.format("%,d", (long) c.getWeightKg());
                data[i][5] = c.getStatus();
            }
            portDashTable.setModel(readOnlyModel(data, MOVEMENT_COLUMNS));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load dashboard: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateUnreadTooltip() {
        User u = Session.getCurrentUser();
        if (u == null) {
            return;
        }
        try {
            int n = new MessageService().unreadCount(u.getId());
            adminMsg.setToolTipText(n > 0 ? "Messages (" + n + " unread)" : "Messages");
        } catch (SQLException ignored) {
        }
    }

    private static String csv(Object value) {
        String text = value == null ? "" : value.toString();
        if (text.contains(",") || text.contains("\"") || text.contains("\n")) {
            return "\"" + text.replace("\"", "\"\"") + "\"";
        }
        return text;
    }

    /**
     * Export Summary: the four stat numbers + the Recent Cargo Movements table
     * as a .csv file.
     */
    private void exportSummary() {
        loadOverview(); // export what is true right now, not what was on screen earlier

        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Export Summary");
        fc.setFileFilter(new FileNameExtensionFilter("CSV files (*.csv)", "csv"));
        fc.setSelectedFile(new File("lodestar-summary-" + java.time.LocalDate.now() + ".csv"));
        if (fc.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File file = fc.getSelectedFile();
        if (!file.getName().toLowerCase().endsWith(".csv")) {
            file = new File(file.getParentFile(), file.getName() + ".csv");
        }
        if (file.exists()) {
            int confirm = JOptionPane.showConfirmDialog(this,
                    file.getName() + " already exists. Replace it?",
                    "Confirm Overwrite", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
        }

        StringBuilder sb = new StringBuilder("\uFEFF"); // BOM so Excel opens it as UTF-8
        sb.append("Lodestar Shipping Co. - System Summary\n");
        sb.append("Generated,").append(csv(LocalDateTime.now().withNano(0))).append("\n\n");
        sb.append("Metric,Value\n");
        sb.append("Total Ports,").append(csv(jTextField3.getText())).append("\n");
        sb.append("Pending Approvals,").append(csv(jTextField10.getText())).append("\n");
        sb.append("Cargo In Transit,").append(csv(jTextField11.getText())).append("\n");
        sb.append("Terminated Ports,").append(csv(jTextField12.getText())).append("\n\n");

        sb.append("Recent Cargo Movements\n");
        javax.swing.table.TableModel model = portDashTable.getModel();
        for (int c = 0; c < model.getColumnCount(); c++) {
            sb.append(c > 0 ? "," : "").append(csv(model.getColumnName(c)));
        }
        sb.append("\n");
        for (int r = 0; r < model.getRowCount(); r++) {
            for (int c = 0; c < model.getColumnCount(); c++) {
                sb.append(c > 0 ? "," : "").append(csv(model.getValueAt(r, c)));
            }
            sb.append("\n");
        }

        try {
            Files.write(file.toPath(), sb.toString().getBytes(StandardCharsets.UTF_8));
            JOptionPane.showMessageDialog(this, "Summary exported to:\n" + file.getAbsolutePath(),
                    "Export Summary", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not save the file: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        adminPanel = new javax.swing.JPanel();
        roundedPanel5 = new JSwing.RoundedPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        adminTitle = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        adminMsg = new javax.swing.JButton();
        roundedPanel8 = new JSwing.RoundedPanel();
        refreshSysOv = new javax.swing.JButton();
        exportSum = new javax.swing.JButton();
        reviewPerm = new javax.swing.JButton();
        adminDes1 = new javax.swing.JPanel();
        adminDashScroll = new javax.swing.JScrollPane();
        portDashTable = new javax.swing.JTable();
        adminLab1 = new javax.swing.JLabel();
        roundedPanel1 = new JSwing.RoundedPanel();
        jTextField10 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        roundedPanel2 = new JSwing.RoundedPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        roundedPanel3 = new JSwing.RoundedPanel();
        jLabel11 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();

        setMaximumSize(new java.awt.Dimension(1060, 650));
        setMinimumSize(new java.awt.Dimension(1060, 650));
        setLayout(new java.awt.BorderLayout());

        adminPanel.setBackground(new java.awt.Color(244, 246, 249));

        roundedPanel5.setBackground(new java.awt.Color(11, 29, 81));
        roundedPanel5.setMaximumSize(new java.awt.Dimension(225, 130));
        roundedPanel5.setMinimumSize(new java.awt.Dimension(225, 130));

        jLabel2.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Total Ports");

        jTextField3.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 36)); // NOI18N
        jTextField3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField3.setText("0");

        javax.swing.GroupLayout roundedPanel5Layout = new javax.swing.GroupLayout(roundedPanel5);
        roundedPanel5.setLayout(roundedPanel5Layout);
        roundedPanel5Layout.setHorizontalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel5Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        roundedPanel5Layout.setVerticalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );

        adminTitle.setBackground(new java.awt.Color(255, 255, 255));
        adminTitle.setMaximumSize(new java.awt.Dimension(1060, 60));
        adminTitle.setMinimumSize(new java.awt.Dimension(1060, 60));
        adminTitle.setPreferredSize(new java.awt.Dimension(1060, 60));

        jLabel1.setFont(new java.awt.Font("Gadugi", 3, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Admin Dashboard");

        adminMsg.setBackground(new java.awt.Color(0, 0, 83));
        adminMsg.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        adminMsg.setForeground(new java.awt.Color(255, 255, 255));
        adminMsg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/mesg (1).png"))); // NOI18N
        adminMsg.setText("  ");
        adminMsg.setBorder(null);
        adminMsg.setContentAreaFilled(false);
        adminMsg.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        adminMsg.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        adminMsg.setOpaque(true);
        adminMsg.addActionListener(this::adminMsgActionPerformed);

        javax.swing.GroupLayout adminTitleLayout = new javax.swing.GroupLayout(adminTitle);
        adminTitle.setLayout(adminTitleLayout);
        adminTitleLayout.setHorizontalGroup(
            adminTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminTitleLayout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(adminMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );
        adminTitleLayout.setVerticalGroup(
            adminTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminTitleLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(adminTitleLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(adminMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap())
        );

        roundedPanel8.setBackground(new java.awt.Color(255, 255, 255));

        refreshSysOv.setBackground(new java.awt.Color(0, 0, 102));
        refreshSysOv.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        refreshSysOv.setForeground(new java.awt.Color(255, 255, 255));
        refreshSysOv.setText("  Refresh System Overview");
        refreshSysOv.setBorder(null);
        refreshSysOv.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        refreshSysOv.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        refreshSysOv.addActionListener(this::refreshSysOvActionPerformed);

        exportSum.setBackground(new java.awt.Color(0, 0, 102));
        exportSum.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        exportSum.setForeground(new java.awt.Color(255, 255, 255));
        exportSum.setText("    Export Summary");
        exportSum.setBorder(null);
        exportSum.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        exportSum.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        exportSum.addActionListener(this::exportSumActionPerformed);

        reviewPerm.setBackground(new java.awt.Color(0, 0, 102));
        reviewPerm.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        reviewPerm.setForeground(new java.awt.Color(255, 255, 255));
        reviewPerm.setText("  Review Pending Permits");
        reviewPerm.setBorder(null);
        reviewPerm.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        reviewPerm.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        reviewPerm.addActionListener(this::reviewPermActionPerformed);

        javax.swing.GroupLayout roundedPanel8Layout = new javax.swing.GroupLayout(roundedPanel8);
        roundedPanel8.setLayout(roundedPanel8Layout);
        roundedPanel8Layout.setHorizontalGroup(
            roundedPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel8Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(refreshSysOv, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(reviewPerm, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(exportSum, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel8Layout.setVerticalGroup(
            roundedPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel8Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(refreshSysOv, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(exportSum, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reviewPerm, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        adminDes1.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout adminDes1Layout = new javax.swing.GroupLayout(adminDes1);
        adminDes1.setLayout(adminDes1Layout);
        adminDes1Layout.setHorizontalGroup(
            adminDes1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        adminDes1Layout.setVerticalGroup(
            adminDes1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        portDashTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Port ID", "Port Name", "Capability", "Permit Submitted", "Status"
            }
        ));
        adminDashScroll.setViewportView(portDashTable);

        adminLab1.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        adminLab1.setForeground(new java.awt.Color(0, 0, 102));
        adminLab1.setText("Recent Cargo Movements");

        roundedPanel1.setBackground(new java.awt.Color(11, 29, 81));
        roundedPanel1.setMaximumSize(new java.awt.Dimension(225, 130));
        roundedPanel1.setMinimumSize(new java.awt.Dimension(225, 130));

        jTextField10.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 36)); // NOI18N
        jTextField10.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField10.setText("0");

        jLabel3.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Pending Approvals");

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        roundedPanel2.setBackground(new java.awt.Color(11, 29, 81));
        roundedPanel2.setMaximumSize(new java.awt.Dimension(225, 130));
        roundedPanel2.setMinimumSize(new java.awt.Dimension(225, 130));

        jLabel4.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Cargo In Transit");

        jTextField11.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 36)); // NOI18N
        jTextField11.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField11.setText("0");

        javax.swing.GroupLayout roundedPanel2Layout = new javax.swing.GroupLayout(roundedPanel2);
        roundedPanel2.setLayout(roundedPanel2Layout);
        roundedPanel2Layout.setHorizontalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30))
        );
        roundedPanel2Layout.setVerticalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        roundedPanel3.setBackground(new java.awt.Color(11, 29, 81));
        roundedPanel3.setMaximumSize(new java.awt.Dimension(225, 130));
        roundedPanel3.setMinimumSize(new java.awt.Dimension(225, 130));

        jLabel11.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Terminated Ports");

        jTextField12.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 36)); // NOI18N
        jTextField12.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField12.setText("0");

        javax.swing.GroupLayout roundedPanel3Layout = new javax.swing.GroupLayout(roundedPanel3);
        roundedPanel3.setLayout(roundedPanel3Layout);
        roundedPanel3Layout.setHorizontalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel3Layout.createSequentialGroup()
                .addGroup(roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel3Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel3Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(30, Short.MAX_VALUE))
        );
        roundedPanel3Layout.setVerticalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout adminPanelLayout = new javax.swing.GroupLayout(adminPanel);
        adminPanel.setLayout(adminPanelLayout);
        adminPanelLayout.setHorizontalGroup(
            adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminPanelLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(adminPanelLayout.createSequentialGroup()
                        .addComponent(adminLab1, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(adminPanelLayout.createSequentialGroup()
                        .addGroup(adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(adminDashScroll)
                            .addComponent(adminDes1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(roundedPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(adminPanelLayout.createSequentialGroup()
                                .addComponent(roundedPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(roundedPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(roundedPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                        .addGap(50, 50, 50))))
            .addComponent(adminTitle, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        adminPanelLayout.setVerticalGroup(
            adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(adminPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(adminTitle, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addGroup(adminPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(roundedPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(roundedPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(roundedPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(roundedPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20)
                .addComponent(roundedPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(adminDes1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(adminLab1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(adminDashScroll, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(46, Short.MAX_VALUE))
        );

        add(adminPanel, java.awt.BorderLayout.PAGE_END);
    }// </editor-fold>//GEN-END:initComponents

    private void refreshSysOvActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshSysOvActionPerformed
        loadOverview();
    }//GEN-LAST:event_refreshSysOvActionPerformed

    private void reviewPermActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reviewPermActionPerformed
        AdminPanel admin = (AdminPanel) SwingUtilities.getAncestorOfClass(AdminPanel.class, this);
        if (admin != null) {
            admin.showApprovals();
        }
    }//GEN-LAST:event_reviewPermActionPerformed

    private void exportSumActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exportSumActionPerformed
        exportSummary();
    }//GEN-LAST:event_exportSumActionPerformed

    private void adminMsgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminMsgActionPerformed
        new MessagesDialog(SwingUtilities.getWindowAncestor(this)).setVisible(true);
        updateUnreadTooltip();
    }//GEN-LAST:event_adminMsgActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane adminDashScroll;
    private javax.swing.JPanel adminDes1;
    private javax.swing.JLabel adminLab1;
    private javax.swing.JButton adminMsg;
    private javax.swing.JPanel adminPanel;
    private javax.swing.JPanel adminTitle;
    private javax.swing.JButton exportSum;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTable portDashTable;
    private javax.swing.JButton refreshSysOv;
    private javax.swing.JButton reviewPerm;
    private JSwing.RoundedPanel roundedPanel1;
    private JSwing.RoundedPanel roundedPanel2;
    private JSwing.RoundedPanel roundedPanel3;
    private JSwing.RoundedPanel roundedPanel5;
    private JSwing.RoundedPanel roundedPanel8;
    // End of variables declaration//GEN-END:variables
}
