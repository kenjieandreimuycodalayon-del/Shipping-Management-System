/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import Model.PermitReview;
import Model.Port;
import Model.Vessel;
import Service.PortService;
import Service.VesselService;
import UI.DashboardUI;
import UI.TemplateUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Frame;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.List;
import java.util.stream.Collectors;

public class PendingApprovals extends javax.swing.JPanel {

    private final PortService portService = new PortService();
    private List<PermitReview> currentReviews;
    private final VesselService vesselService = new VesselService();
    private List<Vessel> currentVessels;

    public PendingApprovals() {
        initComponents();

        applyModernStyle();
        applyModernStyle2();

        approvePermit.setText("Approve Port");

        // ---- Vessel Registrations tab ----
        portApproval.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        vesselPending.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        vesselPending.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    openVesselReview();
                }
            }
        });
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadPendingVessels();
            }
        });
        loadPendingVessels();

        // double-click a request -> open the review dialog
        portApproval.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    openReview();
                }
            }
        });

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadPendingPorts();
            }
        });

        loadPendingPorts();
    }

    private void loadPendingPorts() {
        try {
            String kw = jTextField2.getText().trim().toLowerCase();
            currentReviews = portService.pendingPermitReviews().stream()
                    .filter(r -> kw.isEmpty()
                    || (r.getPortName() != null && r.getPortName().toLowerCase().contains(kw))
                    || (r.getPortCode() != null && r.getPortCode().toLowerCase().contains(kw))
                    || (r.getPermitNo() != null && r.getPermitNo().toLowerCase().contains(kw)))
                    .collect(Collectors.toList());

            Object[][] data = new Object[currentReviews.size()][5];
            for (int i = 0; i < currentReviews.size(); i++) {
                PermitReview r = currentReviews.get(i);
                data[i][0] = r.getPortCode() != null ? r.getPortCode() : "#" + r.getPortId();
                data[i][1] = r.getPortName();
                data[i][2] = r.getPrimaryCapability() != null ? r.getPrimaryCapability() : "—";
                data[i][3] = r.getDateSubmitted();
                data[i][4] = r.getStatus();
            }
            portApproval.setModel(new DefaultTableModel(data,
                    new String[]{"Port ID", "Port Name", "Capability / Spec", "Date Submitted", "Status"}) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            });
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load pending permits: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void applyModernStyle() {
        TemplateUI.stylePage(approvalPanel, jPanel2, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel5 (Port Permits)
        roundedPanel5.setBackground(UIManager.getColor("Table.background"));
        roundedPanel5.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");

        TemplateUI.styleButton(approvePermit, true);
        TemplateUI.styleButton(rejectPermit, true);
        TemplateUI.styleSection(jLabel9);
        jScrollPane2.setBorder(null);
        TemplateUI.styleTable(portApproval, 4, 2);
    }

    private void applyModernStyle2() {
        TemplateUI.stylePage(approvalPanel, jPanel2, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel4 (Vessel Permits)
        roundedPanel4.setBackground(UIManager.getColor("Table.background"));
        roundedPanel4.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");

        TemplateUI.styleButton(approveVessel, true);
        TemplateUI.styleButton(rejectShipReq, true);
        TemplateUI.styleSection(jLabel6);
        jScrollPane1.setBorder(null);
        TemplateUI.styleTable(vesselPending, 4, 2);
    }

    private PermitReview selectedReview() {
        int row = portApproval.getSelectedRow();
        if (currentReviews == null || row < 0 || row >= currentReviews.size()) {
            JOptionPane.showMessageDialog(this, "Select a request first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        return currentReviews.get(row);
    }

    private void openReview() {
        PermitReview r = selectedReview();
        if (r == null) {
            return;
        }
        PermitReviewDialog dialog = new PermitReviewDialog((Frame) SwingUtilities.getWindowAncestor(this), r);
        dialog.setVisible(true);
        if (dialog.getDecision() == PermitReviewDialog.Decision.APPROVE) {
            decide(r, true);
        } else if (dialog.getDecision() == PermitReviewDialog.Decision.REJECT) {
            decide(r, false);
        }
    }

    private void decide(PermitReview r, boolean approve) {
        String label = approve ? "Approve" : "Reject";
        String remarks = JOptionPane.showInputDialog(this,
                label + " permit " + r.getPermitNo() + " for " + r.getPortName() + "?\nRemarks"
                + (approve ? " (optional):" : " (required):"),
                label + " Permit", JOptionPane.QUESTION_MESSAGE);
        if (remarks == null) {
            return; // cancelled
        }
        if (!approve && remarks.isBlank()) {
            JOptionPane.showMessageDialog(this, "Please enter a reason for rejecting.",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            if (approve) {
                portService.approvePermit(r.getPermitId(), r.getPortId(), remarks.trim());
            } else {
                portService.rejectPermit(r.getPermitId(), r.getPortId(), remarks.trim());
            }
            loadPendingPorts();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // ===================== Vessel Registrations tab =====================
    private void loadPendingVessels() {
        try {
            String kw = jTextField1.getText().trim().toLowerCase();
            currentVessels = vesselService.pendingRegistrations().stream()
                    .filter(v -> kw.isEmpty()
                    || (v.getVesselName() != null && v.getVesselName().toLowerCase().contains(kw))
                    || (v.getImoNumber() != null && v.getImoNumber().toLowerCase().contains(kw))
                    || (v.getCarrierLine() != null && v.getCarrierLine().toLowerCase().contains(kw))
                    || (v.getRequestedBy() != null && v.getRequestedBy().toLowerCase().contains(kw)))
                    .collect(Collectors.toList());

            Object[][] data = new Object[currentVessels.size()][5];
            for (int i = 0; i < currentVessels.size(); i++) {
                Vessel v = currentVessels.get(i);
                data[i][0] = v.getImoNumber();
                data[i][1] = v.getVesselName();
                data[i][2] = v.getCarrierLine() != null ? v.getCarrierLine() : "\u2014";
                data[i][3] = v.getMaxCapacityTons();
                data[i][4] = v.getRequestedBy() != null ? v.getRequestedBy() : "\u2014";
            }
            vesselPending.setModel(new DefaultTableModel(data,
                    new String[]{"IMO Number", "Vessel Name", "Carrier / Line", "Max Cap (Tons)", "Requested By"}) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            });
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load pending vessels: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Vessel selectedVessel() {
        int row = vesselPending.getSelectedRow();
        if (currentVessels == null || row < 0 || row >= currentVessels.size()) {
            JOptionPane.showMessageDialog(this, "Select a request first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        return currentVessels.get(row);
    }

    private void openVesselReview() {
        Vessel v = selectedVessel();
        if (v == null) {
            return;
        }
        Port owner = null;
        try {
            if (v.getPortId() != null) {
                owner = portService.findById(v.getPortId());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        VesselReviewDialog dialog = new VesselReviewDialog((Frame) SwingUtilities.getWindowAncestor(this), v, owner);
        dialog.setVisible(true);
        if (dialog.getDecision() == VesselReviewDialog.Decision.APPROVE) {
            decideVessel(v, true);
        } else if (dialog.getDecision() == VesselReviewDialog.Decision.REJECT) {
            decideVessel(v, false);
        }
    }

    private void decideVessel(Vessel v, boolean approve) {
        String label = approve ? "Approve" : "Reject";
        String remarks = JOptionPane.showInputDialog(this,
                label + " vessel " + v.getVesselName() + " (IMO " + v.getImoNumber() + ")?\nRemarks"
                + (approve ? " (optional):" : " (required):"),
                label + " Vessel", JOptionPane.QUESTION_MESSAGE);
        if (remarks == null) {
            return; // cancelled
        }
        if (!approve && remarks.isBlank()) {
            JOptionPane.showMessageDialog(this, "Please enter a reason for rejecting.",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            if (approve) {
                vesselService.approveRegistration(v.getId(), remarks.trim());
            } else {
                vesselService.rejectRegistration(v.getId(), remarks.trim());
            }
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), label + " Vessel", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
        loadPendingVessels();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        approvalPanel = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        portPermPanel = new javax.swing.JPanel();
        roundedPanel5 = new JSwing.RoundedPanel();
        approvePermit = new javax.swing.JButton();
        rejectPermit = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        portApproval = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        vesselPermPanel = new javax.swing.JPanel();
        roundedPanel4 = new JSwing.RoundedPanel();
        approveVessel = new javax.swing.JButton();
        rejectShipReq = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        vesselPending = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();

        setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Central Approvals Hub");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        jTabbedPane1.setForeground(new java.awt.Color(0, 0, 102));
        jTabbedPane1.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N

        roundedPanel5.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel5.setMaximumSize(new java.awt.Dimension(323, 75));
        roundedPanel5.setMinimumSize(new java.awt.Dimension(323, 75));

        approvePermit.setBackground(new java.awt.Color(0, 0, 102));
        approvePermit.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        approvePermit.setForeground(new java.awt.Color(255, 255, 255));
        approvePermit.setText("           Approve Port");
        approvePermit.setBorder(null);
        approvePermit.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        approvePermit.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        approvePermit.addActionListener(this::approvePermitActionPerformed);

        rejectPermit.setBackground(new java.awt.Color(0, 0, 102));
        rejectPermit.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        rejectPermit.setForeground(new java.awt.Color(255, 255, 255));
        rejectPermit.setText("          Reject Request");
        rejectPermit.setBorder(null);
        rejectPermit.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        rejectPermit.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        rejectPermit.addActionListener(this::rejectPermitActionPerformed);

        jLabel8.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("Search:");

        jTextField2.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        jTextField2.setMaximumSize(new java.awt.Dimension(241, 42));
        jTextField2.setMinimumSize(new java.awt.Dimension(241, 42));
        jTextField2.setPreferredSize(new java.awt.Dimension(241, 42));
        jTextField2.addActionListener(this::jTextField2ActionPerformed);

        javax.swing.GroupLayout roundedPanel5Layout = new javax.swing.GroupLayout(roundedPanel5);
        roundedPanel5.setLayout(roundedPanel5Layout);
        roundedPanel5Layout.setHorizontalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(approvePermit, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(rejectPermit, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(107, Short.MAX_VALUE))
        );
        roundedPanel5Layout.setVerticalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(approvePermit, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rejectPermit, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        portApproval.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Port ID", "Port Name", "Capability / Spec", "Date Submitted", "Status"
            }
        ));
        jScrollPane2.setViewportView(portApproval);

        jLabel9.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("Pending Port Permits");

        javax.swing.GroupLayout portPermPanelLayout = new javax.swing.GroupLayout(portPermPanel);
        portPermPanel.setLayout(portPermPanelLayout);
        portPermPanelLayout.setHorizontalGroup(
            portPermPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(portPermPanelLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(portPermPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(portPermPanelLayout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(portPermPanelLayout.createSequentialGroup()
                        .addGroup(portPermPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2)
                            .addComponent(roundedPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(50, 50, 50))))
        );
        portPermPanelLayout.setVerticalGroup(
            portPermPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(portPermPanelLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(roundedPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Port Operating Permits", portPermPanel);

        roundedPanel4.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel4.setMaximumSize(new java.awt.Dimension(323, 75));
        roundedPanel4.setMinimumSize(new java.awt.Dimension(323, 75));

        approveVessel.setBackground(new java.awt.Color(0, 0, 102));
        approveVessel.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        approveVessel.setForeground(new java.awt.Color(255, 255, 255));
        approveVessel.setText("         Approve Vessel");
        approveVessel.setBorder(null);
        approveVessel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        approveVessel.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        approveVessel.addActionListener(this::approveVesselActionPerformed);

        rejectShipReq.setBackground(new java.awt.Color(0, 0, 102));
        rejectShipReq.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        rejectShipReq.setForeground(new java.awt.Color(255, 255, 255));
        rejectShipReq.setText("          Reject Request");
        rejectShipReq.setBorder(null);
        rejectShipReq.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        rejectShipReq.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        rejectShipReq.addActionListener(this::rejectShipReqActionPerformed);

        jTextField1.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        jTextField1.setMaximumSize(new java.awt.Dimension(241, 42));
        jTextField1.setMinimumSize(new java.awt.Dimension(241, 42));
        jTextField1.setPreferredSize(new java.awt.Dimension(241, 42));
        jTextField1.addActionListener(this::jTextField1ActionPerformed);

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Search:");

        javax.swing.GroupLayout roundedPanel4Layout = new javax.swing.GroupLayout(roundedPanel4);
        roundedPanel4.setLayout(roundedPanel4Layout);
        roundedPanel4Layout.setHorizontalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(45, 45, 45)
                .addComponent(approveVessel, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(rejectShipReq, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 73, Short.MAX_VALUE)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(107, 107, 107))
        );
        roundedPanel4Layout.setVerticalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(approveVessel, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rejectShipReq, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        vesselPending.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "IMO Number", "Vessel Name", "Carrier / Line", "Max Cap (Tons)", "Requested By"
            }
        ));
        jScrollPane1.setViewportView(vesselPending);

        jLabel6.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Pending Vessels");

        javax.swing.GroupLayout vesselPermPanelLayout = new javax.swing.GroupLayout(vesselPermPanel);
        vesselPermPanel.setLayout(vesselPermPanelLayout);
        vesselPermPanelLayout.setHorizontalGroup(
            vesselPermPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(vesselPermPanelLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(vesselPermPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(vesselPermPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(roundedPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane1)))
                .addContainerGap(50, Short.MAX_VALUE))
        );
        vesselPermPanelLayout.setVerticalGroup(
            vesselPermPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(vesselPermPanelLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addComponent(roundedPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Vessel Registrations", vesselPermPanel);

        javax.swing.GroupLayout approvalPanelLayout = new javax.swing.GroupLayout(approvalPanel);
        approvalPanel.setLayout(approvalPanelLayout);
        approvalPanelLayout.setHorizontalGroup(
            approvalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jTabbedPane1)
        );
        approvalPanelLayout.setVerticalGroup(
            approvalPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(approvalPanelLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 584, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        add(approvalPanel, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        loadPendingVessels();
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        loadPendingPorts();
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void approvePermitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approvePermitActionPerformed
        PermitReview r = selectedReview();
        if (r != null)
            decide(r, true);
    }//GEN-LAST:event_approvePermitActionPerformed

    private void rejectPermitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rejectPermitActionPerformed
        PermitReview r = selectedReview();
        if (r != null)
            decide(r, false);
    }//GEN-LAST:event_rejectPermitActionPerformed

    private void approveVesselActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_approveVesselActionPerformed
        Vessel v = selectedVessel();
        if (v != null) {
            decideVessel(v, true);
        }
    }//GEN-LAST:event_approveVesselActionPerformed

    private void rejectShipReqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rejectShipReqActionPerformed
        Vessel v = selectedVessel();
        if (v != null) {
            decideVessel(v, false);
        }
    }//GEN-LAST:event_rejectShipReqActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel approvalPanel;
    private javax.swing.JButton approvePermit;
    private javax.swing.JButton approveVessel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTable portApproval;
    private javax.swing.JPanel portPermPanel;
    private javax.swing.JButton rejectPermit;
    private javax.swing.JButton rejectShipReq;
    private JSwing.RoundedPanel roundedPanel4;
    private JSwing.RoundedPanel roundedPanel5;
    private javax.swing.JTable vesselPending;
    private javax.swing.JPanel vesselPermPanel;
    // End of variables declaration//GEN-END:variables
}
