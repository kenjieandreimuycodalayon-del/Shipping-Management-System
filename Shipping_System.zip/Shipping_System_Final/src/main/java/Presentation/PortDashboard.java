/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import UI.DashboardUI;
import Model.Cargo;
import Model.PermitApplication;
import Model.Port;
import Model.User;
import Service.CargoService;
import Service.MessageService;
import Service.PartnershipService;
import Service.PortService;
import UI.MainPanelOverhaul;
import Util.Session;
import java.awt.Color;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.HierarchyEvent;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Kenji
 */
public class PortDashboard extends javax.swing.JPanel {

    // ===== 2) FIELDS + CONSTRUCTOR: REPLACE the existing PortDashboard() constructor with this =====
    private static final int RECENT_LIMIT = 10;

    private final CargoService cargoService = new CargoService();
    private final PartnershipService partnershipService = new PartnershipService();
    private final PortService portService = new PortService();

    /**
     * Creates new form PortDashboard
     */
    public PortDashboard() {
        initComponents();
        applyModernStyle();
        MainPanelOverhaul.styleIconButton(portMsg);

        addHierarchyListener(e -> {
            if ((e.getChangeFlags() & HierarchyEvent.SHOWING_CHANGED) != 0 && isShowing()) {
                loadStats();
            }
        });
    }

    private void applyModernStyle() {
        DashboardUI.stylePage(portPanel, jPanel2, jLabel1, jPanel3);
        roundedPanel4.setBackground(portPanel.getBackground());
        DashboardUI.styleButton(refreshButton, false);
        DashboardUI.styleButton(permitStat, true);
        DashboardUI.styleStatCard(roundedPanel1, jLabel2, jTextField3, DashboardUI.BLUE);   // Active Shipments
        DashboardUI.styleStatCard(roundedPanel2, jLabel3, jTextField1, DashboardUI.GREEN);  // Active Partnerships
        DashboardUI.styleStatCard(roundedPanel3, jLabel4, jTextField2, DashboardUI.AMBER);  // Permit Status
        DashboardUI.styleSection(jLabel5);
        portDashScroll.setBorder(null);
        DashboardUI.styleTable(portDashTable, 4, 2);   // status badges in col 4, weights right-aligned
    }

    private String codeOf(Port p, int portId) {
        if (p == null) {
            return "#" + portId;
        }
        return p.getPortCode() != null ? p.getPortCode() : "#" + p.getId();
    }

    private String show(Object value) {
        return value == null || value.toString().isBlank() ? "—" : value.toString();
    }

    private void loadStats() {
        Integer me = Session.getPortId();
        if (me == null) {
            return;
        }
        try {
            Map<Integer, Port> ports = new HashMap<>();
            for (Port p : portService.findAll()) {
                ports.put(p.getId(), p);
            }
            jTextField3.setText(cargoService.countActiveByCreator(me) + " / " + cargoService.maxActiveShipments(me));
            jTextField1.setText(String.valueOf(partnershipService.activeFor(me).size()));

            Port mine = ports.get(me);
            if (mine != null) {
                String status = mine.getStatus().name();
                jTextField2.setText(status);

                Color statusCol = DashboardUI.statusColor(status);
                String hexColor = String.format("#%02x%02x%02x", statusCol.getRed(), statusCol.getGreen(), statusCol.getBlue());

                jTextField2.setDisabledTextColor(statusCol);
                jTextField2.setForeground(statusCol);
                jTextField2.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE,
                        "border: 0,0,0,0; "
                        + "background: null; "
                        + "disabledBackground: null; "
                        + "inactiveBackground: null; "
                        + "disabledForeground: " + hexColor + "; "
                        + "inactiveForeground: " + hexColor + "; "
                        + "foreground: " + hexColor);
            } else {
                jTextField2.setText("—");
            }
            // Recent Cargo Movements
            List<Cargo> recent = cargoService.recentForPort(me, RECENT_LIMIT);
            Object[][] data = new Object[recent.size()][5];
            for (int i = 0; i < recent.size(); i++) {
                Cargo c = recent.get(i);
                data[i][0] = c.getCargoCode();
                data[i][1] = codeOf(ports.get(c.getDestinationPortId()), c.getDestinationPortId());
                data[i][2] = String.format("%,d", (long) c.getWeightKg());
                data[i][3] = c.getProducts() == null ? "" : c.getProducts().size() + " item(s)";
                data[i][4] = c.getStatus();
            }
            portDashTable.setModel(new DefaultTableModel(data,
                    new String[]{"Cargo ID", "Destination Port", "Weight (kg)", "Products", "Status"}) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            });
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load dashboard: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateUnreadTooltip() {
        User u = Session.getCurrentUser();
        if (u == null) {
            return;
        }
        try {
            int n = new MessageService().unreadCount(u.getId());
            portMsg.setToolTipText(n > 0 ? "Messages (" + n + " unread)" : "Messages");
        } catch (SQLException ignored) {
        }
    }

    private void showPermitStatus() {
        Integer me = Session.getPortId();
        if (me == null) {
            return;
        }
        try {
            Port port = portService.findById(me);
            if (port == null) {
                JOptionPane.showMessageDialog(this, "Port record not found.",
                        "Permit Status", JOptionPane.WARNING_MESSAGE);
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.append("Status: ").append(port.getStatus());
            sb.append("\nPermit No: ").append(show(port.getPermitNo()));
            sb.append("\nPermit Authority: ").append(show(port.getPermitAuthority()));
            sb.append("\nExpiration Date: ").append(show(port.getExpirationDate()));

            boolean warn = port.getStatus() != Port.Status.ACTIVE;
            LocalDate expiry = port.getExpirationDate();
            if (expiry != null) {
                long days = ChronoUnit.DAYS.between(LocalDate.now(), expiry);
                if (days < 0) {
                    sb.append("\n\n! Your permit expired ").append(-days).append(" day(s) ago. Please renew it.");
                    warn = true;
                } else if (days <= 30) {
                    sb.append("\n\n! Your permit expires in ").append(days).append(" day(s). Please renew it.");
                    warn = true;
                } else {
                    sb.append(" (").append(days).append(" days left)");
                }
            }

            List<PermitApplication> history = portService.permitHistory(me); // newest first
            if (!history.isEmpty() && history.get(0).getAdminRemarks() != null
                    && !history.get(0).getAdminRemarks().isBlank()) {
                sb.append("\n\nAdmin Remarks: ").append(history.get(0).getAdminRemarks());
            }
            JOptionPane.showMessageDialog(this, sb.toString(), "Permit Status",
                    warn ? JOptionPane.WARNING_MESSAGE : JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        portPanel = new javax.swing.JPanel();
        roundedPanel1 = new JSwing.RoundedPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextField3 = new javax.swing.JTextField();
        roundedPanel2 = new JSwing.RoundedPanel();
        jLabel3 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        roundedPanel3 = new JSwing.RoundedPanel();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        portMsg = new javax.swing.JButton();
        roundedPanel4 = new JSwing.RoundedPanel();
        refreshButton = new javax.swing.JButton();
        permitStat = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        portDashScroll = new javax.swing.JScrollPane();
        portDashTable = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();

        setMaximumSize(new java.awt.Dimension(1060, 650));
        setMinimumSize(new java.awt.Dimension(1060, 650));
        setPreferredSize(new java.awt.Dimension(1060, 650));
        setLayout(new java.awt.BorderLayout());

        portPanel.setBackground(new java.awt.Color(244, 246, 249));

        roundedPanel1.setBackground(new java.awt.Color(11, 29, 81));
        roundedPanel1.setMaximumSize(new java.awt.Dimension(300, 130));
        roundedPanel1.setMinimumSize(new java.awt.Dimension(300, 130));
        roundedPanel1.setPreferredSize(new java.awt.Dimension(300, 130));

        jLabel2.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText(" Active Shipments");

        jTextField3.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 36)); // NOI18N
        jTextField3.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField3.setEnabled(false);

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(37, Short.MAX_VALUE))
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(26, Short.MAX_VALUE))
        );

        roundedPanel2.setBackground(new java.awt.Color(11, 29, 81));
        roundedPanel2.setMaximumSize(new java.awt.Dimension(300, 130));
        roundedPanel2.setMinimumSize(new java.awt.Dimension(300, 130));

        jLabel3.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText(" Active Partnerships");

        jTextField1.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 36)); // NOI18N
        jTextField1.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField1.setEnabled(false);

        javax.swing.GroupLayout roundedPanel2Layout = new javax.swing.GroupLayout(roundedPanel2);
        roundedPanel2.setLayout(roundedPanel2Layout);
        roundedPanel2Layout.setHorizontalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel3))
                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        roundedPanel2Layout.setVerticalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        roundedPanel3.setBackground(new java.awt.Color(11, 29, 81));
        roundedPanel3.setMaximumSize(new java.awt.Dimension(300, 130));
        roundedPanel3.setMinimumSize(new java.awt.Dimension(300, 130));

        jLabel4.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText(" Permit Status");

        jTextField2.setFont(new java.awt.Font("Franklin Gothic Demi", 0, 36)); // NOI18N
        jTextField2.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        jTextField2.setEnabled(false);

        javax.swing.GroupLayout roundedPanel3Layout = new javax.swing.GroupLayout(roundedPanel3);
        roundedPanel3.setLayout(roundedPanel3Layout);
        roundedPanel3Layout.setHorizontalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, roundedPanel3Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );
        roundedPanel3Layout.setVerticalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel4)
                .addGap(18, 18, 18)
                .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setMaximumSize(new java.awt.Dimension(1060, 60));
        jPanel2.setMinimumSize(new java.awt.Dimension(1060, 60));
        jPanel2.setPreferredSize(new java.awt.Dimension(1060, 60));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Port Dashboard");

        portMsg.setBackground(new java.awt.Color(0, 0, 83));
        portMsg.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        portMsg.setForeground(new java.awt.Color(255, 255, 255));
        portMsg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/mesg (1).png"))); // NOI18N
        portMsg.setText("  ");
        portMsg.setBorder(null);
        portMsg.setContentAreaFilled(false);
        portMsg.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        portMsg.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        portMsg.setOpaque(true);
        portMsg.addActionListener(this::portMsgActionPerformed);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(portMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(portMsg, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(3, Short.MAX_VALUE))
        );

        roundedPanel4.setBackground(new java.awt.Color(255, 255, 255));

        refreshButton.setBackground(new java.awt.Color(0, 0, 102));
        refreshButton.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        refreshButton.setForeground(new java.awt.Color(255, 255, 255));
        refreshButton.setText("                  Refresh Stats");
        refreshButton.setBorder(null);
        refreshButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        refreshButton.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        refreshButton.addActionListener(this::refreshButtonActionPerformed);

        permitStat.setBackground(new java.awt.Color(0, 0, 102));
        permitStat.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        permitStat.setForeground(new java.awt.Color(255, 255, 255));
        permitStat.setText("            Check Permit Status");
        permitStat.setBorder(null);
        permitStat.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        permitStat.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        permitStat.addActionListener(this::permitStatActionPerformed);

        javax.swing.GroupLayout roundedPanel4Layout = new javax.swing.GroupLayout(roundedPanel4);
        roundedPanel4.setLayout(roundedPanel4Layout);
        roundedPanel4Layout.setHorizontalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(refreshButton, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(permitStat, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel4Layout.setVerticalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(refreshButton, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(permitStat, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        jPanel3.setBackground(new java.awt.Color(0, 0, 102));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 8, Short.MAX_VALUE)
        );

        portDashTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Cargo ID", "Destination Port", "Weight (kg)", "Products", "Status"
            }
        ));
        portDashScroll.setViewportView(portDashTable);
        if (portDashTable.getColumnModel().getColumnCount() > 0) {
            portDashTable.getColumnModel().getColumn(0).setMinWidth(150);
            portDashTable.getColumnModel().getColumn(0).setPreferredWidth(150);
            portDashTable.getColumnModel().getColumn(0).setMaxWidth(150);
            portDashTable.getColumnModel().getColumn(2).setMinWidth(150);
            portDashTable.getColumnModel().getColumn(2).setPreferredWidth(150);
            portDashTable.getColumnModel().getColumn(2).setMaxWidth(150);
            portDashTable.getColumnModel().getColumn(3).setMinWidth(150);
            portDashTable.getColumnModel().getColumn(3).setPreferredWidth(150);
            portDashTable.getColumnModel().getColumn(3).setMaxWidth(150);
        }

        jLabel5.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("  Recent Cargo Movements");

        javax.swing.GroupLayout portPanelLayout = new javax.swing.GroupLayout(portPanel);
        portPanel.setLayout(portPanelLayout);
        portPanelLayout.setHorizontalGroup(
            portPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(portPanelLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(portPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(portPanelLayout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(portPanelLayout.createSequentialGroup()
                        .addGroup(portPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(portDashScroll)
                            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(roundedPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(portPanelLayout.createSequentialGroup()
                                .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
                                .addComponent(roundedPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(15, 15, 15)
                                .addComponent(roundedPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(50, 50, 50))))
        );
        portPanelLayout.setVerticalGroup(
            portPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(portPanelLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addGroup(portPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(roundedPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                    .addComponent(roundedPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(roundedPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(roundedPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(portDashScroll, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        add(portPanel, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void refreshButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refreshButtonActionPerformed
        loadStats();
    }//GEN-LAST:event_refreshButtonActionPerformed

    private void permitStatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_permitStatActionPerformed
        showPermitStatus();
    }//GEN-LAST:event_permitStatActionPerformed

    private void portMsgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_portMsgActionPerformed
        new MessagesDialog(SwingUtilities.getWindowAncestor(this)).setVisible(true);
        updateUnreadTooltip();
    }//GEN-LAST:event_portMsgActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JButton permitStat;
    private javax.swing.JScrollPane portDashScroll;
    private javax.swing.JTable portDashTable;
    private javax.swing.JButton portMsg;
    private javax.swing.JPanel portPanel;
    private javax.swing.JButton refreshButton;
    private JSwing.RoundedPanel roundedPanel1;
    private JSwing.RoundedPanel roundedPanel2;
    private JSwing.RoundedPanel roundedPanel3;
    private JSwing.RoundedPanel roundedPanel4;
    // End of variables declaration//GEN-END:variables
}
