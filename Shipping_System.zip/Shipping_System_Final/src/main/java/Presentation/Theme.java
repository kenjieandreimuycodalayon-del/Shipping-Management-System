package Presentation;


import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;

/**
 * Central look & feel for the app. Call Theme.apply(this) once right after
 * initComponents() in any panel/dialog. It restyles components at runtime, so the
 * NetBeans .form files and generated code stay untouched and in sync.
 */
public final class Theme {

    public static final Color NAVY = new Color(11, 29, 81);
    public static final Color NAVY_HOVER = new Color(30, 52, 120);
    public static final Color NAVY_PRESSED = new Color(6, 18, 56);
    public static final Color BG = new Color(244, 246, 249);
    public static final Color CARD = Color.WHITE;
    public static final Color BORDER = new Color(218, 223, 232);
    public static final Color TEXT = new Color(30, 41, 59);
    public static final Color MUTED = new Color(100, 116, 139);
    public static final Color ROW_ALT = new Color(247, 249, 252);
    public static final Color SELECTION = new Color(219, 230, 255);

    private static final String FONT = "Segoe UI";

    private Theme() {
    }

    public static Font font(int style, int size) {
        return new Font(FONT, style, size);
    }

    /** Restyle everything inside root (recursively). */
    public static void apply(Container root) {
        for (Component c : root.getComponents()) {
            if (c instanceof JButton b) {
                styleButton(b);
            } else if (c instanceof JScrollPane sp) {
                styleScroll(sp);
                if (sp.getViewport().getView() instanceof JTable t) {
                    styleTable(t);
                }
            } else if (c instanceof JComboBox<?> cb) {
                styleCombo(cb);
            } else if (c instanceof JTextField tf) {
                if (!tf.isEnabled() && tf.getFont().getSize() >= 30) {
                    styleStatValue(tf);
                } else {
                    styleField(tf);
                }
            } else if (c instanceof JLabel l) {
                styleLabel(l);
            }
            if (c instanceof Container child && !(c instanceof JScrollPane) && !(c instanceof JComboBox)
                    && !(c instanceof JButton)) {
                apply(child);
            }
        }
    }

    private static void styleLabel(JLabel l) {
        Font old = l.getFont();
        if (old != null) {
            l.setFont(font(old.getStyle() & ~Font.ITALIC, old.getSize()));
        }
        Color fg = l.getForeground();
        if (Color.WHITE.equals(fg)) {
            l.setText(l.getText().trim());
        }
    }

    // ---------- buttons ----------
    public static void styleButton(JButton b) {
        b.setText(b.getText().trim());
        b.setHorizontalAlignment(SwingConstants.CENTER);
        b.setFont(font(Font.BOLD, 14));
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createEmptyBorder(8, 16, 8, 16));
        b.setContentAreaFilled(false);
        b.setOpaque(false);
        b.setRolloverEnabled(true);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setUI(new RoundedButtonUI());
    }

    private static final class RoundedButtonUI extends BasicButtonUI {
        @Override
        public void paint(Graphics g, JComponent c) {
            AbstractButton b = (AbstractButton) c;
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            ButtonModel m = b.getModel();
            Color fill = !b.isEnabled() ? new Color(160, 168, 186)
                    : m.isPressed() ? NAVY_PRESSED
                    : m.isRollover() ? NAVY_HOVER : NAVY;
            g2.setColor(fill);
            g2.fillRoundRect(0, 0, c.getWidth(), c.getHeight(), 12, 12);
            g2.dispose();
            super.paint(g, c);
        }
    }

    // ---------- inputs ----------
    public static void styleField(JTextField tf) {
        tf.setFont(font(Font.PLAIN, 14));
        tf.setForeground(TEXT);
        tf.setBorder(inputBorder());
    }

    public static void styleCombo(JComboBox<?> cb) {
        cb.setFont(font(Font.PLAIN, 14));
        cb.setBackground(Color.WHITE);
        cb.setForeground(TEXT);
        cb.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private static Border inputBorder() {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER, 1, true),
                BorderFactory.createEmptyBorder(6, 10, 6, 10));
    }

    /** Big number shown inside the navy stat cards. */
    public static void styleStatValue(JTextField tf) {
        tf.setOpaque(false);
        tf.setBorder(BorderFactory.createEmptyBorder());
        tf.setFont(font(Font.BOLD, 34));
        tf.setDisabledTextColor(Color.WHITE);
        tf.setForeground(Color.WHITE);
        tf.setHorizontalAlignment(SwingConstants.LEFT);
        tf.setEditable(false);
    }

    // ---------- tables ----------
    private static void styleScroll(JScrollPane sp) {
        sp.setBorder(BorderFactory.createLineBorder(BORDER));
        sp.getViewport().setBackground(Color.WHITE);
        sp.getVerticalScrollBar().setUnitIncrement(16);
    }

    public static void styleTable(JTable t) {
        t.setFont(font(Font.PLAIN, 14));
        t.setForeground(TEXT);
        t.setRowHeight(34);
        t.setShowGrid(false);
        t.setShowHorizontalLines(true);
        t.setGridColor(new Color(236, 239, 245));
        t.setIntercellSpacing(new Dimension(0, 1));
        t.setSelectionBackground(SELECTION);
        t.setSelectionForeground(TEXT);
        t.setFillsViewportHeight(true);
        t.setDefaultRenderer(Object.class, new RowRenderer());

        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setPreferredSize(new Dimension(h.getPreferredSize().width, 38));
        h.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean sel,
                    boolean focus, int row, int col) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(table, value, false, false, row, col);
                l.setBackground(NAVY);
                l.setForeground(Color.WHITE);
                l.setFont(font(Font.BOLD, 13));
                l.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
                l.setHorizontalAlignment(SwingConstants.LEFT);
                l.setOpaque(true);
                return l;
            }
        });
    }

    private static final class RowRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean sel,
                boolean focus, int row, int col) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(table, value, sel, false, row, col);
            l.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
            l.setBackground(sel ? SELECTION : (row % 2 == 0 ? Color.WHITE : ROW_ALT));
            l.setForeground(TEXT);
            l.setFont(font(Font.PLAIN, 14));
            if (value instanceof Enum<?> e) {
                l.setText(e.name().replace('_', ' '));
                l.setFont(font(Font.BOLD, 13));
                l.setForeground(statusColor(e.name()));
            }
            return l;
        }
    }

    private static Color statusColor(String s) {
        switch (s.toUpperCase()) {
            case "ACTIVE": case "RECEIVED": case "APPROVED": case "DELIVERED": case "ACCEPTED":
                return new Color(22, 128, 61);
            case "PENDING": case "IN_TRANSIT": case "SHIPPED": case "PROCESSING":
                return new Color(180, 100, 0);
            case "CANCELLED": case "RETURNED": case "TERMINATED": case "REJECTED": case "EXPIRED":
            case "SUSPENDED":
                return new Color(185, 28, 28);
            default:
                return MUTED;
        }
    }
}