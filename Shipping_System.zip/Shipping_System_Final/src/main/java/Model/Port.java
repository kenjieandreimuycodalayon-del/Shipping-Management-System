package Model;

import java.time.LocalDate;

public class Port {

    public enum Status { PENDING, ACTIVE, SUSPENDED, TERMINATED }

    private int id;
    private String portCode;
    private String portName;
    private String registeredName;
    private String primaryCapability;
    private Status status;
    private int dispatchLimit;
    private int cargoItemLimit;
    private String permitAuthority;
    private String permitNo;
    private LocalDate submittedDate;
    private LocalDate approvedDate;
    private LocalDate expirationDate;
    private LocalDate lastRenewal;

    public Port() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getPortCode() { return portCode; }
    public void setPortCode(String portCode) { this.portCode = portCode; }

    public String getPortName() { return portName; }
    public void setPortName(String portName) { this.portName = portName; }

    public String getRegisteredName() { return registeredName; }
    public void setRegisteredName(String registeredName) { this.registeredName = registeredName; }

    public String getPrimaryCapability() { return primaryCapability; }
    public void setPrimaryCapability(String primaryCapability) { this.primaryCapability = primaryCapability; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public int getDispatchLimit() { return dispatchLimit; }
    public void setDispatchLimit(int dispatchLimit) { this.dispatchLimit = dispatchLimit; }

    public int getCargoItemLimit() { return cargoItemLimit; }
    public void setCargoItemLimit(int cargoItemLimit) { this.cargoItemLimit = cargoItemLimit; }

    public String getPermitAuthority() { return permitAuthority; }
    public void setPermitAuthority(String permitAuthority) { this.permitAuthority = permitAuthority; }

    public String getPermitNo() { return permitNo; }
    public void setPermitNo(String permitNo) { this.permitNo = permitNo; }

    public LocalDate getSubmittedDate() { return submittedDate; }
    public void setSubmittedDate(LocalDate submittedDate) { this.submittedDate = submittedDate; }

    public LocalDate getApprovedDate() { return approvedDate; }
    public void setApprovedDate(LocalDate approvedDate) { this.approvedDate = approvedDate; }

    public LocalDate getExpirationDate() { return expirationDate; }
    public void setExpirationDate(LocalDate expirationDate) { this.expirationDate = expirationDate; }

    public LocalDate getLastRenewal() { return lastRenewal; }
    public void setLastRenewal(LocalDate lastRenewal) { this.lastRenewal = lastRenewal; }

    @Override
    public String toString() {
        return (portCode != null ? portCode : "#" + id) + " - " + portName;
    }
}