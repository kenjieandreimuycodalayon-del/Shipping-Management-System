package UI;

import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

/**
 * Shared building blocks so every JDialog has the same header band, card,
 * form layout, buttons and footer. Put this next to TestUI in the UI package.
 */
public final class DialogKit {

    public static final Color NAVY = new Color(0, 0, 102);
    public static final Color PAGE_BG = new Color(244, 246, 249);
    public static final Color LINE = new Color(218, 222, 230);
    public static final Color MUTED = new Color(108, 117, 125);
    public static final Color TEXT = new Color(33, 37, 41);
    private static final Color HEADER_SUB = new Color(200, 205, 235);

    private DialogKit() {
    }

    // ---------------------------------------------------------------- shell

    /** Header on top, body in the middle, footer at the bottom. */
    public static void assemble(JDialog d, JComponent header, JComponent body, JComponent footer) {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(PAGE_BG);
        root.add(header, BorderLayout.NORTH);
        root.add(body, BorderLayout.CENTER);
        root.add(footer, BorderLayout.SOUTH);
        d.setContentPane(root);
    }

    /** Pack, enforce a minimum width, fix the size and centre on the owner. */
    public static void finish(JDialog d, Component owner, int minWidth) {
        d.pack();
        d.setSize(Math.max(d.getWidth(), minWidth), d.getHeight());
        d.setResizable(false);
        d.setLocationRelativeTo(owner);
    }

    public static void escToClose(JDialog d) {
        d.getRootPane().registerKeyboardAction(e -> d.dispose(),
                KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0),
                JComponent.WHEN_IN_FOCUSED_WINDOW);
    }

    /** Navy band: title + optional subtitle on the left, optional badge on the right. */
    public static JPanel header(String title, String subtitle, String badge) {
        JPanel p = new JPanel(new BorderLayout(16, 0));
        p.setBackground(NAVY);
        p.setBorder(new EmptyBorder(18, 28, 18, 28));

        JPanel texts = new JPanel();
        texts.setLayout(new BoxLayout(texts, BoxLayout.Y_AXIS));
        texts.setOpaque(false);
        JLabel t = new JLabel(title);
        t.setFont(TemplateUI.font(Font.BOLD, 22));
        t.setForeground(Color.WHITE);
        texts.add(t);
        if (subtitle != null && !subtitle.isBlank()) {
            JLabel s = new JLabel(subtitle);
            s.setFont(TemplateUI.font(Font.PLAIN, 13));
            s.setForeground(HEADER_SUB);
            texts.add(Box.createVerticalStrut(3));
            texts.add(s);
        }
        p.add(texts, BorderLayout.WEST);

        if (badge != null && !badge.isBlank()) {
            JPanel wrap = new JPanel(new GridBagLayout());
            wrap.setOpaque(false);
            wrap.add(new Badge(badge));
            p.add(wrap, BorderLayout.EAST);
        }
        return p;
    }

    /** White footer with a top divider. Optional left component, buttons on the right. */
    public static JPanel footer(JComponent left, JButton... buttons) {
        JPanel p = new JPanel(new BorderLayout(12, 0));
        p.setBackground(Color.WHITE);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, LINE),
                new EmptyBorder(14, 28, 14, 28)));
        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);
        for (JButton b : buttons) {
            right.add(b);
        }
        if (left != null) {
            p.add(left, BorderLayout.WEST);
        }
        p.add(right, BorderLayout.EAST);
        return p;
    }

    /** Padding around the card(s) in the middle of the dialog. */
    public static JPanel body(JComponent content) {
        JPanel p = new JPanel(new BorderLayout());
        p.setOpaque(false);
        p.setBorder(new EmptyBorder(22, 28, 22, 28));
        p.add(content, BorderLayout.CENTER);
        return p;
    }

    /** Rounded white card with an optional heading (pass null for none). */
    public static JPanel card(String heading) {
        JPanel p = new JPanel(new BorderLayout(0, 14));
        p.putClientProperty(FlatClientProperties.STYLE, "arc: 16; background: #ffffff");
        p.setBorder(new EmptyBorder(20, 24, 20, 24));
        if (heading != null) {
            JLabel h = new JLabel(heading);
            h.setFont(TemplateUI.font(Font.BOLD, 16));
            h.setForeground(NAVY);
            p.add(h, BorderLayout.NORTH);
        }
        return p;
    }

    // -------------------------------------------------------------- buttons

    private static final String BTN = "font: bold; arc: 12; focusWidth: 0; margin: 9,22,9,22; ";

    public static JButton primary(String text) {
        return button(text, BTN + "background: #000066; foreground: #ffffff; borderWidth: 0; "
                + "hoverBackground: #1e1e8c; pressedBackground: #00004a; "
                + "disabledBackground: #c5c9d6; disabledText: #ffffff");
    }

    public static JButton secondary(String text) {
        return button(text, BTN + "background: #ffffff; foreground: #000066; borderColor: #000066; "
                + "hoverBackground: #eef0f8; pressedBackground: #dde1f0");
    }

    public static JButton danger(String text) {
        return button(text, BTN + "background: #b42828; foreground: #ffffff; borderWidth: 0; "
                + "hoverBackground: #c93a3a; pressedBackground: #962020");
    }

    private static JButton button(String text, String style) {
        JButton b = new JButton(text);
        b.putClientProperty(FlatClientProperties.STYLE, style);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    // ---------------------------------------------------------------- forms

    /** Empty transparent GridBag panel to fill with addField / infoRow. */
    public static JPanel form() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setOpaque(false);
        return p;
    }

    /**
     * Label above a field in a 2-column grid. row = 0,1,2...; col = 0 or 1;
     * span = 1 or 2. Text fields and combo boxes are styled automatically.
     */
    public static void addField(JPanel form, int row, int col, int span, String label, JComponent field) {
        if (field instanceof JTextField) {
            TemplateUI.styleTextField((JTextField) field, null);
        } else if (field instanceof JComboBox) {
            TemplateUI.styleComboBox((JComboBox<?>) field);
        }
        JLabel l = new JLabel(label);
        l.setFont(TemplateUI.font(Font.BOLD, 13));
        l.setForeground(TEXT);

        int left = col == 0 ? 0 : 8;
        int right = (col + span >= 2) ? 0 : 8;

        GridBagConstraints c = new GridBagConstraints();
        c.gridx = col;
        c.gridy = row * 2;
        c.gridwidth = span;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.anchor = GridBagConstraints.WEST;
        c.insets = new Insets(0, left, 5, right);
        form.add(l, c);

        c.gridy = row * 2 + 1;
        c.insets = new Insets(0, left, 16, right);
        form.add(field, c);
    }

    /** Read-only "Label    Value" row. Returns the value label so callers can colour it. */
    public static JLabel infoRow(JPanel rows, int row, String label, String value) {
        GridBagConstraints c = new GridBagConstraints();
        c.gridy = row;
        c.anchor = GridBagConstraints.NORTHWEST;

        JLabel l = new JLabel(label);
        l.setFont(TemplateUI.font(Font.BOLD, 13));
        l.setForeground(MUTED);
        l.setPreferredSize(new Dimension(130, l.getPreferredSize().height));
        c.gridx = 0;
        c.insets = new Insets(7, 0, 7, 16);
        rows.add(l, c);

        String text = value == null || value.isBlank() ? "\u2014" : value;
        JLabel v = new JLabel(text);
        v.setFont(TemplateUI.font(Font.PLAIN, 14));
        v.setForeground(TEXT);
        v.setToolTipText(text);
        c.gridx = 1;
        c.weightx = 1;
        c.fill = GridBagConstraints.HORIZONTAL;
        c.insets = new Insets(7, 0, 7, 0);
        rows.add(v, c);
        return v;
    }

    // ------------------------------------------------------ document preview

    /** Card showing an uploaded image (or a message) with a "View Full Size" button. */
    public static JPanel documentCard(JDialog owner, String heading, BufferedImage image,
            String message, String fullSizeTitle) {
        JPanel card = card(heading);

        JLabel preview = new JLabel();
        preview.setHorizontalAlignment(SwingConstants.CENTER);
        if (image != null) {
            double scale = Math.min(1.0, Math.min(380.0 / image.getWidth(), 330.0 / image.getHeight()));
            int w = (int) (image.getWidth() * scale);
            int h = (int) (image.getHeight() * scale);
            preview.setIcon(new ImageIcon(image.getScaledInstance(w, h, Image.SCALE_SMOOTH)));
        } else {
            preview.setText(message);
            preview.setFont(TemplateUI.font(Font.PLAIN, 14));
            preview.setForeground(MUTED);
        }
        JScrollPane scroll = new JScrollPane(preview);
        scroll.setBorder(BorderFactory.createLineBorder(LINE));
        card.add(scroll, BorderLayout.CENTER);

        if (image != null) {
            JButton full = secondary("View Full Size");
            full.addActionListener(e -> showFullSize(owner, fullSizeTitle, image));
            JPanel south = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
            south.setOpaque(false);
            south.add(full);
            card.add(south, BorderLayout.SOUTH);
        }
        return card;
    }

    private static void showFullSize(JDialog owner, String title, BufferedImage image) {
        JDialog d = new JDialog(owner, title, true);
        d.add(new JScrollPane(new JLabel(new ImageIcon(image))));
        d.setSize(900, 700);
        d.setLocationRelativeTo(owner);
        escToClose(d);
        d.setVisible(true);
    }

    // ---------------------------------------------------------------- badge

    private static final class Badge extends JLabel {

        Badge(String text) {
            super(text, SwingConstants.CENTER);
            setFont(TemplateUI.font(Font.BOLD, 13));
            setForeground(Color.WHITE);
            setBorder(new EmptyBorder(6, 14, 6, 14));
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(255, 255, 255, 40));
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
