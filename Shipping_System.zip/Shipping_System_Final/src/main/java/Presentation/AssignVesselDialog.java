package Presentation;

import Model.Cargo;
import Model.Vessel;
import UI.DialogKit;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

/**
 * Backs DispatchQueue -> "Assign Vessel & Dispatch" and "Update Route / ETA".
 * It only collects and checks the input; the panel calls CargoService.
 */
public class AssignVesselDialog extends JDialog {

    private final JComboBox<Vessel> vesselBox = new JComboBox<>();
    private final JTextField departureField = new JTextField(14);
    private final JTextField etaField = new JTextField(14);

    private final Cargo cargo;
    private final boolean updateMode;
    private Vessel vessel;
    private LocalDate departure;
    private LocalDate eta;
    private boolean confirmed = false;

    public AssignVesselDialog(Frame owner, Cargo cargo, List<Vessel> vessels, boolean updateMode) {
        super(owner, updateMode ? "Update Route / ETA" : "Assign Vessel & Dispatch", true);
        this.cargo = cargo;
        this.updateMode = updateMode;
        for (Vessel v : vessels) {
            vesselBox.addItem(v);
        }
        buildUI();
        prefill();
        DialogKit.finish(this, owner, 520);
    }

    private void buildUI() {
        JPanel header = DialogKit.header(
                updateMode ? "Update Route / ETA" : "Assign Vessel & Dispatch",
                "Cargo " + cargo.getCargoCode() + "  \u2022  " + cargo.getWeightKg() + " kg", null);

        departureField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "yyyy-MM-dd");
        etaField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "yyyy-MM-dd");

        JPanel form = DialogKit.form();
        DialogKit.addField(form, 0, 0, 2, "Vessel", vesselBox);
        DialogKit.addField(form, 1, 0, 1, "Departure Date", departureField);
        DialogKit.addField(form, 1, 1, 1, "Estimated ETA", etaField);

        JPanel card = DialogKit.card(null);
        card.add(form, BorderLayout.CENTER);

        JButton submit = DialogKit.primary(updateMode ? "Save Changes" : "Dispatch Cargo");
        submit.addActionListener(e -> onSubmit());
        JButton cancel = DialogKit.secondary("Cancel");
        cancel.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(card), DialogKit.footer(null, cancel, submit));
        DialogKit.escToClose(this);
        getRootPane().setDefaultButton(submit);
    }

    private void prefill() {
        if (updateMode) {
            departureField.setText(cargo.getDepartureDate() != null ? cargo.getDepartureDate().toString() : "");
            etaField.setText(cargo.getEstimatedEta() != null ? cargo.getEstimatedEta().toString() : "");
            if (cargo.getVesselId() != null) {
                for (int i = 0; i < vesselBox.getItemCount(); i++) {
                    if (vesselBox.getItemAt(i).getId() == cargo.getVesselId()) {
                        vesselBox.setSelectedIndex(i);
                        break;
                    }
                }
            }
        } else {
            departureField.setText(LocalDate.now().toString());
            etaField.setText(LocalDate.now().plusDays(7).toString());
        }
    }

    private void onSubmit() {
        Vessel selected = (Vessel) vesselBox.getSelectedItem();
        if (selected == null) {
            JOptionPane.showMessageDialog(this, "Select a vessel.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        LocalDate dep;
        LocalDate arr;
        try {
            dep = LocalDate.parse(departureField.getText().trim());
            arr = LocalDate.parse(etaField.getText().trim());
        } catch (DateTimeParseException ex) {
            JOptionPane.showMessageDialog(this, "Dates must be in the format yyyy-MM-dd (e.g. 2026-10-15).",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (arr.isBefore(dep)) {
            JOptionPane.showMessageDialog(this, "Est. ETA cannot be earlier than the departure date.",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        vessel = selected;
        departure = dep;
        eta = arr;
        confirmed = true;
        dispose();
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public Vessel getVessel() {
        return vessel;
    }

    public LocalDate getDeparture() {
        return departure;
    }

    public LocalDate getEta() {
        return eta;
    }
}
