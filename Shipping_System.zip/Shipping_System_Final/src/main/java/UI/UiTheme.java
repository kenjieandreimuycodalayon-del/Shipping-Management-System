package UI;

import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 * Small shared look for the app. Call the style* methods from constructors
 * (never inside the NetBeans-generated initComponents block).
 */
public final class UiTheme {

    public static final Color NAVY = new Color(0, 0, 102);
    public static final Color NAVY_HOVER = new Color(30, 30, 140);
    public static final Color BORDER = new Color(218, 222, 230);
    public static final Color STRIPE = new Color(246, 248, 252);
    public static final Color SELECTION = new Color(214, 224, 247);
    public static final Color TEXT = new Color(33, 37, 41);
    public static final Color MUTED = new Color(108, 117, 125);

    public static final Font BODY = new Font("Gadugi", Font.PLAIN, 14);
    public static final Font BOLD = new Font("Gadugi", Font.BOLD, 14);
    public static final Font TITLE = new Font("Gadugi", Font.BOLD, 22);

    private UiTheme() {
    }

    /** Call once at startup, before any window is created. */
    public static void installDefaults() {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
            // fall back to Metal
        }
    }

    public static void styleTable(JTable table) {
        table.setFont(BODY);
        table.setForeground(TEXT);
        table.setRowHeight(34);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setSelectionBackground(SELECTION);
        table.setSelectionForeground(TEXT);
        table.setFillsViewportHeight(true);
        table.setAutoCreateRowSorter(true);

        // renderers registered by class survive setModel(...) in loadArchive()
        table.setDefaultRenderer(Object.class, new RowRenderer());

        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.setPreferredSize(new Dimension(header.getPreferredSize().width, 38));
        header.setDefaultRenderer(new HeaderRenderer());

        Container parent = table.getParent();
        if (parent instanceof JViewport && parent.getParent() instanceof JScrollPane) {
            JScrollPane sp = (JScrollPane) parent.getParent();
            sp.setBorder(BorderFactory.createLineBorder(BORDER));
            sp.getViewport().setBackground(Color.WHITE);
        }
    }

    /** Flat navy button with hover state. Resets the old space-padded labels. */
    public static void stylePrimary(JButton b) {
        b.setText(b.getText().trim());
        b.setHorizontalAlignment(SwingConstants.CENTER);
        b.setFont(BOLD);
        b.setForeground(Color.WHITE);
        b.setBackground(NAVY);
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setBorderPainted(false);
        b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent e) {
                b.setBackground(NAVY_HOVER);
            }

            @Override
            public void mouseExited(MouseEvent e) {
                b.setBackground(NAVY);
            }
        });
    }

    /** Outlined secondary button (Cancel etc.). */
    public static void styleSecondary(JButton b) {
        b.setFont(BOLD);
        b.setForeground(NAVY);
        b.setBackground(Color.WHITE);
        b.setOpaque(true);
        b.setContentAreaFilled(true);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(NAVY),
                BorderFactory.createEmptyBorder(8, 18, 8, 18)));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    public static void styleField(JTextField f) {
        f.setFont(BODY);
        f.setBorder(fieldBorder(BORDER));
        f.addFocusListener(new java.awt.event.FocusAdapter() {
            @Override
            public void focusGained(java.awt.event.FocusEvent e) {
                f.setBorder(fieldBorder(NAVY));
            }

            @Override
            public void focusLost(java.awt.event.FocusEvent e) {
                f.setBorder(fieldBorder(BORDER));
            }
        });
    }

    private static Border fieldBorder(Color c) {
        return BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(c),
                BorderFactory.createEmptyBorder(7, 10, 7, 10));
    }

    // ---- renderers ----

    private static final class RowRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                boolean focus, int row, int col) {
            super.getTableCellRendererComponent(t, value, selected, false, row, col);
            setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
            if (!selected) {
                setBackground(row % 2 == 0 ? Color.WHITE : STRIPE);
            }
            setForeground(TEXT);
            setFont(BODY);

            // colour-code the status column (value is the Cargo.Status enum)
            if (value != null && value.getClass().isEnum()) {
                switch (value.toString().toUpperCase()) {
                    case "RECEIVED":
                        setForeground(new Color(25, 135, 84));
                        break;
                    case "RETURNED":
                        setForeground(new Color(180, 110, 0));
                        break;
                    case "CANCELLED":
                        setForeground(new Color(200, 50, 50));
                        break;
                    default:
                        break;
                }
                setFont(BOLD);
            }
            return this;
        }
    }

    private static final class HeaderRenderer extends DefaultTableCellRenderer {
        HeaderRenderer() {
            setHorizontalAlignment(SwingConstants.LEFT);
        }

        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                boolean focus, int row, int col) {
            super.getTableCellRendererComponent(t, value, false, false, row, col);
            setBackground(NAVY);
            setForeground(Color.WHITE);
            setFont(BOLD);
            setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 12));
            return this;
        }
    }
}
