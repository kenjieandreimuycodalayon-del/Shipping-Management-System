package Presentation;

import Model.Partnership;
import Model.Port;
import UI.DialogKit;
import UI.TemplateUI;
import Util.IdGenerator;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDate;

/**
 * Backs PortPartnerships -> "Review Contract". Shows the pre-built partnership
 * contract for the selected request. The dialog cannot be closed (Close button
 * or the window's X) until the agreement checkbox at the bottom is ticked.
 */
public class ContractDialog extends JDialog {

    private final Partnership partnership;
    private final Port sender;
    private final Port receiver;
    private boolean agreed = false;

    public ContractDialog(Frame owner, Partnership partnership, Port sender, Port receiver) {
        super(owner, "Partnership Contract", true);
        this.partnership = partnership;
        this.sender = sender;
        this.receiver = receiver;
        buildUI();
        setSize(820, 680);
        setResizable(false);
        setLocationRelativeTo(owner);
    }

    public boolean isAgreed() {
        return agreed;
    }

    private void buildUI() {
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);   // no Esc-to-close here on purpose

        JPanel header = DialogKit.header("Partnership Contract",
                "Please read the full agreement before continuing.",
                IdGenerator.partnershipCode(partnership.getId()));

        JTextArea text = new JTextArea(buildContract());
        text.setEditable(false);
        text.setLineWrap(true);
        text.setWrapStyleWord(true);
        text.setFont(TemplateUI.font(Font.PLAIN, 14));
        text.setForeground(DialogKit.TEXT);
        text.setBorder(BorderFactory.createEmptyBorder(12, 14, 12, 14));
        text.setCaretPosition(0);
        JScrollPane scroll = new JScrollPane(text);
        scroll.setBorder(BorderFactory.createLineBorder(DialogKit.LINE));
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        JPanel card = DialogKit.card("Terms and Conditions");
        card.add(scroll, BorderLayout.CENTER);

        JCheckBox agree = new JCheckBox("I have read and agree to the terms of this partnership contract.");
        agree.setFont(TemplateUI.font(Font.BOLD, 14));
        agree.setForeground(DialogKit.NAVY);
        agree.setOpaque(false);
        agree.setFocusPainted(false);

        JButton close = DialogKit.primary("Accept & Close");
        close.setEnabled(false);
        close.addActionListener(e -> {
            agreed = true;
            dispose();
        });
        agree.addActionListener(e -> close.setEnabled(agree.isSelected()));

        // the window's X must obey the same rule
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                if (agree.isSelected()) {
                    agreed = true;
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(ContractDialog.this,
                            "Please tick the checkbox to confirm you have read the contract before closing.",
                            "Contract", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        DialogKit.assemble(this, header, DialogKit.body(card), DialogKit.footer(agree, close));
    }

    private String describe(Port p) {
        if (p == null) {
            return "Unknown Port";
        }
        return p.getPortName() + " (" + (p.getPortCode() != null ? p.getPortCode() : "#" + p.getId()) + ")";
    }

    private String buildContract() {
        String requestType = partnership.getRequestType() != null ? partnership.getRequestType() : "-";
        StringBuilder sb = new StringBuilder();
        sb.append("PORT PARTNERSHIP AGREEMENT\n\n");
        sb.append("Agreement No.: ").append(IdGenerator.partnershipCode(partnership.getId())).append("\n");
        sb.append("Date Reviewed: ").append(LocalDate.now()).append("\n");
        sb.append("Partnership Type: ").append(requestType).append("\n\n");
        sb.append("This Agreement is made within the Lodestar Shipping Co. port network between:\n\n");
        sb.append("  Requesting Port (the \"First Party\"): ").append(describe(sender)).append("\n");
        sb.append("  Receiving Port (the \"Second Party\"): ").append(describe(receiver)).append("\n\n");

        sb.append("1. PURPOSE\n");
        sb.append("The parties agree to cooperate as partner ports for the purpose of ").append(requestType)
                .append(", including the creation, dispatch and receipt of cargo between their ports through the Lodestar network.\n\n");

        sb.append("2. OPERATING PERMIT\n");
        sb.append("Each party confirms that it holds a valid, approved operating permit and shall keep that permit in good standing for as long as this Agreement is active. A party whose permit is suspended, rejected or terminated may not create or receive cargo under this Agreement.\n\n");

        sb.append("3. CARGO HANDLING\n");
        sb.append("Each party shall handle, store and release partner cargo with due care, shall declare the weight and products of every cargo accurately, and shall not alter a cargo manifest after the cargo has been dispatched.\n\n");

        sb.append("4. SHIPMENT LIMITS\n");
        sb.append("Each party shall observe the dispatch and cargo item limits set for its port by the network administrator, including the maximum number of active shipments and the maximum number of products per cargo.\n\n");

        sb.append("5. DISPATCH, ARRIVAL AND RETURNS\n");
        sb.append("The origin port is responsible for preparing and dispatching the cargo on an approved vessel. The destination port is responsible for logging the dock arrival of the cargo, or for marking it as returned when it cannot be accepted.\n\n");

        sb.append("6. LIABILITY\n");
        sb.append("Each party is responsible for loss or damage to cargo while it is in that party's custody. Neither party is liable for delays caused by weather, port closures, force majeure or instructions of competent authorities.\n\n");

        sb.append("7. CONFIDENTIALITY\n");
        sb.append("Each party shall keep cargo, product and partner information received through this Agreement confidential and use it only for the purposes of this Agreement.\n\n");

        sb.append("8. TERM AND TERMINATION\n");
        sb.append("This Agreement takes effect when the Second Party accepts the request and remains active until terminated. Either party may terminate an active partnership at any time through the system. Cargo already dispatched shall still be completed under these terms.\n\n");

        sb.append("9. NETWORK POLICY\n");
        sb.append("This Agreement is subject to the policies of Lodestar Shipping Co. and its network administrator, who may suspend or terminate a port or partnership that breaches these terms.\n\n");

        sb.append("10. ACCEPTANCE\n");
        sb.append("By ticking the agreement box below, the reviewing party confirms that it has read and understood this Agreement in full.\n");
        return sb.toString();
    }
}
