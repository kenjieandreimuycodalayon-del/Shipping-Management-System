package UI;

import java.awt.Container; //NEW
import javax.swing.JComponent;
import javax.swing.JPanel;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import java.awt.BorderLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Component;
import java.awt.Point;
import javax.swing.SwingUtilities;

/**
 * Lets the window resize without touching the generated GroupLayouts. The shell
 * (window, top bar, sidebar) stretches; each page keeps the size it was
 * designed at.
 */
public final class ResponsiveShell {

    private static final Color LOGIN_BG = new Color(244, 246, 249);

    private ResponsiveShell() {
    }

    /**
     * Full-screen cards (login, register): centered at 1280x720.
     */
    public static JPanel centered(JComponent content) {
        content.setPreferredSize(new Dimension(1280, 720));
        JPanel wrap = new JPanel(new GridBagLayout());
        wrap.setBackground(LOGIN_BG);
        wrap.add(content);   // no fill, so it stays centered at its designed size
        return wrap;
    }

    /**
     * Inner pages (1060x650): top-center, and forwards "shown" to the page.
     */
    public static JPanel page(JPanel p) {
        JPanel wrap = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                JComponent band = findTitleBand(p, p, 0);
                if (band == null) {
                    return;
                }
                Point pt = SwingUtilities.convertPoint(band.getParent(), band.getLocation(), this);
                g.setColor(band.getBackground());
                g.fillRect(0, pt.y, getWidth(), band.getHeight());   // children (the page) paint on top
            }
        };
        wrap.setBackground(UIManager.getColor("Panel.background"));
        GridBagConstraints gc = new GridBagConstraints();
        gc.anchor = GridBagConstraints.NORTH;
        gc.weightx = 1;
        gc.weighty = 1;
        wrap.add(p, gc);

        // Pages load their data in componentShown. CardLayout now shows the
        // wrapper, so forward the event or the tables stay empty.
        wrap.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                p.dispatchEvent(new ComponentEvent(p, ComponentEvent.COMPONENT_SHOWN));
            }
        });
        return wrap;
    }

    private static JComponent findTitleBand(Container page, Container node, int depth) {
        if (page.getWidth() <= 0 || depth > 3) {
            return null;
        }
        for (Component c : node.getComponents()) {
            if (c instanceof JPanel && c.isVisible()
                    && c.getWidth() >= page.getWidth() - 2
                    && c.getHeight() > 0 && c.getHeight() <= 90
                    && SwingUtilities.convertPoint(c.getParent(), c.getLocation(), page).y <= 20) {
                return (JComponent) c;
            }
            if (c instanceof Container) {
                JComponent found = findTitleBand(page, (Container) c, depth + 1);
                if (found != null) {
                    return found;
                }
            }
        }
        return null;
    }

    /**
     * Login screen: cover image fills the left, the form stays centered on the
     * right.
     */
    public static JPanel loginSplit(Icon coverIcon, JPanel form) {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(Color.WHITE);

        root.add(new CoverPanel(coverIcon), BorderLayout.WEST);

        JPanel right = new JPanel(new GridBagLayout());
        right.setBackground(Color.WHITE);
        form.setPreferredSize(new Dimension(660, 720));
        right.add(form);   // no fill, so the form keeps its designed size
        root.add(right, BorderLayout.CENTER);
        return root;
    }

    /**
     * Paints the cover image scaled to fill its area (crops the overflow).
     */
    private static final class CoverPanel extends JPanel {

        private static final int MIN_WIDTH = 600;
        private static final double MAX_SHARE = 0.55;   // never take more than 55% of the window

        private final Image img;

        CoverPanel(Icon icon) {
            img = icon instanceof ImageIcon ? ((ImageIcon) icon).getImage() : null;
            setBackground(new Color(27, 48, 92));
        }

        @Override
        public Dimension getPreferredSize() {
            Container p = getParent();
            int h = (p != null && p.getHeight() > 0) ? p.getHeight() : 720;
            int w = MIN_WIDTH;

            int iw = img != null ? img.getWidth(null) : -1;
            int ih = img != null ? img.getHeight(null) : -1;
            if (iw > 0 && ih > 0) {
                w = (int) Math.round(h * (iw / (double) ih));   // width that shows the whole image
            }
            if (p != null && p.getWidth() > 0) {
                w = Math.min(w, (int) (p.getWidth() * MAX_SHARE));
            }
            return new Dimension(Math.max(MIN_WIDTH, w), h);
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (img == null) {
                return;
            }
            int iw = img.getWidth(null), ih = img.getHeight(null);
            if (iw <= 0 || ih <= 0) {
                return;
            }
            double s = Math.max(getWidth() / (double) iw, getHeight() / (double) ih);
            int w = (int) Math.ceil(iw * s), h = (int) Math.ceil(ih * s);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.drawImage(img, (getWidth() - w) / 2, (getHeight() - h) / 2, w, h, null);
            g2.dispose();
        }
    }
}
