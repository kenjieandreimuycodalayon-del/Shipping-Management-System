package Presentation;

import Model.Cargo;
import Model.CargoProduct;
import Service.CargoService;
import UI.DialogKit;
import UI.TemplateUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;

public class InspectManifestDialog extends JDialog {

    public InspectManifestDialog(Frame owner, int cargoId) {
        super(owner, "Inspect Manifest", true);
        buildUI(cargoId);
        DialogKit.escToClose(this);
        DialogKit.finish(this, owner, 560);
    }

    private void buildUI(int cargoId) {
        JButton close = DialogKit.secondary("Close");
        close.addActionListener(e -> dispose());

        JPanel header;
        JComponent body;
        try {
            Cargo cargo = new CargoService().findById(cargoId);
            if (cargo == null) {
                header = DialogKit.header("Inspect Manifest", null, null);
                body = message("Cargo not found.");
            } else {
                header = DialogKit.header("Inspect Manifest", "Cargo details and product list", cargo.getCargoCode());
                body = buildBody(cargo);
            }
        } catch (SQLException ex) {
            header = DialogKit.header("Inspect Manifest", null, null);
            body = message("Database error: " + ex.getMessage());
        }
        DialogKit.assemble(this, header, body, DialogKit.footer(null, close));
    }

    private JComponent message(String text) {
        JPanel card = DialogKit.card(null);
        JLabel l = new JLabel(text, SwingConstants.CENTER);
        l.setFont(TemplateUI.font(Font.PLAIN, 14));
        l.setForeground(DialogKit.MUTED);
        card.add(l, BorderLayout.CENTER);
        card.setPreferredSize(new Dimension(420, 120));
        return DialogKit.body(card);
    }

    private JComponent buildBody(Cargo cargo) {
        JPanel rows = DialogKit.form();
        DialogKit.infoRow(rows, 0, "Cargo Code", cargo.getCargoCode());
        DialogKit.infoRow(rows, 1, "Direction", cargo.getDirection().name());
        JLabel status = DialogKit.infoRow(rows, 2, "Status", cargo.getStatus().name());
        status.setFont(TemplateUI.font(Font.BOLD, 14));
        status.setForeground(TemplateUI.statusColor(cargo.getStatus().name()));
        DialogKit.infoRow(rows, 3, "Weight (kg)", String.valueOf(cargo.getWeightKg()));
        DialogKit.infoRow(rows, 4, "Priority", cargo.getPriority());

        DefaultTableModel model = new DefaultTableModel(new String[]{"Product", "Quantity", "Unit"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        for (CargoProduct p : cargo.getProducts()) {
            model.addRow(new Object[]{p.getProductName(), p.getQuantity(), p.getUnit()});
        }
        JTable table = new JTable(model);
        TemplateUI.styleTable(table, -1, 1);
        table.setRowHeight(36);
        table.setPreferredScrollableViewportSize(new Dimension(480, 140));
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(DialogKit.LINE));

        JLabel productsLabel = new JLabel("Products");
        productsLabel.setFont(TemplateUI.font(Font.BOLD, 14));
        productsLabel.setForeground(DialogKit.NAVY);
        JPanel products = new JPanel(new BorderLayout(0, 8));
        products.setOpaque(false);
        products.add(productsLabel, BorderLayout.NORTH);
        products.add(scroll, BorderLayout.CENTER);

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        top.add(rows, BorderLayout.NORTH);

        JPanel card = DialogKit.card("Cargo Details");
        JPanel inner = new JPanel(new BorderLayout(0, 10));
        inner.setOpaque(false);
        inner.add(top, BorderLayout.NORTH);
        inner.add(products, BorderLayout.CENTER);
        card.add(inner, BorderLayout.CENTER);
        return DialogKit.body(card);
    }
}
