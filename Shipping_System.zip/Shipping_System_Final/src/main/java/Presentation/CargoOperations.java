/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import Model.Cargo;
import Model.Port;
import Service.CargoService;
import Service.PortService;
import UI.TemplateUI;
import Util.Session;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Frame;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class CargoOperations extends javax.swing.JPanel {
    private final CargoService cargoService = new CargoService();
    private final PortService portService = new PortService();
    private List<Cargo> currentCargo;

    /**
     * Creates new form CargoOperations
     */
    public CargoOperations() {
        initComponents();
        applyModernStyle();

        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"All", "Prepared", "Dispatched", "Recieved", "Returned", "Cancelled"}));
        invTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        invTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    viewProd.doClick();
                }
            }
        });
        jComboBox1.addActionListener(e -> loadCargo());
        jComboBox2.addActionListener(e -> loadCargo());

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadCargo();
            }
        });
    }
    
    private void applyModernStyle() {
        TemplateUI.stylePage(jPanel1, jPanel2, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel5 (Port Permits)
        roundedPanel5.setBackground(UIManager.getColor("Table.background"));
        roundedPanel5.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");
        roundedPanel4.setBackground(UIManager.getColor("Table.background"));
        roundedPanel4.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");
        
        TemplateUI.styleTextField(jTextField1, "Search...");
        TemplateUI.styleComboBox(jComboBox1);
        TemplateUI.styleComboBox(jComboBox2);
        
        TemplateUI.styleButton(createOutCargo, true);
        TemplateUI.styleButton(updateStat, true);
        TemplateUI.styleButton(viewProd, true);
        TemplateUI.styleButton(cargoDel, true);
        
        TemplateUI.styleSection(jLabel1);
        jScrollPane1.setBorder(null);
        TemplateUI.styleTable(invTable, 5, 2);
        
    }

    private void onCreateCargo() {
        CreateCargoDialog dialog = new CreateCargoDialog((Frame) SwingUtilities.getWindowAncestor(this));
        dialog.setVisible(true);
        if (dialog.isSucceeded()) {
            loadCargo();
        }
    }

    private Cargo selectedCargo() {
        int row = invTable.getSelectedRow();
        if (currentCargo == null || row < 0 || row >= currentCargo.size()) {
            JOptionPane.showMessageDialog(this, "Select a cargo row first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return null;
        }
        return currentCargo.get(row);
    }

    private void onUpdateStatus() {
        Integer me = Session.getPortId();
        Cargo cargo = selectedCargo();
        if (me == null || cargo == null) {
            return;
        }
        List<Cargo.Status> options = cargoService.allowedStatusChanges(me, cargo);
        if (options.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Your port has no status changes available for " + cargo.getCargoCode()
                    + " (" + cargo.getStatus() + ").",
                    "Update Status", JOptionPane.INFORMATION_MESSAGE);
            return;
        }
        Cargo.Status chosen = (Cargo.Status) JOptionPane.showInputDialog(this,
                "New status for " + cargo.getCargoCode() + ":", "Update Status",
                JOptionPane.PLAIN_MESSAGE, null, options.toArray(), options.get(0));
        if (chosen == null) {
            return;
        }
        if (chosen == Cargo.Status.CANCELLED) {
            int confirm = JOptionPane.showConfirmDialog(this,
                    "Cancel cargo " + cargo.getCargoCode() + "? This cannot be undone.",
                    "Confirm Cancel", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }
        }
        try {
            cargoService.updateStatus(me, cargo.getId(), chosen);
            loadCargo();
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Update Status", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void loadCargo() {
        Integer me = Session.getPortId();
        if (me == null) {
            return;
        }
        try {
            Cargo.Direction direction = comboToDirection((String) jComboBox1.getSelectedItem());
            Cargo.Status status = comboToStatus((String) jComboBox2.getSelectedItem());
            String keyword = jTextField1.getText().trim();

            Map<Integer, Port> ports = new HashMap<>();
            for (Port p : portService.findAll()) {
                ports.put(p.getId(), p);
            }

            currentCargo = cargoService.findForPort(me, direction, status, keyword);

            Object[][] data = new Object[currentCargo.size()][7];
            for (int i = 0; i < currentCargo.size(); i++) {
                Cargo c = currentCargo.get(i);
                data[i][0] = c.getCargoCode();
                // direction is stored from the creator's side; show it from THIS port's side
                data[i][1] = c.getOriginPortId() == me ? Cargo.Direction.OUTBOUND : Cargo.Direction.INBOUND;
                data[i][2] = codeOf(ports.get(c.getOriginPortId()), c.getOriginPortId());
                data[i][3] = codeOf(ports.get(c.getDestinationPortId()), c.getDestinationPortId());
                data[i][4] = c.getProducts() == null ? "" : c.getProducts().size() + " item(s)";
                data[i][5] = c.getStatus();
                data[i][6] = c.getDatePrepared();
            }
            invTable.setModel(new DefaultTableModel(data,
                    new String[]{"Cargo ID", "Direction", "Origin Port", "Destination Port", "Products", "Status", "Date"}) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            });

            jLabel12.setText("! Limits: Max " + cargoService.maxActiveShipments(me)
                    + " active shipments allowed. Max " + cargoService.maxProductsPerCargo(me)
                    + " products per cargo.");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load cargo: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    private String codeOf(Port p, int portId) {
        if (p == null) {
            return "#" + portId;
        }
        return p.getPortCode() != null ? p.getPortCode() : "#" + p.getId();
    }


    private Cargo.Direction comboToDirection(String label) {
        if (label == null || "All".equalsIgnoreCase(label)) {
            return null;
        }
        return Cargo.Direction.valueOf(label.toUpperCase());
    }

    private Cargo.Status comboToStatus(String label) {
        if (label == null || "All".equalsIgnoreCase(label)) {
            return null;
        }
        // combo labels are "Prepared"/"Dispatched"/"Recieved"/"Returned"/"Cancelled" (kept as originally authored)
        return switch (label) {
            case "Recieved" ->
                Cargo.Status.RECEIVED;
            default ->
                Cargo.Status.valueOf(label.toUpperCase());
        };
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        roundedPanel4 = new JSwing.RoundedPanel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jComboBox1 = new javax.swing.JComboBox<>();
        jComboBox2 = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        roundedPanel5 = new JSwing.RoundedPanel();
        createOutCargo = new javax.swing.JButton();
        updateStat = new javax.swing.JButton();
        viewProd = new javax.swing.JButton();
        cargoDel = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        invTable = new javax.swing.JTable();
        jLabel12 = new javax.swing.JLabel();

        jLabel5.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("Request New Partnership");

        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setMaximumSize(new java.awt.Dimension(1060, 650));
        setMinimumSize(new java.awt.Dimension(1060, 650));
        setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Cargo Inventory & Operations ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        roundedPanel4.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel4.setMaximumSize(new java.awt.Dimension(323, 75));
        roundedPanel4.setMinimumSize(new java.awt.Dimension(323, 75));

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Search:");

        jTextField1.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        jTextField1.addActionListener(this::jTextField1ActionPerformed);

        jLabel8.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("Direction");

        jComboBox1.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        jComboBox1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Inbound", "Outbound" }));

        jComboBox2.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        jComboBox2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Prepared", "Dispatched", "Recieved", "Returned" }));

        jLabel9.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("Status");

        javax.swing.GroupLayout roundedPanel4Layout = new javax.swing.GroupLayout(roundedPanel4);
        roundedPanel4.setLayout(roundedPanel4Layout);
        roundedPanel4Layout.setHorizontalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52)
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel4Layout.setVerticalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel9)
                        .addComponent(jComboBox2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel7)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8)
                        .addComponent(jComboBox1, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jLabel6.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Search & Filter");

        jLabel10.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("Actions");

        roundedPanel5.setBackground(new java.awt.Color(255, 255, 255));

        createOutCargo.setBackground(new java.awt.Color(0, 0, 102));
        createOutCargo.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        createOutCargo.setForeground(new java.awt.Color(255, 255, 255));
        createOutCargo.setText("  Create Outbound Cargo");
        createOutCargo.setBorder(null);
        createOutCargo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        createOutCargo.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        createOutCargo.addActionListener(this::createOutCargoActionPerformed);

        updateStat.setBackground(new java.awt.Color(0, 0, 102));
        updateStat.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        updateStat.setForeground(new java.awt.Color(255, 255, 255));
        updateStat.setText("           Update Status");
        updateStat.setBorder(null);
        updateStat.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        updateStat.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        updateStat.addActionListener(this::updateStatActionPerformed);

        viewProd.setBackground(new java.awt.Color(0, 0, 102));
        viewProd.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        viewProd.setForeground(new java.awt.Color(255, 255, 255));
        viewProd.setText("           View Products");
        viewProd.setBorder(null);
        viewProd.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        viewProd.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        viewProd.addActionListener(this::viewProdActionPerformed);

        cargoDel.setBackground(new java.awt.Color(0, 0, 102));
        cargoDel.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        cargoDel.setForeground(new java.awt.Color(255, 255, 255));
        cargoDel.setText("                  Delete");
        cargoDel.setBorder(null);
        cargoDel.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        cargoDel.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        cargoDel.addActionListener(this::cargoDelActionPerformed);

        javax.swing.GroupLayout roundedPanel5Layout = new javax.swing.GroupLayout(roundedPanel5);
        roundedPanel5.setLayout(roundedPanel5Layout);
        roundedPanel5Layout.setHorizontalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(createOutCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(updateStat, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(viewProd, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(cargoDel, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(70, Short.MAX_VALUE))
        );
        roundedPanel5Layout.setVerticalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(createOutCargo, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(updateStat, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(viewProd, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cargoDel, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        jLabel11.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 102));
        jLabel11.setText("Cargo Inventory");

        invTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Cargo ID", "Direction", "Origin Port", "Destination Port", "Products", "Status", "Date"
            }
        ));
        jScrollPane1.setViewportView(invTable);
        if (invTable.getColumnModel().getColumnCount() > 0) {
            invTable.getColumnModel().getColumn(0).setMinWidth(100);
            invTable.getColumnModel().getColumn(0).setPreferredWidth(100);
            invTable.getColumnModel().getColumn(0).setMaxWidth(100);
            invTable.getColumnModel().getColumn(1).setMinWidth(150);
            invTable.getColumnModel().getColumn(1).setPreferredWidth(150);
            invTable.getColumnModel().getColumn(1).setMaxWidth(150);
        }

        jLabel12.setFont(new java.awt.Font("Gadugi", 0, 14)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 102));
        jLabel12.setText("! Limits: Max 10 active shipments allowed. Max 5 products per cargo.");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1)
                            .addComponent(roundedPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(roundedPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(50, 50, 50))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(224, 224, 224)
                                .addComponent(jLabel12)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel12)
                .addGap(0, 13, Short.MAX_VALUE))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        loadCargo();
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void viewProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewProdActionPerformed
        Cargo cargo = selectedCargo();
        if (cargo == null) {
            return;
        }
        InspectManifestDialog dialog
                = new InspectManifestDialog((Frame) SwingUtilities.getWindowAncestor(this), cargo.getId());
        dialog.setVisible(true);
    }//GEN-LAST:event_viewProdActionPerformed

    private void cargoDelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cargoDelActionPerformed
        Integer me = Session.getPortId();
        Cargo cargo = selectedCargo();
        if (me == null || cargo == null) {
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete cargo " + cargo.getCargoCode() + "? This cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            cargoService.delete(me, cargo.getId());
            loadCargo();
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Delete Cargo", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_cargoDelActionPerformed

    private void createOutCargoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_createOutCargoActionPerformed
        onCreateCargo();
    }//GEN-LAST:event_createOutCargoActionPerformed

    private void updateStatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateStatActionPerformed
        onUpdateStatus();
    }//GEN-LAST:event_updateStatActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cargoDel;
    private javax.swing.JButton createOutCargo;
    private javax.swing.JTable invTable;
    private javax.swing.JComboBox<String> jComboBox1;
    private javax.swing.JComboBox<String> jComboBox2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private JSwing.RoundedPanel roundedPanel4;
    private JSwing.RoundedPanel roundedPanel5;
    private javax.swing.JButton updateStat;
    private javax.swing.JButton viewProd;
    // End of variables declaration//GEN-END:variables
}
