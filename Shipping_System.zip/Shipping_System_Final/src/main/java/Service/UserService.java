package Service;

import DAO.UserDAO;
import Model.User;

import java.sql.SQLException;

/**
 * Settings -> "Save Profile & Security". Rule violations throw
 * IllegalStateException with a message the UI can show directly. NOTE:
 * passwords are compared as plain text to match AuthService and
 * RegistrationService. Swap in a real hash (e.g. BCrypt) before production.
 */
public class UserService {

    private static final int MAX_USERNAME_LENGTH = 50;   // users.username is varchar(50)
    private static final int MAX_NAME_LENGTH = 150;      // users.full_name / email are varchar(150)
    private static final int MIN_PASSWORD_LENGTH = 6;    // same rule as RegisterPanel

    private final UserDAO userDAO = new UserDAO();

    /**
     * Updates the logged-in user's manager name, email and (optionally)
     * password. The current password is required only when the email or the
     * password changes. If the username IS the email (every self-registered
     * port), the username follows the new email so the login keeps working.
     *
     * @param currentUsername the username of the logged-in user (Session)
     * @param newPassword blank = keep the current password
     * @return the saved user, so the caller can refresh the Session
     */
    public User updateProfile(String currentUsername, String fullName, String email,
            String currentPassword, String newPassword) throws SQLException {
        User user = userDAO.findByUsername(currentUsername);
        if (user == null) {
            throw new IllegalStateException("Account not found.");
        }

        String name = fullName == null ? "" : fullName.trim();
        String newEmail = email == null ? "" : email.trim().toLowerCase();
        if (name.isEmpty()) {
            throw new IllegalStateException("Manager Name is required.");
        }
        if (name.length() > MAX_NAME_LENGTH) {
            throw new IllegalStateException("Manager Name must be " + MAX_NAME_LENGTH + " characters or fewer.");
        }
        if (!newEmail.matches("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$")) {
            throw new IllegalStateException("Please enter a valid email address.");
        }
        if (newEmail.length() > MAX_NAME_LENGTH) {
            throw new IllegalStateException("Email must be " + MAX_NAME_LENGTH + " characters or fewer.");
        }

        boolean emailChanged = !newEmail.equalsIgnoreCase(user.getEmail() == null ? "" : user.getEmail());
        boolean wantsNewPassword = newPassword != null && !newPassword.isEmpty();

        if (emailChanged || wantsNewPassword) {
            if (currentPassword == null || !currentPassword.equals(user.getPasswordHash())) {
                throw new IllegalStateException("Current password is incorrect.\n"
                        + "It is required to change your email or password.");
            }
        }
        if (wantsNewPassword) {
            if (newPassword.length() < MIN_PASSWORD_LENGTH) {
                throw new IllegalStateException("New password must be at least " + MIN_PASSWORD_LENGTH + " characters.");
            }
            if (newPassword.equals(user.getPasswordHash())) {
                throw new IllegalStateException("New password must be different from the current password.");
            }
        }

        if (emailChanged) {
            User clash = userDAO.findByUsername(newEmail);
            if (clash == null) {
                clash = userDAO.findByEmail(newEmail);
            }
            if (clash != null && clash.getId() != user.getId()) {
                throw new IllegalStateException("An account with this email already exists.");
            }
            boolean usernameIsEmail = user.getEmail() != null && user.getUsername().equalsIgnoreCase(user.getEmail());
            if (usernameIsEmail) {
                if (newEmail.length() > MAX_USERNAME_LENGTH) {
                    throw new IllegalStateException("Email must be " + MAX_USERNAME_LENGTH + " characters or fewer.");
                }
                user.setUsername(newEmail);
            }
        }

        user.setFullName(name);
        user.setEmail(newEmail);
        if (wantsNewPassword) {
            user.setPasswordHash(newPassword); // TODO BCrypt before production
        }

        try {
            userDAO.update(user);
        } catch (SQLException ex) {
            // 1062 = duplicate key: someone took that email/username a moment ago
            if (ex.getErrorCode() == 1062) {
                throw new IllegalStateException("An account with this email already exists.");
            }
            throw ex;
        }
        return user;
    }
}
