package DAO;

import Model.User;
import Util.DBConnection;

import java.sql.*;

public class UserDAO {

    public int insert(Connection conn, User u) throws SQLException {
        String sql = "INSERT INTO users (username, password_hash, full_name, email, role, port_id) "
                + "VALUES (?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, u);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    u.setId(keys.getInt(1));
                    return u.getId();
                }
            }
        }
        return -1;
    }

    public void update(User u) throws SQLException {
        String sql = "UPDATE users SET username=?, password_hash=?, full_name=?, email=?, role=?, port_id=? "
                + "WHERE id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, u);
            ps.setInt(7, u.getId());
            ps.executeUpdate();
        }
    }

    public User findByUsername(String username) throws SQLException {
        String sql = "SELECT * FROM users WHERE username=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public User findByPortId(int portId) throws SQLException {
        String sql = "SELECT * FROM users WHERE port_id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, portId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    public User findByEmail(String email) throws SQLException {
        String sql = "SELECT * FROM users WHERE email=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    private void bind(PreparedStatement ps, User u) throws SQLException {
        ps.setString(1, u.getUsername());
        ps.setString(2, u.getPasswordHash());
        ps.setString(3, u.getFullName());
        ps.setString(4, u.getEmail());
        ps.setString(5, u.getRole().name());
        if (u.getPortId() != null) {
            ps.setInt(6, u.getPortId());
        } else {
            ps.setNull(6, Types.INTEGER);
        }
    }

    private User map(ResultSet rs) throws SQLException {
        User u = new User();
        u.setId(rs.getInt("id"));
        u.setUsername(rs.getString("username"));
        u.setPasswordHash(rs.getString("password_hash"));
        u.setFullName(rs.getString("full_name"));
        u.setEmail(rs.getString("email"));
        u.setRole(User.Role.valueOf(rs.getString("role")));
        int portId = rs.getInt("port_id");
        u.setPortId(rs.wasNull() ? null : portId);
        return u;
    }
}
