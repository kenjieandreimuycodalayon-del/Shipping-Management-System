/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import Model.Cargo;
import Model.Port;
import Model.Vessel;
import Service.CargoService;
import Service.PortService;
import Service.VesselService;
import UI.TemplateUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Frame;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AdminQueue extends javax.swing.JPanel {

    private final CargoService cargoService = new CargoService();
    private final PortService portService = new PortService();
    private final VesselService vesselService = new VesselService();
    private List<Cargo> currentCargo;

    /**
     * Creates new form AdminQueue
     */
    public AdminQueue() {
        initComponents();
        
        applyModernStyle();

        // the generated heading was copied from Partnerships
        jLabel5.setText("Network Cargo Queue");
        shipRegistryStat.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"All", "Prepared", "Dispatched", "Recieved", "Returned", "Cancelled"}));
        queueTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        queueTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    adminInsMan.doClick();
                }
            }
        });
        // Inspect Manifest and Search already have listeners wired in initComponents()
        shipRegistryStat.addActionListener(e -> loadQueue());

        // reload whenever the Queue card is shown so new cargo appears
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadQueue();
            }
        });

        loadQueue();
    }
    
    private void applyModernStyle() {
        TemplateUI.stylePage(jPanel1, jPanel2, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel5 (Port Permits)
        roundedPanel8.setBackground(UIManager.getColor("Table.background"));
        roundedPanel8.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");

        TemplateUI.styleTextField(shipRegistrySearch, "Search...");
        TemplateUI.styleComboBox(shipRegistryStat);
        TemplateUI.styleButton(adminInsMan, true);
        TemplateUI.styleSection(jLabel1);
        jScrollPane1.setBorder(null);
        TemplateUI.styleTable(queueTable, 5, 2);
    }

    private void onInspectManifest() {
        int row = queueTable.getSelectedRow();
        if (currentCargo == null || row < 0 || row >= currentCargo.size()) {
            JOptionPane.showMessageDialog(this, "Select a cargo row first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Cargo cargo = currentCargo.get(row);
        InspectManifestDialog dialog
                = new InspectManifestDialog((Frame) SwingUtilities.getWindowAncestor(this), cargo.getId());
        dialog.setVisible(true);
    }

    private String codeOf(Port p, int portId) {
        if (p == null) {
            return "#" + portId;
        }
        return p.getPortCode() != null ? p.getPortCode() : "#" + p.getId();
    }

    private void loadQueue() {
        try {
            Map<Integer, Port> ports = new HashMap<>();
            for (Port p : portService.findAll()) {
                ports.put(p.getId(), p);
            }
            Map<Integer, Vessel> vessels = new HashMap<>();
            for (Vessel v : vesselService.findByStatus(null)) {
                vessels.put(v.getId(), v);
            }

            String keyword = shipRegistrySearch.getText().trim();
            String statusLabel = (String) shipRegistryStat.getSelectedItem();
            Cargo.Status status = "All".equalsIgnoreCase(statusLabel) || statusLabel == null
                    ? null
                    : "Recieved".equals(statusLabel) ? Cargo.Status.RECEIVED : Cargo.Status.valueOf(statusLabel.toUpperCase());

            currentCargo = cargoService.find(null, status, keyword);

            Object[][] data = new Object[currentCargo.size()][6];
            for (int i = 0; i < currentCargo.size(); i++) {
                Cargo c = currentCargo.get(i);
                Vessel v = c.getVesselId() != null ? vessels.get(c.getVesselId()) : null;
                data[i][0] = c.getCargoCode();
                data[i][1] = codeOf(ports.get(c.getOriginPortId()), c.getOriginPortId());
                data[i][2] = codeOf(ports.get(c.getDestinationPortId()), c.getDestinationPortId());
                data[i][3] = v != null ? v.getVesselName() : "\u2014";
                data[i][4] = String.format("%,d", (long) c.getWeightKg());
                data[i][5] = c.getStatus();
            }
            queueTable.setModel(new DefaultTableModel(data,
                    new String[]{"Cargo ID", "Origin Port", "Destination Port", "Assigned Vessel", "Weight (kg)", "Status"}) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            });
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load queue: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        roundedPanel8 = new JSwing.RoundedPanel();
        adminInsMan = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        shipRegistrySearch = new javax.swing.JTextField();
        shipRegistryStat = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        queueTable = new javax.swing.JTable();

        setMaximumSize(new java.awt.Dimension(1060, 650));
        setMinimumSize(new java.awt.Dimension(1060, 650));
        setLayout(new java.awt.BorderLayout());

        jPanel1.setMaximumSize(new java.awt.Dimension(1060, 650));
        jPanel1.setMinimumSize(new java.awt.Dimension(1060, 650));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Global Network Dispatch Queue");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1)
                .addContainerGap(618, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        roundedPanel8.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel8.setMaximumSize(new java.awt.Dimension(960, 76));
        roundedPanel8.setMinimumSize(new java.awt.Dimension(960, 76));

        adminInsMan.setBackground(new java.awt.Color(0, 0, 102));
        adminInsMan.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        adminInsMan.setForeground(new java.awt.Color(255, 255, 255));
        adminInsMan.setText("         Inspect Manifest");
        adminInsMan.setBorder(null);
        adminInsMan.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        adminInsMan.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        adminInsMan.addActionListener(this::adminInsManActionPerformed);

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Search:");

        shipRegistrySearch.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        shipRegistrySearch.addActionListener(this::shipRegistrySearchActionPerformed);

        shipRegistryStat.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        shipRegistryStat.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Prepared", "Dispatched", "Recieved", "Returned" }));

        jLabel9.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("Status:");

        javax.swing.GroupLayout roundedPanel8Layout = new javax.swing.GroupLayout(roundedPanel8);
        roundedPanel8.setLayout(roundedPanel8Layout);
        roundedPanel8Layout.setHorizontalGroup(
            roundedPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel8Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(adminInsMan, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(60, 60, 60)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(shipRegistryStat, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(shipRegistrySearch, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(134, Short.MAX_VALUE))
        );
        roundedPanel8Layout.setVerticalGroup(
            roundedPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel8Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel9)
                        .addComponent(shipRegistryStat, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7)
                        .addComponent(shipRegistrySearch, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(adminInsMan, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        jLabel5.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("Request New Partnership");

        queueTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Cargo ID", "Origin Port", "Destination Port", "Assigned Vessel", "Weight (kg)", "Status"
            }
        ));
        jScrollPane1.setViewportView(queueTable);
        if (queueTable.getColumnModel().getColumnCount() > 0) {
            queueTable.getColumnModel().getColumn(0).setMinWidth(150);
            queueTable.getColumnModel().getColumn(0).setPreferredWidth(150);
            queueTable.getColumnModel().getColumn(0).setMaxWidth(150);
        }

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(roundedPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jScrollPane1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(roundedPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(50, 50, 50)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 43, Short.MAX_VALUE))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void shipRegistrySearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shipRegistrySearchActionPerformed
        loadQueue();
    }//GEN-LAST:event_shipRegistrySearchActionPerformed

    private void adminInsManActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adminInsManActionPerformed
        onInspectManifest();
    }//GEN-LAST:event_adminInsManActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton adminInsMan;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable queueTable;
    private JSwing.RoundedPanel roundedPanel8;
    private javax.swing.JTextField shipRegistrySearch;
    private javax.swing.JComboBox<String> shipRegistryStat;
    // End of variables declaration//GEN-END:variables
}
