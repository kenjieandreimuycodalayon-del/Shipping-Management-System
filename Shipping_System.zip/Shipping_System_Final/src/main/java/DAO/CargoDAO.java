package DAO;

import Model.Cargo;
import Util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CargoDAO {

    public int insert(Cargo c) throws SQLException {
        String sql = "INSERT INTO cargo (cargo_code, direction, origin_port_id, destination_port_id, vessel_id, "
                + "weight_kg, priority, status, date_prepared, departure_date, estimated_eta, date_ended) "
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, c);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    c.setId(keys.getInt(1));
                    return c.getId();
                }
            }
        }
        return -1;
    }

    public void update(Cargo c) throws SQLException {
        String sql = "UPDATE cargo SET cargo_code=?, direction=?, origin_port_id=?, destination_port_id=?, "
                + "vessel_id=?, weight_kg=?, priority=?, status=?, date_prepared=?, departure_date=?, "
                + "estimated_eta=?, date_ended=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            bind(ps, c);
            ps.setInt(13, c.getId());
            ps.executeUpdate();
        }
    }

    /** Called once, right after insert(), with the code generated from the real id. */
    public void updateCargoCode(int cargoId, String cargoCode) throws SQLException {
        String sql = "UPDATE cargo SET cargo_code=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, cargoCode);
            ps.setInt(2, cargoId);
            ps.executeUpdate();
        }
    }

    public void updateStatus(int id, Cargo.Status status) throws SQLException {
        String sql = "UPDATE cargo SET status=?" + (status == Cargo.Status.RECEIVED
                || status == Cargo.Status.RETURNED || status == Cargo.Status.CANCELLED
                ? ", date_ended=CURDATE()" : "") + " WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status.name());
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    public void assignVessel(int cargoId, int vesselId, LocalDate departureDate, LocalDate estimatedEta)
            throws SQLException {
        String sql = "UPDATE cargo SET vessel_id=?, departure_date=?, estimated_eta=?, status='DISPATCHED' "
                + "WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, vesselId);
            ps.setDate(2, departureDate != null ? Date.valueOf(departureDate) : null);
            ps.setDate(3, estimatedEta != null ? Date.valueOf(estimatedEta) : null);
            ps.setInt(4, cargoId);
            ps.executeUpdate();
        }
    }

    public void updateRoute(int cargoId, int vesselId, LocalDate departureDate, LocalDate estimatedEta)
            throws SQLException {
        String sql = "UPDATE cargo SET vessel_id=?, departure_date=?, estimated_eta=? "
                + "WHERE id=? AND status='DISPATCHED'";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, vesselId);
            ps.setDate(2, departureDate != null ? Date.valueOf(departureDate) : null);
            ps.setDate(3, estimatedEta != null ? Date.valueOf(estimatedEta) : null);
            ps.setInt(4, cargoId);
            ps.executeUpdate();
        }
    }
    
    public void delete(int id) throws SQLException {
        String sql = "DELETE FROM cargo WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public Cargo findById(int id) throws SQLException {
        String sql = "SELECT * FROM cargo WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /** Pass null for direction/status to skip that filter. */
    public List<Cargo> find(Cargo.Direction direction, Cargo.Status status, String keyword) throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT * FROM cargo WHERE 1=1");
        List<Object> params = new ArrayList<>();
        if (direction != null) {
            sql.append(" AND direction=?");
            params.add(direction.name());
        }
        if (status != null) {
            sql.append(" AND status=?");
            params.add(status.name());
        }
        if (keyword != null && !keyword.isBlank()) {
            sql.append(" AND cargo_code LIKE ?");
            params.add("%" + keyword + "%");
        }
        sql.append(" ORDER BY created_at DESC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Cargo> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }

    public int countActive() throws SQLException {
        String sql = "SELECT COUNT(*) FROM cargo WHERE status IN ('PREPARED','DISPATCHED')";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private void bind(PreparedStatement ps, Cargo c) throws SQLException {
        ps.setString(1, c.getCargoCode());
        ps.setString(2, c.getDirection().name());
        ps.setInt(3, c.getOriginPortId());
        ps.setInt(4, c.getDestinationPortId());
        if (c.getVesselId() != null) {
            ps.setInt(5, c.getVesselId());
        } else {
            ps.setNull(5, Types.INTEGER);
        }
        ps.setDouble(6, c.getWeightKg());
        ps.setString(7, c.getPriority());
        ps.setString(8, c.getStatus().name());
        ps.setDate(9, toSqlDate(c.getDatePrepared()));
        ps.setDate(10, toSqlDate(c.getDepartureDate()));
        ps.setDate(11, toSqlDate(c.getEstimatedEta()));
        ps.setDate(12, toSqlDate(c.getDateEnded()));
    }

    private Cargo map(ResultSet rs) throws SQLException {
        Cargo c = new Cargo();
        c.setId(rs.getInt("id"));
        c.setCargoCode(rs.getString("cargo_code"));
        c.setDirection(Cargo.Direction.valueOf(rs.getString("direction")));
        c.setOriginPortId(rs.getInt("origin_port_id"));
        c.setDestinationPortId(rs.getInt("destination_port_id"));
        int vesselId = rs.getInt("vessel_id");
        c.setVesselId(rs.wasNull() ? null : vesselId);
        c.setWeightKg(rs.getDouble("weight_kg"));
        c.setPriority(rs.getString("priority"));
        c.setStatus(Cargo.Status.valueOf(rs.getString("status")));
        c.setDatePrepared(toLocalDate(rs.getDate("date_prepared")));
        c.setDepartureDate(toLocalDate(rs.getDate("departure_date")));
        c.setEstimatedEta(toLocalDate(rs.getDate("estimated_eta")));
        c.setDateEnded(toLocalDate(rs.getDate("date_ended")));
        return c;
    }
    
    public List<Cargo> findForPort(int portId, Cargo.Direction direction, Cargo.Status status, String keyword)
            throws SQLException {
        StringBuilder sql = new StringBuilder("SELECT * FROM cargo WHERE ");
        List<Object> params = new ArrayList<>();
        if (direction == Cargo.Direction.OUTBOUND) {
            sql.append("origin_port_id=?");
            params.add(portId);
        } else if (direction == Cargo.Direction.INBOUND) {
            sql.append("destination_port_id=?");
            params.add(portId);
        } else {
            sql.append("(origin_port_id=? OR destination_port_id=?)");
            params.add(portId);
            params.add(portId);
        }
        if (status != null) {
            sql.append(" AND status=?");
            params.add(status.name());
        }
        if (keyword != null && !keyword.isBlank()) {
            sql.append(" AND cargo_code LIKE ?");
            params.add("%" + keyword + "%");
        }
        sql.append(" ORDER BY created_at DESC");

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) {
                ps.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Cargo> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }
    
    public int countActiveByCreator(int portId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM cargo WHERE status IN ('PREPARED','DISPATCHED') AND "
                + "((direction='OUTBOUND' AND origin_port_id=?) OR (direction='INBOUND' AND destination_port_id=?))";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, portId);
            ps.setInt(2, portId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    private Date toSqlDate(LocalDate d) {
        return d != null ? Date.valueOf(d) : null;
    }

    private LocalDate toLocalDate(Date d) {
        return d != null ? d.toLocalDate() : null;
    }
}