package Presentation;

import Model.PermitApplication;
import Model.Port;
import Service.PortService;
import UI.DialogKit;
import UI.TemplateUI;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * Read-only full profile of a port, with its submitted permit photo. Opened
 * from PortManagement (double-click a row).
 */
public class PortDetailsDialog extends JDialog {

    private final Port port;
    private final PortService portService = new PortService();
    private PermitApplication latestPermit;
    private BufferedImage permitImage;
    private String previewMessage;

    public PortDetailsDialog(Frame owner, Port port) {
        super(owner, "Port Details", true);
        this.port = port;
        loadPermitImage();
        buildUI();
        setSize(940, 700);
        setResizable(false);
        setLocationRelativeTo(owner);
    }

    private void loadPermitImage() {
        try {
            List<PermitApplication> history = portService.permitHistory(port.getId()); // newest first
            if (history.isEmpty()) {
                previewMessage = "No permit application on file.";
                return;
            }
            latestPermit = history.get(0);
            byte[] data = portService.permitDocument(latestPermit.getId());
            if (data == null) {
                previewMessage = "No permit document was uploaded.";
                return;
            }
            permitImage = ImageIO.read(new ByteArrayInputStream(data));
            if (permitImage == null) {
                previewMessage = "Preview not available for this file type.";
            }
        } catch (SQLException | IOException ex) {
            previewMessage = "Could not load document: " + ex.getMessage();
        }
    }

    private void buildUI() {
        String code = port.getPortCode() != null ? port.getPortCode() : "#" + port.getId();
        JPanel header = DialogKit.header("Port Details", "Full profile and submitted permit", code);

        String permitTitle = "Permit"
                + (latestPermit != null && latestPermit.getPermitNo() != null
                ? " \u2014 " + latestPermit.getPermitNo() : "");

        JPanel cards = new JPanel(new GridLayout(1, 2, 20, 0));
        cards.setOpaque(false);
        cards.add(buildInfoCard(code));
        cards.add(DialogKit.documentCard(this, "Submitted Permit", permitImage, previewMessage, permitTitle));

        JButton close = DialogKit.secondary("Close");
        close.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(cards), DialogKit.footer(null, close));
        DialogKit.escToClose(this);
    }

    private JPanel buildInfoCard(String code) {
        JPanel card = DialogKit.card("Port Profile");

        JPanel rows = DialogKit.form();
        DialogKit.infoRow(rows, 0, "Port ID", code);
        DialogKit.infoRow(rows, 1, "Port Name", port.getPortName());
        DialogKit.infoRow(rows, 2, "Registered Name", port.getRegisteredName());
        DialogKit.infoRow(rows, 3, "Capability", port.getPrimaryCapability());
        String status = port.getStatus() != null ? port.getStatus().name() : null;
        JLabel statusLabel = DialogKit.infoRow(rows, 4, "Status", status);
        if (status != null) {
            statusLabel.setFont(TemplateUI.font(Font.BOLD, 14));
            statusLabel.setForeground(TemplateUI.statusColor(status));
        }
        DialogKit.infoRow(rows, 5, "Dispatch Limit", String.valueOf(port.getDispatchLimit()));
        DialogKit.infoRow(rows, 6, "Cargo Item Limit", String.valueOf(port.getCargoItemLimit()));
        DialogKit.infoRow(rows, 7, "Permit No.", port.getPermitNo());
        DialogKit.infoRow(rows, 8, "Permit Authority", port.getPermitAuthority());
        DialogKit.infoRow(rows, 9, "Submitted", str(port.getSubmittedDate()));
        DialogKit.infoRow(rows, 10, "Expires", str(port.getExpirationDate()));
        DialogKit.infoRow(rows, 11, "Last Renewal", str(port.getLastRenewal()));

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(rows, BorderLayout.NORTH);
        card.add(wrap, BorderLayout.CENTER);
        return card;
    }

    private static String str(Object o) {
        return o == null ? null : o.toString();
    }
}
