package DAO;

import Model.Message;
import Model.MessageContact;
import Model.User;
import Util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MessageDAO {

    private static final String SELECT
            = "SELECT m.id, m.sender_id, m.recipient_id, m.subject, m.body, m.is_read, m.sent_at, "
            + "s.role AS s_role, s.full_name AS s_name, s.username AS s_user, sp.port_name AS s_port, sp.port_code AS s_code, "
            + "r.role AS r_role, r.full_name AS r_name, r.username AS r_user, rp.port_name AS r_port, rp.port_code AS r_code "
            + "FROM messages m "
            + "JOIN users s ON s.id = m.sender_id LEFT JOIN ports sp ON sp.id = s.port_id "
            + "JOIN users r ON r.id = m.recipient_id LEFT JOIN ports rp ON rp.id = r.port_id ";

    public int insert(Connection conn, Message m) throws SQLException {
        String sql = "INSERT INTO messages (sender_id, recipient_id, subject, body) VALUES (?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, m.getSenderId());
            ps.setInt(2, m.getRecipientId());
            ps.setString(3, m.getSubject());
            ps.setString(4, m.getBody());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    m.setId(keys.getInt(1));
                    return m.getId();
                }
            }
        }
        return -1;
    }

    public List<Message> findInbox(int userId) throws SQLException {
        return query(SELECT + "WHERE m.recipient_id=? AND m.recipient_deleted=0 "
                + "ORDER BY m.sent_at DESC, m.id DESC", userId);
    }

    public List<Message> findSent(int userId) throws SQLException {
        return query(SELECT + "WHERE m.sender_id=? AND m.sender_deleted=0 "
                + "ORDER BY m.sent_at DESC, m.id DESC", userId);
    }

    public void markRead(int messageId, int userId) throws SQLException {
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(
                "UPDATE messages SET is_read=1 WHERE id=? AND recipient_id=?")) {
            ps.setInt(1, messageId);
            ps.setInt(2, userId);
            ps.executeUpdate();
        }
    }

    /**
     * Hides the message for this user only (whichever side they are on).
     */
    public void delete(int messageId, int userId) throws SQLException {
        try (Connection conn = DBConnection.getConnection()) {
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE messages SET recipient_deleted=1 WHERE id=? AND recipient_id=?")) {
                ps.setInt(1, messageId);
                ps.setInt(2, userId);
                ps.executeUpdate();
            }
            try (PreparedStatement ps = conn.prepareStatement(
                    "UPDATE messages SET sender_deleted=1 WHERE id=? AND sender_id=?")) {
                ps.setInt(1, messageId);
                ps.setInt(2, userId);
                ps.executeUpdate();
            }
        }
    }

    public int countUnread(int userId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM messages WHERE recipient_id=? AND is_read=0 AND recipient_deleted=0";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    /**
     * Every admin plus every user of an ACTIVE port, except the caller.
     */
    public List<MessageContact> findContacts(int excludeUserId) throws SQLException {
        String sql = "SELECT u.id, u.role, u.full_name, u.username, p.port_name, p.port_code "
                + "FROM users u LEFT JOIN ports p ON p.id = u.port_id "
                + "WHERE u.id <> ? AND (u.role='ADMIN' OR p.status='ACTIVE') "
                + "ORDER BY u.role, p.port_name, u.username";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, excludeUserId);
            try (ResultSet rs = ps.executeQuery()) {
                List<MessageContact> list = new ArrayList<>();
                while (rs.next()) {
                    String role = rs.getString("role");
                    list.add(new MessageContact(rs.getInt("id"),
                            label(role, rs.getString("full_name"), rs.getString("username"),
                                    rs.getString("port_name"), rs.getString("port_code")),
                            User.Role.valueOf(role)));
                }
                return list;
            }
        }
    }

    private List<Message> query(String sql, int userId) throws SQLException {
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Message> list = new ArrayList<>();
                while (rs.next()) {
                    list.add(map(rs));
                }
                return list;
            }
        }
    }

    private Message map(ResultSet rs) throws SQLException {
        Message m = new Message();
        m.setId(rs.getInt("id"));
        m.setSenderId(rs.getInt("sender_id"));
        m.setRecipientId(rs.getInt("recipient_id"));
        m.setSubject(rs.getString("subject"));
        m.setBody(rs.getString("body"));
        m.setRead(rs.getBoolean("is_read"));
        Timestamp ts = rs.getTimestamp("sent_at");
        m.setSentAt(ts != null ? ts.toLocalDateTime() : null);
        m.setSenderLabel(label(rs.getString("s_role"), rs.getString("s_name"), rs.getString("s_user"),
                rs.getString("s_port"), rs.getString("s_code")));
        m.setRecipientLabel(label(rs.getString("r_role"), rs.getString("r_name"), rs.getString("r_user"),
                rs.getString("r_port"), rs.getString("r_code")));
        return m;
    }

    private static String label(String role, String fullName, String username, String portName, String portCode) {
        if ("ADMIN".equals(role)) {
            return "Admin - " + (fullName != null && !fullName.isBlank() ? fullName : username);
        }
        String name = portName != null ? portName : username;
        return portCode != null ? name + " (" + portCode + ")" : name;
    }
}
