package Service;

import DAO.CargoDAO;
import DAO.CargoProductDAO;
import DAO.PartnershipDAO;
import DAO.PortDAO;
import Model.Cargo;
import Model.CargoProduct;
import Model.Partnership;
import Model.Port;
import Util.IdGenerator;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import DAO.VesselDAO;
import Model.Vessel;
import java.util.Comparator;

public class CargoService {

    /** Defaults used when a port's own limits are 0 (e.g. the seeded Demo Port).
     *  Matches the "! Limits: Max 10 active shipments allowed. Max 5 products
     *  per cargo." label on the Cargo Operations screen. */
    public static final int MAX_ACTIVE_SHIPMENTS = 10;
    public static final int MAX_PRODUCTS_PER_CARGO = 5;

    private final CargoDAO cargoDAO = new CargoDAO();
    private final CargoProductDAO productDAO = new CargoProductDAO();
    private final PortDAO portDAO = new PortDAO();
    private final PartnershipDAO partnershipDAO = new PartnershipDAO();
    private final VesselDAO vesselDAO = new VesselDAO();

    /** ports.dispatch_limit = max active shipments for that port (0 = use the default). */
    public int maxActiveShipments(int portId) throws SQLException {
        Port port = portDAO.findById(portId);
        return port != null && port.getDispatchLimit() > 0 ? port.getDispatchLimit() : MAX_ACTIVE_SHIPMENTS;
    }

    /** ports.cargo_item_limit = max products per cargo for that port (0 = use the default). */
    public int maxProductsPerCargo(int portId) throws SQLException {
        Port port = portDAO.findById(portId);
        return port != null && port.getCargoItemLimit() > 0 ? port.getCargoItemLimit() : MAX_PRODUCTS_PER_CARGO;
    }

    /**
     * Cargo Operations -> "Create Outbound Cargo" (or inbound). The ACTING port
     * is the creator: it must be the origin of an OUTBOUND cargo or the
     * destination of an INBOUND one, and must have an ACTIVE partnership with
     * the other port. Throws IllegalStateException with a message the dialog
     * can show directly.
     *
     * cargo_code is NOT NULL + UNIQUE, but the real bill-of-lading-style
     * code (e.g. "LSC-OB-2026-000123") needs the real auto-increment id
     * first. A short-lived placeholder satisfies the constraint for the
     * single insert, then gets overwritten immediately after.
     */
    public int createCargo(int actingPortId, Cargo cargo, List<CargoProduct> products) throws SQLException {
        boolean outbound = cargo.getDirection() == Cargo.Direction.OUTBOUND;
        int creatorId = outbound ? cargo.getOriginPortId() : cargo.getDestinationPortId();
        int partnerId = outbound ? cargo.getDestinationPortId() : cargo.getOriginPortId();

        if (creatorId != actingPortId) {
            throw new IllegalStateException("Your port must be the "
                    + (outbound ? "origin" : "destination") + " of the cargo it creates.");
        }
        if (creatorId == partnerId) {
            throw new IllegalStateException("Origin and Destination must be different ports.");
        }
        if (cargo.getWeightKg() <= 0) {
            throw new IllegalStateException("Weight must be greater than zero.");
        }
        if (products.isEmpty()) {
            throw new IllegalStateException("Add at least one product to the cargo.");
        }
        requireActive(actingPortId, "Your port must be ACTIVE to create cargo.");
        requireActive(partnerId, "The partner port is not active.");
        if (!hasActivePartnership(actingPortId, partnerId)) {
            throw new IllegalStateException("Your port has no active partnership with that port.");
        }

        int maxProducts = maxProductsPerCargo(actingPortId);
        if (products.size() > maxProducts) {
            throw new IllegalStateException("A cargo can hold at most " + maxProducts + " products.");
        }
        int maxActive = maxActiveShipments(actingPortId);
        if (cargoDAO.countActiveByCreator(actingPortId) >= maxActive) {
            throw new IllegalStateException("Only " + maxActive + " active shipments are allowed at once.");
        }

        cargo.setStatus(Cargo.Status.PREPARED);
        cargo.setDatePrepared(LocalDate.now());
        cargo.setCargoCode("TEMP-" + System.nanoTime());
        int cargoId = cargoDAO.insert(cargo);

        String cargoCode = IdGenerator.cargoCode(cargo.getDirection(), cargoId);
        cargo.setCargoCode(cargoCode);
        cargoDAO.updateCargoCode(cargoId, cargoCode);

        for (CargoProduct product : products) {
            productDAO.insert(cargoId, product);
        }
        return cargoId;
    }

    /**
     * Status changes this port may make on this cargo from Cargo Operations:
     * PREPARED -> CANCELLED (creator only); DISPATCHED -> RECEIVED / RETURNED
     * (destination only). Dispatching needs a vessel, so it is done in the
     * Dispatch Queue, not here. RECEIVED / RETURNED / CANCELLED are final.
     */
    public List<Cargo.Status> allowedStatusChanges(int actingPortId, Cargo cargo) {
        List<Cargo.Status> result = new ArrayList<>();
        switch (cargo.getStatus()) {
            case PREPARED:
                if (isCreator(cargo, actingPortId)) {
                    result.add(Cargo.Status.CANCELLED);
                }
                break;
            case DISPATCHED:
                if (cargo.getDestinationPortId() == actingPortId) {
                    result.add(Cargo.Status.RECEIVED);
                    result.add(Cargo.Status.RETURNED);
                }
                break;
            default:
                break;
        }
        return result;
    }

    /** Cargo Operations -> "Update Status". */
    public void updateStatus(int actingPortId, int cargoId, Cargo.Status status) throws SQLException {
        Cargo cargo = requireParty(actingPortId, cargoId);
        if (!allowedStatusChanges(actingPortId, cargo).contains(status)) {
            throw new IllegalStateException("Your port cannot change this cargo from "
                    + cargo.getStatus() + " to " + status + ".");
        }
        cargoDAO.updateStatus(cargoId, status);
    }
    
    /** Port Dashboard -> "Active Shipments": PREPARED/DISPATCHED cargo THIS port created (what the limit counts). */
    public int countActiveByCreator(int portId) throws SQLException {
        return cargoDAO.countActiveByCreator(portId);
    }
    
    /** Port Dashboard -> "Recent Cargo Movements": this port's newest cargo (either direction), at most `limit` rows. */
    public List<Cargo> recentForPort(int portId, int limit) throws SQLException {
        List<Cargo> all = cargoDAO.findForPort(portId, null, null, null); // already newest first
        List<Cargo> recent = all.size() > limit ? new ArrayList<>(all.subList(0, limit)) : all;
        return withProducts(recent);
    }
    
    /**
     * Port Archive: this port's RECEIVED / RETURNED / CANCELLED cargo, newest
     * first. Pass null status for all three; any other status is rejected
     * because PREPARED / DISPATCHED cargo is still active, not archived.
     */
    public List<Cargo> archivedForPort(int portId, Cargo.Status status, String keyword) throws SQLException {
        List<Cargo.Status> wanted;
        if (status == null) {
            wanted = List.of(Cargo.Status.RECEIVED, Cargo.Status.RETURNED, Cargo.Status.CANCELLED);
        } else if (status == Cargo.Status.RECEIVED || status == Cargo.Status.RETURNED
                || status == Cargo.Status.CANCELLED) {
            wanted = List.of(status);
        } else {
            throw new IllegalStateException("The archive only holds RECEIVED, RETURNED or CANCELLED cargo.");
        }
        List<Cargo> result = new ArrayList<>();
        for (Cargo.Status s : wanted) {
            result.addAll(cargoDAO.findForPort(portId, null, s, keyword));
        }
        Comparator<Cargo> newestFirst = Comparator
                .comparing(Cargo::getDateEnded, Comparator.nullsLast(Comparator.<LocalDate>reverseOrder()))
                .thenComparing(Comparator.comparingInt(Cargo::getId).reversed());
        result.sort(newestFirst);
        return result;
    }

    /** Admin Dashboard -> "Recent Cargo Movements": newest cargo network-wide, at most `limit` rows. */
    public List<Cargo> recent(int limit) throws SQLException {
        List<Cargo> all = cargoDAO.find(null, null, null); // already newest first
        List<Cargo> recent = all.size() > limit ? new ArrayList<>(all.subList(0, limit)) : all;
        return withProducts(recent);
    }

    public List<Cargo> readyForDispatch(int portId) throws SQLException {
        List<Cargo> result = new ArrayList<>();
        for (Cargo c : cargoDAO.findForPort(portId, null, Cargo.Status.PREPARED, null)) {
            if (c.getOriginPortId() == portId) {
                result.add(c);
            }
        }
        return withProducts(result);
    }
    
        private void requireUsableVessel(int actingPortId, int vesselId, Cargo cargo) throws SQLException {
        Vessel vessel = vesselDAO.findById(vesselId);
        if (vessel == null) {
            throw new IllegalStateException("Vessel not found.");
        }
        boolean isCurrent = cargo.getVesselId() != null && cargo.getVesselId() == vesselId;
        if (!isCurrent && (vessel.getPortId() == null || vessel.getPortId() != actingPortId)) {
            throw new IllegalStateException("You can only use vessels registered to your port.");
        }
        if (vessel.getStatus() != Vessel.Status.ACTIVE && !isCurrent) {
            throw new IllegalStateException("Only ACTIVE vessels can be assigned to cargo.");
        }
        // cargo weight is in kg, vessel capacity is in tons
        if (vessel.getMaxCapacityTons() > 0 && cargo.getWeightKg() / 1000.0 > vessel.getMaxCapacityTons()) {
            throw new IllegalStateException("This cargo (" + cargo.getWeightKg() + " kg) exceeds the capacity of "
                    + vessel.getVesselName() + " (" + vessel.getMaxCapacityTons() + " tons).");
        }
    }

    public List<Cargo> activeInTransit(int portId) throws SQLException {
        return withProducts(cargoDAO.findForPort(portId, null, Cargo.Status.DISPATCHED, null));
    }
    
    /**
     * Dispatch Queue -> "Assign Vessel & Dispatch". Only the ORIGIN port can
     * dispatch, only PREPARED cargo, on an ACTIVE vessel that can carry the
     * weight. PREPARED -> DISPATCHED.
     */
    public void dispatch(int actingPortId, int cargoId, int vesselId,
            LocalDate departureDate, LocalDate estimatedEta) throws SQLException {
        Cargo cargo = requireParty(actingPortId, cargoId);
        if (cargo.getStatus() != Cargo.Status.PREPARED) {
            throw new IllegalStateException("Only PREPARED cargo can be dispatched.");
        }
        if (cargo.getOriginPortId() != actingPortId) {
            throw new IllegalStateException("Only the origin port can dispatch this cargo.");
        }
        requireActive(actingPortId, "Your port must be ACTIVE to dispatch cargo.");
        requireActive(cargo.getDestinationPortId(), "The destination port is not active.");
        if (!hasActivePartnership(actingPortId, cargo.getDestinationPortId())) {
            throw new IllegalStateException("Your port no longer has an active partnership with the destination port.");
        }
        requireUsableVessel(actingPortId, vesselId, cargo);
        requireSchedule(departureDate, estimatedEta, true);
        cargoDAO.assignVessel(cargoId, vesselId, departureDate, estimatedEta);
    }
    
    public void updateRoute(int actingPortId, int cargoId, int vesselId,
            LocalDate departureDate, LocalDate estimatedEta) throws SQLException {
        Cargo cargo = requireParty(actingPortId, cargoId);
        if (cargo.getStatus() != Cargo.Status.DISPATCHED) {
            throw new IllegalStateException("Only DISPATCHED cargo can have its route updated.");
        }
        if (cargo.getOriginPortId() != actingPortId) {
            throw new IllegalStateException("Only the origin port can update the route / ETA.");
        }
        requireUsableVessel(actingPortId, vesselId, cargo);
        requireSchedule(departureDate, estimatedEta, false);
        cargoDAO.updateRoute(cargoId, vesselId, departureDate, estimatedEta);
    }
    
    public void logArrival(int actingPortId, int cargoId) throws SQLException {
        Cargo cargo = requireParty(actingPortId, cargoId);
        if (cargo.getStatus() != Cargo.Status.DISPATCHED) {
            throw new IllegalStateException("Only DISPATCHED cargo can be logged as arrived.");
        }
        if (cargo.getDestinationPortId() != actingPortId) {
            throw new IllegalStateException("Only the destination port can log the dock arrival.");
        }
        cargoDAO.updateStatus(cargoId, Cargo.Status.RECEIVED);
    }
    
    /** Cargo Operations -> "Delete". Only PREPARED cargo, only by the port that created it. */
    public void delete(int actingPortId, int cargoId) throws SQLException {
        Cargo cargo = requireParty(actingPortId, cargoId);
        if (cargo.getStatus() != Cargo.Status.PREPARED || !isCreator(cargo, actingPortId)) {
            throw new IllegalStateException(
                    "Only PREPARED cargo created by your port can be deleted.\nUse Update Status to cancel other cargo.");
        }
        cargoDAO.delete(cargoId);
    }

    public Cargo findById(int id) throws SQLException {
        Cargo cargo = cargoDAO.findById(id);
        if (cargo != null) {
            cargo.setProducts(productDAO.findByCargoId(id));
        }
        return cargo;
    }

    /** Backs the admin Queue filter row (Direction / Status / Search). */
    public List<Cargo> find(Cargo.Direction direction, Cargo.Status status, String keyword) throws SQLException {
        return withProducts(cargoDAO.find(direction, status, keyword));
    }

    /**
     * Backs Cargo Operations' filter row (Direction / Status / Search) for ONE
     * port. Direction is relative to that port: OUTBOUND = it is the origin,
     * INBOUND = it is the destination.
     */
    public List<Cargo> findForPort(int portId, Cargo.Direction direction, Cargo.Status status, String keyword)
            throws SQLException {
        return withProducts(cargoDAO.findForPort(portId, direction, status, keyword));
    }

    /** Dispatch Queue -> "Ready for Dispatch" table. */
    public List<Cargo> readyForDispatch() throws SQLException {
        return cargoDAO.find(null, Cargo.Status.PREPARED, null);
    }

    /** Dispatch Queue -> "Active In-Transit" table. */
    public List<Cargo> activeInTransit() throws SQLException {
        return cargoDAO.find(null, Cargo.Status.DISPATCHED, null);
    }

    /** Archive screens -> received/returned/cancelled cargo. */
    public List<Cargo> archived() throws SQLException {
        List<Cargo> received = cargoDAO.find(null, Cargo.Status.RECEIVED, null);
        received.addAll(cargoDAO.find(null, Cargo.Status.CANCELLED, null));
        received.addAll(cargoDAO.find(null, Cargo.Status.RETURNED, null));
        return received;
    }

    public int countActive() throws SQLException {
        return cargoDAO.countActive();
    }

    // ---- helpers ----
    /** cargo rows come back without products; the table's "Products" column needs them. */
    private List<Cargo> withProducts(List<Cargo> cargo) throws SQLException {
        for (Cargo c : cargo) {
            c.setProducts(productDAO.findByCargoId(c.getId()));
        }
        return cargo;
    }

    /** The direction column is stored from the creator's point of view. */
    private static boolean isCreator(Cargo cargo, int portId) {
        return cargo.getDirection() == Cargo.Direction.OUTBOUND
                ? cargo.getOriginPortId() == portId
                : cargo.getDestinationPortId() == portId;
    }

    private Cargo requireParty(int actingPortId, int cargoId) throws SQLException {
        Cargo cargo = cargoDAO.findById(cargoId);
        if (cargo == null) {
            throw new IllegalStateException("Cargo not found.");
        }
        if (cargo.getOriginPortId() != actingPortId && cargo.getDestinationPortId() != actingPortId) {
            throw new IllegalStateException("Your port is not part of this cargo.");
        }
        return cargo;
    }

    private void requireActive(int portId, String message) throws SQLException {
        Port port = portDAO.findById(portId);
        if (port == null || port.getStatus() != Port.Status.ACTIVE) {
            throw new IllegalStateException(message);
        }
    }

    private boolean hasActivePartnership(int a, int b) throws SQLException {
        for (Partnership p : partnershipDAO.findByPortAndStatus(a, Partnership.Status.ACTIVE)) {
            if (PartnershipService.otherPort(p, a) == b) {
                return true;
            }
        }
        return false;
    }
    
    private void requireSchedule(LocalDate departure, LocalDate eta, boolean departureNotInPast) {
        if (departure == null || eta == null) {
            throw new IllegalStateException("Departure date and Est. ETA are required.");
        }
        if (departureNotInPast && departure.isBefore(LocalDate.now())) {
            throw new IllegalStateException("Departure date cannot be in the past.");
        }
        if (eta.isBefore(departure)) {
            throw new IllegalStateException("Est. ETA cannot be earlier than the departure date.");
        }
    }
}