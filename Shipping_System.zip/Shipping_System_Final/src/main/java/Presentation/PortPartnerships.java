package Presentation;

import Model.Partnership;
import Model.Port;
import Service.PartnershipService;
import Service.PortService;
import UI.TemplateUI;
import Util.Session;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.SwingUtilities;
import java.awt.Frame;
import javax.swing.UIManager;

public class PortPartnerships extends javax.swing.JPanel {

    /**
     * Creates new form PortPartnerships
     */
    // TODO: change to whatever request types you actually want
    private static final String[] REQUEST_TYPES = {"Cargo Exchange", "Feeder Service", "Joint Operations"};

    private final PartnershipService partnershipService = new PartnershipService();
    private final PortService portService = new PortService();

    // parallel to the table rows / combo items so a selection maps back to an object
    private List<Partnership> activeList = new ArrayList<>();
    private List<Partnership> pendingList = new ArrayList<>();
    private List<Port> targetPorts = new ArrayList<>();

    public PortPartnerships() {
        initComponents();
        applyModernStyle();
        
        portSelection.setEditable(false); // generated code makes it editable; we only want list picks

        // Do NOT load in the constructor: PortPanel builds all its screens at app start,
        // before anyone has logged in, so Session.getPortId() would still be null.
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                refresh();
            }
        });
    }
    
    private void applyModernStyle() {
        TemplateUI.stylePage(portPartnerships, jPanel2, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel5 (Port Permits)
        roundedPanel4.setBackground(UIManager.getColor("Table.background"));
        roundedPanel4.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");
        
        TemplateUI.styleComboBox(portSelection);

        TemplateUI.styleButton(sendReq, true);
        
        TemplateUI.styleButton(terminatePart, true);
        
        TemplateUI.styleButton(acceptReq, true);
        TemplateUI.styleButton(rejectReq, true);
        TemplateUI.styleButton(reviewContractPartnershipButton, true);
        
        TemplateUI.styleSection(jLabel1);
        jScrollPane1.setBorder(null);
        TemplateUI.styleTable(activePart, -1, 2);
        
        TemplateUI.styleSection(jLabel1);
        jScrollPane2.setBorder(null);
        TemplateUI.styleTable(pendingPart, 3, 2);
    }

    private interface DbAction {

        void run() throws SQLException;
    }

    private void runAction(DbAction action) {
        try {
            action.run();
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Partnership", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
        refresh();
    }

    private DefaultTableModel readOnlyModel(Object[][] data, String[] columns) {
        return new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private String codeOf(Port p) {
        if (p == null) {
            return "-";
        }
        return p.getPortCode() != null ? p.getPortCode() : "#" + p.getId();
    }

    private void refresh() {
        Integer me = Session.getPortId();
        if (me == null) {
            return;
        }
        try {
            Map<Integer, Port> ports = new HashMap<>();
            for (Port p : portService.findAll()) {
                ports.put(p.getId(), p);
            }

            // Active partnerships
            activeList = partnershipService.activeFor(me);
            Object[][] active = new Object[activeList.size()][4];
            for (int i = 0; i < activeList.size(); i++) {
                Partnership p = activeList.get(i);
                Port other = ports.get(PartnershipService.otherPort(p, me));
                active[i][0] = codeOf(other);
                active[i][1] = other != null ? other.getPortName() : "-";
                active[i][2] = other != null ? other.getPrimaryCapability() : "-";
                active[i][3] = p.getConnectedSince();
            }
            activePart.setModel(readOnlyModel(active,
                    new String[]{"Port ID", "Port Name", "Capability", "Connected Since"}));

            // Pending requests (incoming + outgoing)
            pendingList = partnershipService.pendingFor(me);
            Object[][] pending = new Object[pendingList.size()][4];
            for (int i = 0; i < pendingList.size(); i++) {
                Partnership p = pendingList.get(i);
                Port other = ports.get(PartnershipService.otherPort(p, me));
                pending[i][0] = codeOf(other);
                pending[i][1] = other != null ? other.getPortName() : "-";
                pending[i][2] = p.getRequestType();
                pending[i][3] = p.getPortBId() == me ? "Incoming" : "Awaiting reply";
            }
            pendingPart.setModel(readOnlyModel(pending,
                    new String[]{"Port ID", "Port Name", "Request Type", "Status"}));

            // Combo: only ports this one can actually send a request to
            targetPorts = partnershipService.availableTargets(me);
            portSelection.removeAllItems();
            for (Port p : targetPorts) {
                portSelection.addItem(p.toString());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load partnerships: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private Partnership selectedFrom(javax.swing.JTable table, List<Partnership> rows, String what) {
        int row = table.getSelectedRow();
        if (row < 0 || row >= rows.size()) {
            JOptionPane.showMessageDialog(this, "Select " + what + " first.", "No Selection",
                    JOptionPane.WARNING_MESSAGE);
            return null;
        }
        return rows.get(row);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        portPartnerships = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        roundedPanel4 = new JSwing.RoundedPanel();
        sendReq = new javax.swing.JButton();
        portSelection = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        activePart = new javax.swing.JTable();
        jScrollPane2 = new javax.swing.JScrollPane();
        pendingPart = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        terminatePart = new javax.swing.JButton();
        acceptReq = new javax.swing.JButton();
        rejectReq = new javax.swing.JButton();
        reviewContractPartnershipButton = new javax.swing.JButton();

        setMaximumSize(new java.awt.Dimension(1060, 650));
        setMinimumSize(new java.awt.Dimension(1060, 650));
        setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Partnership Management");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 314, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        roundedPanel4.setBackground(new java.awt.Color(255, 255, 255));

        sendReq.setBackground(new java.awt.Color(0, 0, 102));
        sendReq.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        sendReq.setForeground(new java.awt.Color(255, 255, 255));
        sendReq.setText("       Send Request");
        sendReq.setBorder(null);
        sendReq.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        sendReq.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        sendReq.addActionListener(this::sendReqActionPerformed);

        portSelection.setEditable(true);
        portSelection.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        portSelection.setMaximumSize(new java.awt.Dimension(350, 52));
        portSelection.setMinimumSize(new java.awt.Dimension(350, 52));
        portSelection.setPreferredSize(new java.awt.Dimension(350, 52));
        portSelection.addActionListener(this::portSelectionActionPerformed);

        javax.swing.GroupLayout roundedPanel4Layout = new javax.swing.GroupLayout(roundedPanel4);
        roundedPanel4.setLayout(roundedPanel4Layout);
        roundedPanel4Layout.setHorizontalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(39, 39, 39)
                .addComponent(portSelection, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(53, 53, 53)
                .addComponent(sendReq, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(360, Short.MAX_VALUE))
        );
        roundedPanel4Layout.setVerticalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(portSelection, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sendReq, javax.swing.GroupLayout.DEFAULT_SIZE, 52, Short.MAX_VALUE))
                .addContainerGap(12, Short.MAX_VALUE))
        );

        jLabel5.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(0, 0, 102));
        jLabel5.setText("Request New Partnership");

        activePart.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Port ID", "Port Name", "Capability", "Connected Since"
            }
        ));
        jScrollPane1.setViewportView(activePart);
        if (activePart.getColumnModel().getColumnCount() > 0) {
            activePart.getColumnModel().getColumn(0).setMinWidth(150);
            activePart.getColumnModel().getColumn(0).setPreferredWidth(150);
            activePart.getColumnModel().getColumn(0).setMaxWidth(150);
        }

        pendingPart.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Port ID", "Port Name", "Request Type", "Status"
            }
        ));
        jScrollPane2.setViewportView(pendingPart);
        if (pendingPart.getColumnModel().getColumnCount() > 0) {
            pendingPart.getColumnModel().getColumn(0).setMinWidth(150);
            pendingPart.getColumnModel().getColumn(0).setPreferredWidth(150);
            pendingPart.getColumnModel().getColumn(0).setMaxWidth(150);
        }

        jLabel6.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Active Partnerships");

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Pending Partnership Requests");

        terminatePart.setBackground(new java.awt.Color(0, 0, 102));
        terminatePart.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        terminatePart.setForeground(new java.awt.Color(255, 255, 255));
        terminatePart.setText(" Terminate Selected Partnership");
        terminatePart.setBorder(null);
        terminatePart.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        terminatePart.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        terminatePart.addActionListener(this::terminatePartActionPerformed);

        acceptReq.setBackground(new java.awt.Color(0, 0, 102));
        acceptReq.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        acceptReq.setForeground(new java.awt.Color(255, 255, 255));
        acceptReq.setText(" Accept Request");
        acceptReq.setBorder(null);
        acceptReq.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        acceptReq.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        acceptReq.addActionListener(this::acceptReqActionPerformed);

        rejectReq.setBackground(new java.awt.Color(0, 0, 102));
        rejectReq.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        rejectReq.setForeground(new java.awt.Color(255, 255, 255));
        rejectReq.setText("  Reject Request");
        rejectReq.setBorder(null);
        rejectReq.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        rejectReq.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        rejectReq.addActionListener(this::rejectReqActionPerformed);

        reviewContractPartnershipButton.setBackground(new java.awt.Color(0, 0, 102));
        reviewContractPartnershipButton.setFont(new java.awt.Font("Gadugi", 1, 14)); // NOI18N
        reviewContractPartnershipButton.setForeground(new java.awt.Color(255, 255, 255));
        reviewContractPartnershipButton.setText(" Review Contract");
        reviewContractPartnershipButton.setBorder(null);
        reviewContractPartnershipButton.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        reviewContractPartnershipButton.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        reviewContractPartnershipButton.addActionListener(this::reviewContractPartnershipButtonActionPerformed);

        javax.swing.GroupLayout portPartnershipsLayout = new javax.swing.GroupLayout(portPartnerships);
        portPartnerships.setLayout(portPartnershipsLayout);
        portPartnershipsLayout.setHorizontalGroup(
            portPartnershipsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(portPartnershipsLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(portPartnershipsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(portPartnershipsLayout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, portPartnershipsLayout.createSequentialGroup()
                        .addGroup(portPartnershipsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(roundedPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(47, 47, 47))
                    .addGroup(portPartnershipsLayout.createSequentialGroup()
                        .addGroup(portPartnershipsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(portPartnershipsLayout.createSequentialGroup()
                                .addComponent(acceptReq, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(rejectReq, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(reviewContractPartnershipButton, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(terminatePart, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 582, Short.MAX_VALUE))))
        );
        portPartnershipsLayout.setVerticalGroup(
            portPartnershipsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(portPartnershipsLayout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(19, 19, 19)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(terminatePart, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel7)
                .addGap(2, 2, 2)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(portPartnershipsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(acceptReq, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rejectReq, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(reviewContractPartnershipButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(49, 49, 49))
        );

        add(portPartnerships, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void portSelectionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_portSelectionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_portSelectionActionPerformed

    private void sendReqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendReqActionPerformed
        Integer me = Session.getPortId();
        int idx = portSelection.getSelectedIndex();
        if (me == null || idx < 0 || idx >= targetPorts.size()) {
            JOptionPane.showMessageDialog(this, "Select a port to send the request to.",
                    "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Port target = targetPorts.get(idx);
        String type = (String) JOptionPane.showInputDialog(this,
                "Request type for " + target.getPortName() + ":", "Send Request",
                JOptionPane.PLAIN_MESSAGE, null, REQUEST_TYPES, REQUEST_TYPES[0]);
        if (type == null) {
            return;
        }
        runAction(() -> partnershipService.sendRequest(me, target.getId(), type));
    }//GEN-LAST:event_sendReqActionPerformed

    private void terminatePartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_terminatePartActionPerformed
        Integer me = Session.getPortId();
        Partnership p = selectedFrom(activePart, activeList, "a partnership");
        if (me == null || p == null) {
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Terminate this partnership? This cannot be undone.",
                "Confirm Termination", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        runAction(() -> partnershipService.terminate(me, p.getId()));
    }//GEN-LAST:event_terminatePartActionPerformed

    private void acceptReqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_acceptReqActionPerformed
        Integer me = Session.getPortId();
        Partnership p = selectedFrom(pendingPart, pendingList, "a request");
        if (me == null || p == null) {
            return;
        }
        runAction(() -> partnershipService.accept(me, p.getId()));

    }//GEN-LAST:event_acceptReqActionPerformed

    private void rejectReqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rejectReqActionPerformed
        Integer me = Session.getPortId();
        Partnership p = selectedFrom(pendingPart, pendingList, "a request");
        if (me == null || p == null) {
            return;
        }
        runAction(() -> partnershipService.reject(me, p.getId()));
    }//GEN-LAST:event_rejectReqActionPerformed

    private void reviewContractPartnershipButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_reviewContractPartnershipButtonActionPerformed
        Partnership p = selectedFrom(pendingPart, pendingList, "a request");
        if (p == null) {
            return;
        }
        try {
            Port sender = portService.findById(p.getPortAId());
            Port receiver = portService.findById(p.getPortBId());
            ContractDialog dialog = new ContractDialog(
                    (Frame) SwingUtilities.getWindowAncestor(this), p, sender, receiver);
            dialog.setVisible(true);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_reviewContractPartnershipButtonActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton acceptReq;
    private javax.swing.JTable activePart;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable pendingPart;
    private javax.swing.JPanel portPartnerships;
    private javax.swing.JComboBox<String> portSelection;
    private javax.swing.JButton rejectReq;
    private javax.swing.JButton reviewContractPartnershipButton;
    private JSwing.RoundedPanel roundedPanel4;
    private javax.swing.JButton sendReq;
    private javax.swing.JButton terminatePart;
    // End of variables declaration//GEN-END:variables
}
