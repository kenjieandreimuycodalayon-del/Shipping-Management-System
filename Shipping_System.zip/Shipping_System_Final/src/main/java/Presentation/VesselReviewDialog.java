package Presentation;

import Model.Port;
import Model.Vessel;
import Service.VesselService;
import UI.DialogKit;
import UI.TemplateUI;
import Util.IdGenerator;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.SQLException;

/**
 * Backs PendingApprovals -> Vessel Registrations tab (double-click a row). Same
 * layout as PermitReviewDialog: request details on the left, the uploaded
 * registration document on the right. It only reports the admin's decision;
 * PendingApprovals calls VesselService.
 */
public class VesselReviewDialog extends JDialog {

    public enum Decision {
        NONE, APPROVE, REJECT
    }

    private final Vessel vessel;
    private final Port port;
    private Decision decision = Decision.NONE;
    private BufferedImage documentImage;
    private String previewMessage;

    /**
     * @param port the port that requested the registration (may be null)
     */
    public VesselReviewDialog(Frame owner, Vessel vessel, Port port) {
        super(owner, "Vessel Registration Review", true);
        this.vessel = vessel;
        this.port = port;
        loadDocumentImage();
        buildUI();
        setSize(940, 680);
        setResizable(false);
        setLocationRelativeTo(owner);
    }

    public Decision getDecision() {
        return decision;
    }

    private void loadDocumentImage() {
        if (!vessel.isHasDocument()) {
            previewMessage = "No registration document was uploaded.";
            return;
        }
        try {
            byte[] data = new VesselService().vesselDocument(vessel.getId());
            documentImage = data != null ? ImageIO.read(new ByteArrayInputStream(data)) : null;
            if (documentImage == null) {
                previewMessage = "Preview not available for this file type.";
            }
        } catch (SQLException | IOException ex) {
            previewMessage = "Could not load document: " + ex.getMessage();
        }
    }

    private void buildUI() {
        JPanel header = DialogKit.header("Vessel Registration Review",
                "Check the request details against the uploaded document.",
                IdGenerator.vesselRegistryCode(vessel.getId()));

        JPanel cards = new JPanel(new GridLayout(1, 2, 20, 0));
        cards.setOpaque(false);
        cards.add(buildInfoCard());
        cards.add(DialogKit.documentCard(this, "Registration Document", documentImage, previewMessage,
                "Document \u2014 " + vessel.getDocumentName()));

        JButton approve = DialogKit.primary("Approve Vessel");
        approve.addActionListener(e -> {
            decision = Decision.APPROVE;
            dispose();
        });
        JButton reject = DialogKit.danger("Reject Request");
        reject.addActionListener(e -> {
            decision = Decision.REJECT;
            dispose();
        });
        JButton close = DialogKit.secondary("Close");
        close.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(cards), DialogKit.footer(null, close, reject, approve));
        DialogKit.escToClose(this);
    }

    private JPanel buildInfoCard() {
        JPanel card = DialogKit.card("Vessel Information");

        String portText = null;
        if (port != null) {
            portText = port.getPortName() + " (" + (port.getPortCode() != null ? port.getPortCode() : "#" + port.getId()) + ")";
        }

        JPanel rows = DialogKit.form();
        DialogKit.infoRow(rows, 0, "Registry No.", IdGenerator.vesselRegistryCode(vessel.getId()));
        DialogKit.infoRow(rows, 1, "IMO Number", vessel.getImoNumber());
        DialogKit.infoRow(rows, 2, "Vessel Name", vessel.getVesselName());
        DialogKit.infoRow(rows, 3, "Carrier / Line", vessel.getCarrierLine());
        DialogKit.infoRow(rows, 4, "Max Cap (Tons)", String.valueOf(vessel.getMaxCapacityTons()));
        DialogKit.infoRow(rows, 5, "Owner Port", portText);
        DialogKit.infoRow(rows, 6, "Requested By", vessel.getRequestedBy());
        String status = vessel.getStatus() != null ? vessel.getStatus().name() : null;
        JLabel statusLabel = DialogKit.infoRow(rows, 7, "Status", status);
        if (status != null) {
            statusLabel.setFont(TemplateUI.font(Font.BOLD, 14));
            statusLabel.setForeground(TemplateUI.statusColor(status));
        }
        DialogKit.infoRow(rows, 8, "Document", vessel.getDocumentName());

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(rows, BorderLayout.NORTH);
        card.add(wrap, BorderLayout.CENTER);
        return card;
    }
}
