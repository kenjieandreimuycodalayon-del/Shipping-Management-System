package Service;

import DAO.PortDAO;
import DAO.VesselDAO;
import Model.Port;
import Model.Vessel;

import java.sql.SQLException;
import java.util.List;

public class VesselService {

    private final VesselDAO vesselDAO = new VesselDAO();
    private final PortDAO portDAO = new PortDAO();

    /**
     * Ship Registry -> "Request Ship Registration". The vessel belongs to the
     * ACTING port, needs a registration document, and starts PENDING.
     * Throws IllegalStateException with a message the dialog can show directly.
     */
    public int requestRegistration(int actingPortId, Vessel vessel, String requestedBy,
            String documentName, byte[] documentData) throws SQLException {
        Port port = portDAO.findById(actingPortId);
        if (port == null || port.getStatus() != Port.Status.ACTIVE) {
            throw new IllegalStateException("Your port must be ACTIVE to request a ship registration.");
        }
        if (vessel.getMaxCapacityTons() <= 0) {
            throw new IllegalStateException("Max Capacity must be greater than zero.");
        }
        if (documentData == null || documentData.length == 0) {
            throw new IllegalStateException("Please upload the vessel's registration document.");
        }
        vessel.setStatus(Vessel.Status.PENDING);
        vessel.setRequestedBy(requestedBy);
        vessel.setPortId(actingPortId);
        vessel.setDocumentName(documentName);
        vessel.setDocumentData(documentData);
        try {
            return vesselDAO.insert(vessel);
        } catch (SQLException ex) {
            // 1062 = duplicate key: imo_number is UNIQUE
            if (ex.getErrorCode() == 1062) {
                throw new IllegalStateException("A vessel with this IMO number is already registered.");
            }
            throw ex;
        }
    }

    /** Pending Approvals -> "Approve Vessel" (Vessel Registrations tab). */
    public void approve(int vesselId) throws SQLException {
        vesselDAO.updateStatus(vesselId, Vessel.Status.APPROVED);
    }

    public void reject(int vesselId) throws SQLException {
        vesselDAO.updateStatus(vesselId, Vessel.Status.REJECTED);
    }

    /**
     * Pending Approvals -> "Approve Vessel". PENDING -> ACTIVE in one step,
     * because the Dispatch Queue only offers ACTIVE vessels to the port.
     */
    public void approveRegistration(int vesselId, String remarks) throws SQLException {
        requirePending(vesselId);
        vesselDAO.updateStatus(vesselId, Vessel.Status.ACTIVE, blankToNull(remarks));
    }

    /** Pending Approvals -> "Reject Request" (Vessel Registrations tab). */
    public void rejectRegistration(int vesselId, String remarks) throws SQLException {
        requirePending(vesselId);
        if (remarks == null || remarks.isBlank()) {
            throw new IllegalStateException("Please enter a reason for rejecting.");
        }
        vesselDAO.updateStatus(vesselId, Vessel.Status.REJECTED, remarks.trim());
    }

    private static String blankToNull(String text) {
        return text == null || text.isBlank() ? null : text.trim();
    }

    /** A stale screen must not re-decide a request somebody already handled. */
    private void requirePending(int vesselId) throws SQLException {
        Vessel v = vesselDAO.findById(vesselId);
        if (v == null) {
            throw new IllegalStateException("Vessel not found.");
        }
        if (v.getStatus() != Vessel.Status.PENDING) {
            throw new IllegalStateException("This request was already handled.");
        }
    }

    public void activate(int vesselId) throws SQLException {
        vesselDAO.updateStatus(vesselId, Vessel.Status.ACTIVE);
    }

    public void deactivate(int vesselId) throws SQLException {
        vesselDAO.updateStatus(vesselId, Vessel.Status.INACTIVE);
    }

    public List<Vessel> pendingRegistrations() throws SQLException {
        return vesselDAO.findByStatus(Vessel.Status.PENDING);
    }

    /** Every ACTIVE vessel in the network (admin side). */
    public List<Vessel> availableFleet() throws SQLException {
        return vesselDAO.findByStatus(Vessel.Status.ACTIVE);
    }

    /** The ACTIVE vessels THIS port owns (Dispatch Queue -> "Assign Vessel"). */
    public List<Vessel> availableFleet(int portId) throws SQLException {
        return vesselDAO.findByPort(portId, Vessel.Status.ACTIVE, null);
    }

    /** Ship Registry table: only this port's vessels. */
    public List<Vessel> findForPort(int portId, Vessel.Status status, String keyword) throws SQLException {
        return vesselDAO.findByPort(portId, status, keyword);
    }

    public byte[] vesselDocument(int vesselId) throws SQLException {
        return vesselDAO.findDocument(vesselId);
    }

    public List<Vessel> findByStatus(Vessel.Status status) throws SQLException {
        return vesselDAO.findByStatus(status);
    }

    public List<Vessel> search(String keyword) throws SQLException {
        return (keyword == null || keyword.isBlank()) ? vesselDAO.findByStatus(null) : vesselDAO.search(keyword);
    }
}