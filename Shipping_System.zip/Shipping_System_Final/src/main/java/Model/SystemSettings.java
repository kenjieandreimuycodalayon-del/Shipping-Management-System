package Model;

public class SystemSettings {

    private String sysRole;
    private int maxQueuePerPort;
    private int maxCargoPerItem;
    private String networkStatus;

    public SystemSettings() {
    }

    public String getSysRole() { return sysRole; }
    public void setSysRole(String sysRole) { this.sysRole = sysRole; }

    public int getMaxQueuePerPort() { return maxQueuePerPort; }
    public void setMaxQueuePerPort(int maxQueuePerPort) { this.maxQueuePerPort = maxQueuePerPort; }

    public int getMaxCargoPerItem() { return maxCargoPerItem; }
    public void setMaxCargoPerItem(int maxCargoPerItem) { this.maxCargoPerItem = maxCargoPerItem; }

    public String getNetworkStatus() { return networkStatus; }
    public void setNetworkStatus(String networkStatus) { this.networkStatus = networkStatus; }
}
