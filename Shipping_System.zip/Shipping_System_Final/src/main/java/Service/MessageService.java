package Service;

import DAO.MessageDAO;
import Model.Message;
import Model.MessageContact;
import Model.User;
import Util.DBConnection;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/**
 * Rule violations throw IllegalStateException with a message the dialog can
 * show directly.
 */
public class MessageService {

    private static final int MAX_SUBJECT = 150;
    private static final int MAX_BODY = 5000;

    private final MessageDAO dao = new MessageDAO();

    public void send(User sender, int recipientId, String subject, String body) throws SQLException {
        String s = clean(subject, "Subject", MAX_SUBJECT);
        String b = clean(body, "Message", MAX_BODY);
        if (recipientId == sender.getId()) {
            throw new IllegalStateException("You cannot send a message to yourself.");
        }
        boolean allowed = false;
        for (MessageContact c : dao.findContacts(sender.getId())) {
            if (c.getUserId() == recipientId) {
                allowed = true;
                break;
            }
        }
        if (!allowed) {
            throw new IllegalStateException("That recipient is not available (the port may be inactive).");
        }
        try (Connection conn = DBConnection.getConnection()) {
            dao.insert(conn, build(sender.getId(), recipientId, s, b));
        }
    }

    /**
     * Admin only: one message to every user of an ACTIVE port, in one
     * transaction. Returns how many got it.
     */
    public int broadcast(User sender, String subject, String body) throws SQLException {
        if (sender.getRole() != User.Role.ADMIN) {
            throw new IllegalStateException("Only administrators can broadcast messages.");
        }
        String s = clean(subject, "Subject", MAX_SUBJECT);
        String b = clean(body, "Message", MAX_BODY);
        int count = 0;
        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                for (MessageContact c : dao.findContacts(sender.getId())) {
                    if (c.getRole() == User.Role.PORT) {
                        dao.insert(conn, build(sender.getId(), c.getUserId(), s, b));
                        count++;
                    }
                }
                if (count == 0) {
                    throw new IllegalStateException("There are no active ports to message.");
                }
                conn.commit();
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                throw ex;
            }
        }
        return count;
    }

    public List<Message> inbox(int userId) throws SQLException {
        return dao.findInbox(userId);
    }

    public List<Message> sent(int userId) throws SQLException {
        return dao.findSent(userId);
    }

    public List<MessageContact> contacts(int userId) throws SQLException {
        return dao.findContacts(userId);
    }

    public int unreadCount(int userId) throws SQLException {
        return dao.countUnread(userId);
    }

    public void markRead(int messageId, int userId) throws SQLException {
        dao.markRead(messageId, userId);
    }

    public void delete(int messageId, int userId) throws SQLException {
        dao.delete(messageId, userId);
    }

    private static Message build(int senderId, int recipientId, String subject, String body) {
        Message m = new Message();
        m.setSenderId(senderId);
        m.setRecipientId(recipientId);
        m.setSubject(subject);
        m.setBody(body);
        return m;
    }

    private static String clean(String text, String field, int max) {
        String t = text == null ? "" : text.trim();
        if (t.isEmpty()) {
            throw new IllegalStateException(field + " is required.");
        }
        if (t.length() > max) {
            throw new IllegalStateException(field + " must be " + max + " characters or fewer.");
        }
        return t;
    }
}
