package DAO;

import Model.PermitApplication;
import Model.PermitReview;
import Util.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PermitApplicationDAO {

    public int insert(Connection conn, PermitApplication pa) throws SQLException {
        String sql = "INSERT INTO permit_applications (port_id, permit_no, date_submitted, date_approved, "
                + "status, admin_remarks, document_name, document_data) VALUES (?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, pa);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    pa.setId(keys.getInt(1));
                    return pa.getId();
                }
            }
        }
        return -1;
    }

    public List<PermitReview> findReviewsByStatus(PermitApplication.Status status) throws SQLException {
        String sql = "SELECT pa.id AS permit_id, pa.port_id, pa.permit_no, pa.date_submitted, "
                + "pa.status AS permit_status, pa.admin_remarks, pa.document_name, "
                + "(pa.document_data IS NOT NULL) AS has_document, "
                + "p.port_code, p.port_name, p.registered_name, p.primary_capability, u.username, u.email "
                + "FROM permit_applications pa JOIN ports p ON p.id = pa.port_id "
                + "LEFT JOIN users u ON u.port_id = p.id AND u.role = 'PORT' "
                + "WHERE pa.status=? ORDER BY pa.date_submitted DESC, pa.id DESC";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status.name());
            try (ResultSet rs = ps.executeQuery()) {
                List<PermitReview> results = new ArrayList<>();
                while (rs.next()) {
                    PermitReview r = new PermitReview();
                    r.setPermitId(rs.getInt("permit_id"));
                    r.setPortId(rs.getInt("port_id"));
                    r.setPermitNo(rs.getString("permit_no"));
                    Date submitted = rs.getDate("date_submitted");
                    r.setDateSubmitted(submitted != null ? submitted.toLocalDate() : null);
                    r.setStatus(PermitApplication.Status.valueOf(rs.getString("permit_status")));
                    r.setAdminRemarks(rs.getString("admin_remarks"));
                    r.setDocumentName(rs.getString("document_name"));
                    r.setHasDocument(rs.getBoolean("has_document"));
                    r.setPortCode(rs.getString("port_code"));
                    r.setPortName(rs.getString("port_name"));
                    r.setRegisteredName(rs.getString("registered_name"));
                    r.setPrimaryCapability(rs.getString("primary_capability"));
                    r.setUsername(rs.getString("username"));
                    r.setEmail(rs.getString("email"));
                    results.add(r);
                }
                return results;
            }
        }
    }

    /**
     * Loaded on demand, only when the admin opens a request.
     */
    public byte[] findDocument(int permitId) throws SQLException {
        String sql = "SELECT document_data FROM permit_applications WHERE id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, permitId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getBytes(1) : null;
            }
        }
    }

    public void updateStatus(Connection conn, int id, PermitApplication.Status status,
            LocalDate dateApproved, String remarks) throws SQLException {
        String sql = "UPDATE permit_applications SET status=?, date_approved=?, admin_remarks=? WHERE id=?";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status.name());
            ps.setDate(2, dateApproved != null ? Date.valueOf(dateApproved) : null);
            ps.setString(3, remarks);
            ps.setInt(4, id);
            ps.executeUpdate();
        }
    }

    /**
     * Called once, right after insert(), with the code generated from the real
     * id.
     */
    public void updatePermitNo(Connection conn, int id, String permitNo) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement("UPDATE permit_applications SET permit_no=? WHERE id=?")) {
            ps.setString(1, permitNo);
            ps.setInt(2, id);
            ps.executeUpdate();
        }
    }

    public List<PermitApplication> findByStatus(PermitApplication.Status status) throws SQLException {
        String sql = "SELECT * FROM permit_applications" + (status != null ? " WHERE status=?" : "")
                + " ORDER BY date_submitted DESC";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            if (status != null) {
                ps.setString(1, status.name());
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<PermitApplication> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }

    public List<PermitApplication> findByPortId(int portId) throws SQLException {
        String sql = "SELECT * FROM permit_applications WHERE port_id=? ORDER BY date_submitted DESC";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, portId);
            try (ResultSet rs = ps.executeQuery()) {
                List<PermitApplication> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }

    private void bind(PreparedStatement ps, PermitApplication pa) throws SQLException {
        ps.setInt(1, pa.getPortId());
        ps.setString(2, pa.getPermitNo());
        ps.setDate(3, pa.getDateSubmitted() != null ? Date.valueOf(pa.getDateSubmitted()) : null);
        ps.setDate(4, pa.getDateApproved() != null ? Date.valueOf(pa.getDateApproved()) : null);
        ps.setString(5, pa.getStatus() != null ? pa.getStatus().name() : PermitApplication.Status.PENDING.name());
        ps.setString(6, pa.getAdminRemarks());
        ps.setString(7, pa.getDocumentName());
        if (pa.getDocumentData() != null) {
            ps.setBytes(8, pa.getDocumentData());
        } else {
            ps.setNull(8, Types.LONGVARBINARY);
        }
    }

    private PermitApplication map(ResultSet rs) throws SQLException {
        PermitApplication pa = new PermitApplication();
        pa.setId(rs.getInt("id"));
        pa.setPortId(rs.getInt("port_id"));
        pa.setPermitNo(rs.getString("permit_no"));
        Date submitted = rs.getDate("date_submitted");
        pa.setDateSubmitted(submitted != null ? submitted.toLocalDate() : null);
        Date approved = rs.getDate("date_approved");
        pa.setDateApproved(approved != null ? approved.toLocalDate() : null);
        pa.setStatus(PermitApplication.Status.valueOf(rs.getString("status")));
        pa.setAdminRemarks(rs.getString("admin_remarks"));
        return pa;
    }
}
