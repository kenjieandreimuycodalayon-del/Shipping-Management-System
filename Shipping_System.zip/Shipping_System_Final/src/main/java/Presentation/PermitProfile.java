/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import Model.PermitApplication;
import Model.Port;
import Service.PortService;
import UI.TemplateUI;
import Util.Session;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import javax.swing.UIManager;

/**
 *
 * @author Kenji
 */
public class PermitProfile extends javax.swing.JPanel {
    private final PortService portService = new PortService();

    /**
     * Creates new form PermitProfile
     */
    public PermitProfile() {
        initComponents();
        applyModernStyle();
        
        // Do NOT load in the constructor: PortPanel builds all its screens at app start,
        // before anyone has logged in, so Session.getPortId() would still be null.
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadProfile();
            }
        });
    }
    
    private String show(Object value) {
        return value == null || value.toString().isBlank() ? "—" : value.toString();
    }
    
    private void applyModernStyle() {
        TemplateUI.stylePage(jPanel1, jPanel2, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel5 (Port Permits)
        roundedPanel1.setBackground(UIManager.getColor("Table.background"));
        roundedPanel1.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");
        
        roundedPanel2.setBackground(UIManager.getColor("Table.background"));
        roundedPanel2.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");
        
        roundedPanel3.setBackground(UIManager.getColor("Table.background"));
        roundedPanel3.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");

        TemplateUI.styleTextField(pIdField, null);
        TemplateUI.styleTextField(pNameField, null);
        TemplateUI.styleTextField(statField, null);
        
        TemplateUI.styleTextField(regName, null);
        TemplateUI.styleTextField(primCap, null);
        TemplateUI.styleTextField(dispLim, null);
        TemplateUI.styleTextField(cargoLim, null);
        
        TemplateUI.styleTextField(permAuth, null);
        TemplateUI.styleTextField(subDate, null);
        TemplateUI.styleTextField(expDate, null);
        TemplateUI.styleTextField(lastRen, null);
        
        TemplateUI.styleSection(jLabel1);
        jScrollPane1.setBorder(null);
        TemplateUI.styleTable(applicationTable, 3, 2);
        


    }
    
    private DefaultTableModel readOnlyModel(Object[][] data, String[] columns) {
        return new DefaultTableModel(data, columns) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }
    
    private void loadProfile() {
        Integer me = Session.getPortId();
        if (me == null) {
            return;
        }
        try {
            Port port = portService.findById(me);
            if (port == null) {
                JOptionPane.showMessageDialog(this, "Port record not found.",
                        "Permit Profile", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // Top Summary Card/Banner
            pIdField.setText(show(port.getPortCode() != null ? port.getPortCode() : "#" + port.getId()));
            pNameField.setText(show(port.getPortName()));
            statField.setText(show(port.getStatus()));

            // Port Profile Specifications
            regName.setText(show(port.getRegisteredName()));
            primCap.setText(show(port.getPrimaryCapability()));
            dispLim.setText(String.valueOf(port.getDispatchLimit()));
            cargoLim.setText(String.valueOf(port.getCargoItemLimit()));

            // Operating Compliance Summary
            permAuth.setText(show(port.getPermitAuthority()));
            subDate.setText(show(port.getSubmittedDate()));
            expDate.setText(show(port.getExpirationDate()));
            lastRen.setText(show(port.getLastRenewal()));

            // Permit Application & Compliance History (newest first)
            List<PermitApplication> history = portService.permitHistory(me);
            Object[][] data = new Object[history.size()][5];
            for (int i = 0; i < history.size(); i++) {
                PermitApplication pa = history.get(i);
                data[i][0] = show(pa.getPermitNo());
                data[i][1] = show(pa.getDateSubmitted());
                data[i][2] = show(pa.getDateApproved());
                data[i][3] = pa.getStatus();
                data[i][4] = show(pa.getAdminRemarks());
            }
            applicationTable.setModel(readOnlyModel(data,
                    new String[]{"Permit No.", "Date Submitted", "Date Approved", "Status", "Admin Remarks"}));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load permit profile: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        roundedPanel1 = new JSwing.RoundedPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        pIdField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        pNameField = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        statField = new javax.swing.JTextField();
        roundedPanel2 = new JSwing.RoundedPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        regName = new javax.swing.JTextField();
        primCap = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        dispLim = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        cargoLim = new javax.swing.JTextField();
        roundedPanel3 = new JSwing.RoundedPanel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        permAuth = new javax.swing.JTextField();
        subDate = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        expDate = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        lastRen = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        applicationTable = new javax.swing.JTable();
        jLabel21 = new javax.swing.JLabel();

        setLayout(new java.awt.BorderLayout());

        jPanel1.setMaximumSize(new java.awt.Dimension(1060, 650));
        jPanel1.setMinimumSize(new java.awt.Dimension(1060, 650));
        jPanel1.setPreferredSize(new java.awt.Dimension(1060, 650));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Port Profile & Operating License");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        roundedPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel11.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 102));
        jLabel11.setText("Top Summary Card/Banner");

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Port ID:");

        pIdField.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        pIdField.setEnabled(false);
        pIdField.addActionListener(this::pIdFieldActionPerformed);

        jLabel8.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("Port Name:");

        pNameField.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        pNameField.setEnabled(false);
        pNameField.addActionListener(this::pNameFieldActionPerformed);

        jLabel9.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(0, 0, 102));
        jLabel9.setText("Status:");

        statField.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        statField.setEnabled(false);
        statField.addActionListener(this::statFieldActionPerformed);

        javax.swing.GroupLayout roundedPanel1Layout = new javax.swing.GroupLayout(roundedPanel1);
        roundedPanel1.setLayout(roundedPanel1Layout);
        roundedPanel1Layout.setHorizontalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pIdField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(pNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(jLabel9)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(statField, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(82, Short.MAX_VALUE))
        );
        roundedPanel1Layout.setVerticalGroup(
            roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(roundedPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(pIdField, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(pNameField, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9)
                    .addComponent(statField, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        roundedPanel2.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel2.setMaximumSize(new java.awt.Dimension(470, 205));
        roundedPanel2.setMinimumSize(new java.awt.Dimension(470, 205));
        roundedPanel2.setPreferredSize(new java.awt.Dimension(470, 205));

        jLabel12.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(0, 0, 102));
        jLabel12.setText("Port Profile Specifications");

        jLabel10.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("Registered Name: ");

        jLabel13.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 0, 102));
        jLabel13.setText("Primary Capability: ");

        regName.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        regName.setEnabled(false);
        regName.addActionListener(this::regNameActionPerformed);

        primCap.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        primCap.setEnabled(false);
        primCap.addActionListener(this::primCapActionPerformed);

        jLabel14.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 0, 102));
        jLabel14.setText("Dispatch Limit:");

        dispLim.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        dispLim.setEnabled(false);
        dispLim.addActionListener(this::dispLimActionPerformed);

        jLabel15.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 0, 102));
        jLabel15.setText("Cargo Item Limit:");

        cargoLim.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        cargoLim.setEnabled(false);
        cargoLim.addActionListener(this::cargoLimActionPerformed);

        javax.swing.GroupLayout roundedPanel2Layout = new javax.swing.GroupLayout(roundedPanel2);
        roundedPanel2.setLayout(roundedPanel2Layout);
        roundedPanel2Layout.setHorizontalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28))
                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                        .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(roundedPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cargoLim, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(roundedPanel2Layout.createSequentialGroup()
                                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(roundedPanel2Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(jLabel10))
                                    .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(regName, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(primCap, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(dispLim, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 44, Short.MAX_VALUE))))
        );
        roundedPanel2Layout.setVerticalGroup(
            roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(regName, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(primCap, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14)
                    .addComponent(dispLim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(roundedPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cargoLim, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        roundedPanel3.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel3.setMaximumSize(new java.awt.Dimension(470, 205));
        roundedPanel3.setMinimumSize(new java.awt.Dimension(470, 205));
        roundedPanel3.setPreferredSize(new java.awt.Dimension(470, 205));

        jLabel16.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(0, 0, 102));
        jLabel16.setText("Operating Compliance Summary");

        jLabel17.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel17.setForeground(new java.awt.Color(0, 0, 102));
        jLabel17.setText("Permit Authority:");

        jLabel18.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(0, 0, 102));
        jLabel18.setText("Submitted Date:");

        permAuth.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        permAuth.setEnabled(false);
        permAuth.addActionListener(this::permAuthActionPerformed);

        subDate.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        subDate.setEnabled(false);
        subDate.addActionListener(this::subDateActionPerformed);

        jLabel19.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(0, 0, 102));
        jLabel19.setText("Expiration Date:");

        expDate.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        expDate.setEnabled(false);
        expDate.addActionListener(this::expDateActionPerformed);

        jLabel20.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(0, 0, 102));
        jLabel20.setText("Last Renewal:");

        lastRen.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        lastRen.setEnabled(false);
        lastRen.addActionListener(this::lastRenActionPerformed);

        javax.swing.GroupLayout roundedPanel3Layout = new javax.swing.GroupLayout(roundedPanel3);
        roundedPanel3.setLayout(roundedPanel3Layout);
        roundedPanel3Layout.setHorizontalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel3Layout.createSequentialGroup()
                .addGroup(roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(roundedPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lastRen, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(roundedPanel3Layout.createSequentialGroup()
                        .addGroup(roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(roundedPanel3Layout.createSequentialGroup()
                                .addGap(24, 24, 24)
                                .addGroup(roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(roundedPanel3Layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(jLabel18, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                    .addComponent(jLabel17))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(permAuth, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(subDate, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(expDate, javax.swing.GroupLayout.PREFERRED_SIZE, 257, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 51, Short.MAX_VALUE))
            .addGroup(roundedPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel3Layout.setVerticalGroup(
            roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel16)
                .addGap(18, 18, 18)
                .addGroup(roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel17)
                    .addComponent(permAuth, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(subDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel18))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel19)
                    .addComponent(expDate, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(roundedPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lastRen, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel20))
                .addContainerGap(30, Short.MAX_VALUE))
        );

        applicationTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Permit No.", "Date Submitted", "Date Approved", "Status", "Admin Remarks"
            }
        ));
        jScrollPane1.setViewportView(applicationTable);

        jLabel21.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 0, 102));
        jLabel21.setText("Permit Application & Compliance History");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 981, Short.MAX_VALUE)
                            .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 377, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(29, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(roundedPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(roundedPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(roundedPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(roundedPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(roundedPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jLabel21)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        add(jPanel1, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void pIdFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pIdFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pIdFieldActionPerformed

    private void pNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pNameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pNameFieldActionPerformed

    private void statFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_statFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_statFieldActionPerformed

    private void regNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_regNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_regNameActionPerformed

    private void primCapActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_primCapActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_primCapActionPerformed

    private void dispLimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dispLimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dispLimActionPerformed

    private void cargoLimActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cargoLimActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cargoLimActionPerformed

    private void permAuthActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_permAuthActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_permAuthActionPerformed

    private void subDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_subDateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_subDateActionPerformed

    private void expDateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_expDateActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_expDateActionPerformed

    private void lastRenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lastRenActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lastRenActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable applicationTable;
    private javax.swing.JTextField cargoLim;
    private javax.swing.JTextField dispLim;
    private javax.swing.JTextField expDate;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lastRen;
    private javax.swing.JTextField pIdField;
    private javax.swing.JTextField pNameField;
    private javax.swing.JTextField permAuth;
    private javax.swing.JTextField primCap;
    private javax.swing.JTextField regName;
    private JSwing.RoundedPanel roundedPanel1;
    private JSwing.RoundedPanel roundedPanel2;
    private JSwing.RoundedPanel roundedPanel3;
    private javax.swing.JTextField statField;
    private javax.swing.JTextField subDate;
    // End of variables declaration//GEN-END:variables
}
