package Presentation;

import Model.MessageContact;
import Model.User;
import Service.MessageService;
import UI.DialogKit;
import UI.TemplateUI;

import javax.swing.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

/**
 * New message / reply. Admins get an extra "All active ports" broadcast entry.
 */
public class ComposeMessageDialog extends JDialog {

    private final JComboBox<MessageContact> toBox = new JComboBox<>();
    private final JTextField subjectField = new JTextField();
    private final JTextArea bodyArea = new JTextArea();

    private final MessageService service = new MessageService();
    private final User sender;
    private boolean sent = false;

    /**
     * @param replyToUserId pre-selects this recipient (null for a new message)
     * @param subject pre-filled subject (null for blank)
     */
    public ComposeMessageDialog(Window owner, User sender, Integer replyToUserId, String subject) {
        super(owner, replyToUserId != null ? "Reply" : "New Message", ModalityType.APPLICATION_MODAL);
        this.sender = sender;
        loadContacts(replyToUserId);
        buildUI();
        if (subject != null) {
            subjectField.setText(subject);
        }
        DialogKit.finish(this, owner, 600);
    }

    private void loadContacts(Integer replyToUserId) {
        try {
            if (sender.getRole() == User.Role.ADMIN) {
                toBox.addItem(new MessageContact(MessageContact.BROADCAST,
                        "All active ports (broadcast)", User.Role.PORT));
            }
            List<MessageContact> contacts = service.contacts(sender.getId());
            for (MessageContact c : contacts) {
                toBox.addItem(c);
                if (replyToUserId != null && c.getUserId() == replyToUserId) {
                    toBox.setSelectedItem(c);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load recipients: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void buildUI() {
        JPanel header = DialogKit.header("New Message", "Send a message through the Lodestar network.", null);

        bodyArea.setLineWrap(true);
        bodyArea.setWrapStyleWord(true);
        bodyArea.setFont(TemplateUI.font(Font.PLAIN, 14));
        bodyArea.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        JScrollPane bodyScroll = new JScrollPane(bodyArea);
        bodyScroll.setBorder(BorderFactory.createLineBorder(DialogKit.LINE));
        bodyScroll.setPreferredSize(new Dimension(480, 190));

        JPanel form = DialogKit.form();
        DialogKit.addField(form, 0, 0, 2, "To", toBox);
        DialogKit.addField(form, 1, 0, 2, "Subject", subjectField);
        DialogKit.addField(form, 2, 0, 2, "Message", bodyScroll);

        JPanel card = DialogKit.card(null);
        card.add(form, BorderLayout.CENTER);

        JButton send = DialogKit.primary("Send");
        send.addActionListener(e -> onSend());
        JButton cancel = DialogKit.secondary("Cancel");
        cancel.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(card), DialogKit.footer(null, cancel, send));
        DialogKit.escToClose(this);
    }

    private void onSend() {
        MessageContact to = (MessageContact) toBox.getSelectedItem();
        if (to == null) {
            JOptionPane.showMessageDialog(this, "Choose a recipient.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            if (to.getUserId() == MessageContact.BROADCAST) {
                int confirm = JOptionPane.showConfirmDialog(this,
                        "Send this message to every active port?", "Confirm Broadcast",
                        JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                if (confirm != JOptionPane.YES_OPTION) {
                    return;
                }
                int n = service.broadcast(sender, subjectField.getText(), bodyArea.getText());
                JOptionPane.showMessageDialog(this, "Message sent to " + n + " port(s).",
                        "Success", JOptionPane.INFORMATION_MESSAGE);
            } else {
                service.send(sender, to.getUserId(), subjectField.getText(), bodyArea.getText());
            }
            sent = true;
            dispose();
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Cannot send", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSent() {
        return sent;
    }
}
