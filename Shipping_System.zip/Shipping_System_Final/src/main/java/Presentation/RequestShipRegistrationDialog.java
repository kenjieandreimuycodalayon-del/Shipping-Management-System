package Presentation;

import Model.Vessel;
import Service.VesselService;
import UI.DialogKit;
import UI.TemplateUI;
import Util.Session;
import com.formdev.flatlaf.FlatClientProperties;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.sql.SQLException;

public class RequestShipRegistrationDialog extends JDialog {

    private static final long MAX_DOCUMENT_BYTES = 5L * 1024 * 1024;
    private static final String NO_FILE_TEXT = "No file selected";

    private final JTextField imoField = new JTextField(20);
    private final JTextField vesselNameField = new JTextField(20);
    private final JTextField carrierLineField = new JTextField(20);
    private final JTextField capacityField = new JTextField(20);
    private final JTextField requestedByField = new JTextField(20);
    private final JLabel documentLabel = new JLabel(NO_FILE_TEXT);

    private final VesselService vesselService = new VesselService();
    private final Integer myPortId = Session.getPortId();
    private byte[] documentBytes;
    private String documentFileName;
    private boolean succeeded = false;

    public RequestShipRegistrationDialog(Frame owner) {
        super(owner, "Request Ship Registration", true);
        buildUI();
        DialogKit.finish(this, owner, 600);
    }

    private void buildUI() {
        JPanel header = DialogKit.header("Request Ship Registration",
                "Submitted to the administrator for approval.", null);

        imoField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "7 digits");
        capacityField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "e.g. 50000");

        // registration document picker
        documentLabel.setFont(TemplateUI.font(Font.PLAIN, 14));
        documentLabel.setForeground(DialogKit.MUTED);
        JButton browse = DialogKit.secondary("Choose Photo...");
        browse.addActionListener(e -> onChooseDocument());
        JPanel documentPanel = new JPanel(new BorderLayout(12, 0));
        documentPanel.setOpaque(false);
        documentPanel.add(documentLabel, BorderLayout.CENTER);
        documentPanel.add(browse, BorderLayout.EAST);

        JPanel form = DialogKit.form();
        DialogKit.addField(form, 0, 0, 1, "IMO Number", imoField);
        DialogKit.addField(form, 0, 1, 1, "Max Capacity (tons)", capacityField);
        DialogKit.addField(form, 1, 0, 2, "Vessel Name", vesselNameField);
        DialogKit.addField(form, 2, 0, 1, "Carrier / Line", carrierLineField);
        DialogKit.addField(form, 2, 1, 1, "Requested By", requestedByField);

        JLabel docTitle = new JLabel("Registration Document (JPG or PNG, max 5 MB)");
        docTitle.setFont(TemplateUI.font(Font.BOLD, 13));
        docTitle.setForeground(DialogKit.TEXT);
        JPanel docSection = new JPanel(new BorderLayout(0, 5));
        docSection.setOpaque(false);
        docSection.add(docTitle, BorderLayout.NORTH);
        docSection.add(documentPanel, BorderLayout.CENTER);

        JPanel card = DialogKit.card(null);
        card.add(form, BorderLayout.CENTER);
        card.add(docSection, BorderLayout.SOUTH);

        JButton submit = DialogKit.primary("Submit Request");
        submit.addActionListener(e -> onSubmit());
        JButton cancel = DialogKit.secondary("Cancel");
        cancel.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(card), DialogKit.footer(null, cancel, submit));
        DialogKit.escToClose(this);
        getRootPane().setDefaultButton(submit);
    }

    private void onChooseDocument() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Select Vessel Registration Document");
        fc.setFileFilter(new FileNameExtensionFilter("Images (JPG, PNG)", "jpg", "jpeg", "png"));
        if (fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File f = fc.getSelectedFile();
        if (f.length() > MAX_DOCUMENT_BYTES) {
            JOptionPane.showMessageDialog(this, "Photo must be 5 MB or smaller.",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            byte[] bytes = Files.readAllBytes(f.toPath());
            if (ImageIO.read(new ByteArrayInputStream(bytes)) == null) {
                JOptionPane.showMessageDialog(this, "That file is not a valid image.",
                        "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
            documentBytes = bytes;
            documentFileName = f.getName();
            documentLabel.setText(f.getName());
            documentLabel.setToolTipText(f.getName());
            documentLabel.setForeground(DialogKit.TEXT);
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Could not read file: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onSubmit() {
        if (myPortId == null) {
            JOptionPane.showMessageDialog(this, "No port is logged in.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String imo = imoField.getText().trim();
        String name = vesselNameField.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vessel Name is required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (!imo.matches("\\d{7}")) {
            JOptionPane.showMessageDialog(this, "IMO Number must be exactly 7 digits (real IMO ship numbers always are).",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        double capacity;
        try {
            capacity = Double.parseDouble(capacityField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Max Capacity must be a number.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String requestedBy = requestedByField.getText().trim();
        if (requestedBy.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Requested By is required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (documentBytes == null) {
            JOptionPane.showMessageDialog(this, "Please upload a photo of the vessel's registration document.",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Vessel vessel = new Vessel();
        vessel.setImoNumber(imo);
        vessel.setVesselName(name);
        vessel.setCarrierLine(carrierLineField.getText().trim());
        vessel.setMaxCapacityTons(capacity);

        try {
            vesselService.requestRegistration(myPortId, vessel, requestedBy, documentFileName, documentBytes);
            succeeded = true;
            JOptionPane.showMessageDialog(this,
                    "Registration request submitted for IMO " + imo + ".\nStatus: PENDING admin approval.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Request Ship Registration", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSucceeded() {
        return succeeded;
    }
}
