package Presentation;

import Model.Cargo;
import Model.CargoProduct;
import Model.Partnership;
import Model.Port;
import Service.CargoService;
import Service.PartnershipService;
import Service.PortService;
import UI.DialogKit;
import UI.TemplateUI;
import Util.Session;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Backs CargoOperations -> "Create Outbound Cargo". The logged-in port is
 * always one end of the cargo (origin for OUTBOUND, destination for INBOUND);
 * the other end must be one of its ACTIVE partner ports.
 */
public class CreateCargoDialog extends JDialog {

    private final JComboBox<Cargo.Direction> directionBox = new JComboBox<>(Cargo.Direction.values());
    private final JComboBox<Port> partnerBox = new JComboBox<>();
    private final JComboBox<String> priorityBox = new JComboBox<>(new String[]{"Normal", "High", "Urgent"});
    private final JTextField weightField = new JTextField(10);

    private final DefaultTableModel productModel
            = new DefaultTableModel(new String[]{"Product", "Quantity", "Unit"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable productTable = new JTable(productModel);

    private final CargoService cargoService = new CargoService();
    private final PartnershipService partnershipService = new PartnershipService();
    private final PortService portService = new PortService();
    private final Integer myPortId = Session.getPortId();
    private int maxProducts = CargoService.MAX_PRODUCTS_PER_CARGO;
    private boolean succeeded = false;

    public CreateCargoDialog(Frame owner) {
        super(owner, "Create Cargo", true);
        loadLimits();
        buildUI();
        loadPartners();
        DialogKit.finish(this, owner, 600);
    }

    private void buildUI() {
        directionBox.setSelectedItem(Cargo.Direction.OUTBOUND);

        JPanel header = DialogKit.header("Create Cargo",
                "Choose a partner port, then list what is being shipped.", null);

        // card 1: shipment details
        weightField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "e.g. 1200");
        JPanel form = DialogKit.form();
        DialogKit.addField(form, 0, 0, 1, "Direction", directionBox);
        DialogKit.addField(form, 0, 1, 1, "Priority", priorityBox);
        DialogKit.addField(form, 1, 0, 2, "Partner Port", partnerBox);
        DialogKit.addField(form, 2, 0, 2, "Weight (kg)", weightField);
        JPanel detailsCard = DialogKit.card("Shipment Details");
        detailsCard.add(form, BorderLayout.CENTER);

        // card 2: products
        TemplateUI.styleTable(productTable, -1, 1);
        productTable.setRowHeight(34);
        productTable.setPreferredScrollableViewportSize(new Dimension(480, 110));
        JScrollPane scroll = new JScrollPane(productTable);
        scroll.setBorder(BorderFactory.createLineBorder(DialogKit.LINE));

        JButton addProduct = DialogKit.secondary("Add Product");
        addProduct.addActionListener(e -> onAddProduct());
        JButton removeProduct = DialogKit.secondary("Remove Selected");
        removeProduct.addActionListener(e -> onRemoveProduct());
        JPanel productButtons = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        productButtons.setOpaque(false);
        productButtons.add(addProduct);
        productButtons.add(removeProduct);

        JPanel productsCard = DialogKit.card("Products (max " + maxProducts + ")");
        productsCard.add(scroll, BorderLayout.CENTER);
        productsCard.add(productButtons, BorderLayout.SOUTH);

        JPanel stack = new JPanel(new BorderLayout(0, 14));
        stack.setOpaque(false);
        stack.add(detailsCard, BorderLayout.NORTH);
        stack.add(productsCard, BorderLayout.CENTER);

        JButton submit = DialogKit.primary("Create Cargo");
        submit.addActionListener(e -> onSubmit());
        JButton cancel = DialogKit.secondary("Cancel");
        cancel.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(stack), DialogKit.footer(null, cancel, submit));
        DialogKit.escToClose(this);
    }

    private void loadLimits() {
        if (myPortId == null) {
            return;
        }
        try {
            maxProducts = cargoService.maxProductsPerCargo(myPortId);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load limits: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Only ACTIVE ports this port has an ACTIVE partnership with.
     */
    private void loadPartners() {
        if (myPortId == null) {
            return;
        }
        try {
            Map<Integer, Port> active = new HashMap<>();
            for (Port p : portService.findByStatus(Port.Status.ACTIVE)) {
                active.put(p.getId(), p);
            }
            for (Partnership p : partnershipService.activeFor(myPortId)) {
                Port other = active.get(PartnershipService.otherPort(p, myPortId));
                if (other != null) {
                    partnerBox.addItem(other);
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load partner ports: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void onAddProduct() {
        if (productModel.getRowCount() >= maxProducts) {
            JOptionPane.showMessageDialog(this, "A cargo can hold at most "
                    + maxProducts + " products.", "Limit reached", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JTextField nameField = new JTextField();
        JTextField qtyField = new JTextField();
        JTextField unitField = new JTextField();
        unitField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "e.g. kg, boxes");

        JPanel panel = DialogKit.form();
        DialogKit.addField(panel, 0, 0, 2, "Product Name", nameField);
        DialogKit.addField(panel, 1, 0, 1, "Quantity", qtyField);
        DialogKit.addField(panel, 1, 1, 1, "Unit", unitField);
        panel.setPreferredSize(new Dimension(380, panel.getPreferredSize().height));

        int result = JOptionPane.showConfirmDialog(this, panel, "Add Product",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (result != JOptionPane.OK_OPTION) {
            return;
        }
        String name = nameField.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Product Name is required.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            double qty = Double.parseDouble(qtyField.getText().trim());
            if (qty <= 0) {
                JOptionPane.showMessageDialog(this, "Quantity must be greater than zero.", "Validation", JOptionPane.WARNING_MESSAGE);
                return;
            }
            productModel.addRow(new Object[]{name, qty, unitField.getText().trim()});
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Quantity must be a number.", "Validation", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void onRemoveProduct() {
        int row = productTable.getSelectedRow();
        if (row >= 0) {
            productModel.removeRow(productTable.convertRowIndexToModel(row));
        }
    }

    private void onSubmit() {
        if (myPortId == null) {
            JOptionPane.showMessageDialog(this, "No port is logged in.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Port partner = (Port) partnerBox.getSelectedItem();
        if (partner == null) {
            JOptionPane.showMessageDialog(this,
                    "You need an ACTIVE partner port to create cargo.\nSend or accept a partnership request first.",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        double weight;
        try {
            weight = Double.parseDouble(weightField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Weight must be a number.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (weight <= 0) {
            JOptionPane.showMessageDialog(this, "Weight must be greater than zero.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (productModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Add at least one product to the cargo.", "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Cargo.Direction direction = (Cargo.Direction) directionBox.getSelectedItem();
        boolean outbound = direction == Cargo.Direction.OUTBOUND;

        Cargo cargo = new Cargo();
        cargo.setDirection(direction);
        cargo.setOriginPortId(outbound ? myPortId : partner.getId());
        cargo.setDestinationPortId(outbound ? partner.getId() : myPortId);
        cargo.setWeightKg(weight);
        cargo.setPriority((String) priorityBox.getSelectedItem());

        List<CargoProduct> products = new ArrayList<>();
        for (int i = 0; i < productModel.getRowCount(); i++) {
            products.add(new CargoProduct(
                    (String) productModel.getValueAt(i, 0),
                    ((Number) productModel.getValueAt(i, 1)).doubleValue(),
                    (String) productModel.getValueAt(i, 2)));
        }

        try {
            cargoService.createCargo(myPortId, cargo, products);
            succeeded = true;
            JOptionPane.showMessageDialog(this,
                    "Cargo created.\n\nCargo Code: " + cargo.getCargoCode(),
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (IllegalStateException ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage(), "Cannot create cargo", JOptionPane.WARNING_MESSAGE);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSucceeded() {
        return succeeded;
    }
}
