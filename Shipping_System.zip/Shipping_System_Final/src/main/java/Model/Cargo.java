package Model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Cargo {

    public enum Direction { INBOUND, OUTBOUND }
    public enum Status { PREPARED, DISPATCHED, RECEIVED, RETURNED, CANCELLED }

    private int id;
    private String cargoCode;
    private Direction direction;
    private int originPortId;
    private int destinationPortId;
    private Integer vesselId;
    private double weightKg;
    private String priority = "Normal";
    private Status status = Status.PREPARED;
    private LocalDate datePrepared;
    private LocalDate departureDate;
    private LocalDate estimatedEta;
    private LocalDate dateEnded;
    private List<CargoProduct> products = new ArrayList<>();

    public Cargo() {
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getCargoCode() { return cargoCode; }
    public void setCargoCode(String cargoCode) { this.cargoCode = cargoCode; }

    public Direction getDirection() { return direction; }
    public void setDirection(Direction direction) { this.direction = direction; }

    public int getOriginPortId() { return originPortId; }
    public void setOriginPortId(int originPortId) { this.originPortId = originPortId; }

    public int getDestinationPortId() { return destinationPortId; }
    public void setDestinationPortId(int destinationPortId) { this.destinationPortId = destinationPortId; }

    public Integer getVesselId() { return vesselId; }
    public void setVesselId(Integer vesselId) { this.vesselId = vesselId; }

    public double getWeightKg() { return weightKg; }
    public void setWeightKg(double weightKg) { this.weightKg = weightKg; }

    public String getPriority() { return priority; }
    public void setPriority(String priority) { this.priority = priority; }

    public Status getStatus() { return status; }
    public void setStatus(Status status) { this.status = status; }

    public LocalDate getDatePrepared() { return datePrepared; }
    public void setDatePrepared(LocalDate datePrepared) { this.datePrepared = datePrepared; }

    public LocalDate getDepartureDate() { return departureDate; }
    public void setDepartureDate(LocalDate departureDate) { this.departureDate = departureDate; }

    public LocalDate getEstimatedEta() { return estimatedEta; }
    public void setEstimatedEta(LocalDate estimatedEta) { this.estimatedEta = estimatedEta; }

    public LocalDate getDateEnded() { return dateEnded; }
    public void setDateEnded(LocalDate dateEnded) { this.dateEnded = dateEnded; }

    public List<CargoProduct> getProducts() { return products; }
    public void setProducts(List<CargoProduct> products) { this.products = products; }
}
