package Util;

import Model.User;

public final class Session {

    private static User currentUser;

    private Session() {
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    /**
     * null for ADMIN users.
     */
    public static Integer getPortId() {
        return currentUser != null ? currentUser.getPortId() : null;
    }

    public static void clear() {
        currentUser = null;
    }
}
