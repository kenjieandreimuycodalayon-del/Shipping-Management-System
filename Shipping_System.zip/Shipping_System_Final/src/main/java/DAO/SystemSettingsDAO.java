package DAO;

import Model.SystemSettings;
import Util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SystemSettingsDAO {

    /** There is always exactly one row (id = 1). */
    public SystemSettings find() throws SQLException {
        String sql = "SELECT * FROM system_settings WHERE id = 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            if (rs.next()) {
                SystemSettings s = new SystemSettings();
                s.setSysRole(rs.getString("sys_role"));
                s.setMaxQueuePerPort(rs.getInt("max_queue_per_port"));
                s.setMaxCargoPerItem(rs.getInt("max_cargo_per_item"));
                s.setNetworkStatus(rs.getString("network_status"));
                return s;
            }
        }
        return null;
    }

    public void save(SystemSettings s) throws SQLException {
        String sql = "UPDATE system_settings SET sys_role=?, max_queue_per_port=?, max_cargo_per_item=?, "
                + "network_status=? WHERE id = 1";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, s.getSysRole());
            ps.setInt(2, s.getMaxQueuePerPort());
            ps.setInt(3, s.getMaxCargoPerItem());
            ps.setString(4, s.getNetworkStatus());
            ps.executeUpdate();
        }
    }
}
