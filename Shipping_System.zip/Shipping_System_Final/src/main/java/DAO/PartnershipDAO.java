package DAO;

import Model.Partnership;
import Util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PartnershipDAO {

    public int insert(Partnership p) throws SQLException {
        String sql = "INSERT INTO partnerships (port_a_id, port_b_id, request_type, status, connected_since) "
                + "VALUES (?,?,?,?,?)";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            bind(ps, p);
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    p.setId(keys.getInt(1));
                    return p.getId();
                }
            }
        }
        return -1;
    }

    public Partnership findById(int id) throws SQLException {
        String sql = "SELECT * FROM partnerships WHERE id=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    /**
     * Moves a partnership from `expected` to `newStatus`. The WHERE clause
     * checks the current status so a stale screen can't, e.g., accept a request
     * that was already terminated. Returns false if nothing was updated.
     */
    public boolean updateStatus(int id, Partnership.Status newStatus, Partnership.Status expected)
            throws SQLException {
        String sql = "UPDATE partnerships SET status=?"
                + (newStatus == Partnership.Status.ACTIVE ? ", connected_since=CURDATE()" : "")
                + " WHERE id=? AND status=?";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newStatus.name());
            ps.setInt(2, id);
            ps.setString(3, expected.name());
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Pass null status for every partnership the port is part of.
     */
    public List<Partnership> findByPortAndStatus(int portId, Partnership.Status status) throws SQLException {
        String sql = "SELECT * FROM partnerships WHERE (port_a_id=? OR port_b_id=?)"
                + (status != null ? " AND status=?" : "") + " ORDER BY id DESC";
        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, portId);
            ps.setInt(2, portId);
            if (status != null) {
                ps.setString(3, status.name());
            }
            try (ResultSet rs = ps.executeQuery()) {
                List<Partnership> results = new ArrayList<>();
                while (rs.next()) {
                    results.add(map(rs));
                }
                return results;
            }
        }
    }

    private void bind(PreparedStatement ps, Partnership p) throws SQLException {
        ps.setInt(1, p.getPortAId());
        ps.setInt(2, p.getPortBId());
        ps.setString(3, p.getRequestType());
        ps.setString(4, p.getStatus() != null ? p.getStatus().name() : Partnership.Status.PENDING.name());
        ps.setDate(5, p.getConnectedSince() != null ? Date.valueOf(p.getConnectedSince()) : null);
    }

    private Partnership map(ResultSet rs) throws SQLException {
        Partnership p = new Partnership();
        p.setId(rs.getInt("id"));
        p.setPortAId(rs.getInt("port_a_id"));
        p.setPortBId(rs.getInt("port_b_id"));
        p.setRequestType(rs.getString("request_type"));
        p.setStatus(Partnership.Status.valueOf(rs.getString("status")));
        Date since = rs.getDate("connected_since");
        p.setConnectedSince(since != null ? since.toLocalDate() : null);
        return p;
    }
}
