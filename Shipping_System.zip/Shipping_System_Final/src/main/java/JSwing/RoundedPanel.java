package JSwing;

import javax.swing.*;
import java.awt.*;

public class RoundedPanel extends JPanel {
    private int cornerRadius = 20; // Default curve radius

    // 1. Default Constructor for NetBeans
    public RoundedPanel() {
        super();
        setOpaque(false);
        setBackground(new Color(10, 25, 47)); // Default Navy Blue
    }

    // 2. Custom Constructor
    public RoundedPanel(int radius, Color bgColor) {
        super();
        this.cornerRadius = radius;
        setBackground(bgColor);
        setOpaque(false);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Dimension arcs = new Dimension(cornerRadius, cornerRadius);
        int width = getWidth();
        int height = getHeight();

        Graphics2D graphics = (Graphics2D) g;
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        // Draws using NetBeans standard background color
        graphics.setColor(getBackground());
        graphics.fillRoundRect(0, 0, width - 1, height - 1, arcs.width, arcs.height);
    }

    // Custom property to edit curve radius directly in NetBeans
    public int getCornerRadius() {
        return cornerRadius;
    }

    public void setCornerRadius(int cornerRadius) {
        this.cornerRadius = cornerRadius;
        repaint();
    }
}