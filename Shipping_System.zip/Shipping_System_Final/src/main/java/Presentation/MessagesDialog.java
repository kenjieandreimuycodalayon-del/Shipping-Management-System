package Presentation;

import Model.Message;
import Model.User;
import Service.MessageService;
import UI.DialogKit;
import UI.TemplateUI;
import Util.Session;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Inbox + Sent for the logged-in user (admin or port). Opened from the envelope button on the dashboards. */
public class MessagesDialog extends JDialog {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("MMM d, yyyy h:mm a");

    private final MessageService service = new MessageService();
    private final User me = Session.getCurrentUser();

    private final DefaultTableModel inboxModel = readOnly("", "From", "Subject", "Received");
    private final DefaultTableModel sentModel = readOnly("To", "Subject", "Sent");
    private final JTable inboxTable = new JTable(inboxModel);
    private final JTable sentTable = new JTable(sentModel);
    private final JTabbedPane tabs = new JTabbedPane();
    private final JLabel previewHeader = new JLabel(" ");
    private final JTextArea preview = new JTextArea();
    private final JButton reply = DialogKit.secondary("Reply");

    private List<Message> inbox = new ArrayList<>();
    private List<Message> sent = new ArrayList<>();

    public MessagesDialog(Window owner) {
        super(owner, "Messages", ModalityType.APPLICATION_MODAL);
        buildUI();
        load();
        DialogKit.finish(this, owner, 820);
    }

    private static DefaultTableModel readOnly(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private void buildUI() {
        JPanel header = DialogKit.header("Messages", "Inbox and sent messages", null);

        TemplateUI.styleTable(inboxTable, -1);
        TemplateUI.styleTable(sentTable, -1);
        inboxTable.setRowHeight(38);
        sentTable.setRowHeight(38);
        inboxTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        inboxTable.getColumnModel().getColumn(0).setMaxWidth(80);
        inboxTable.getColumnModel().getColumn(3).setPreferredWidth(170);
        sentTable.getColumnModel().getColumn(2).setPreferredWidth(170);
        inboxTable.setPreferredScrollableViewportSize(new Dimension(760, 190));
        sentTable.setPreferredScrollableViewportSize(new Dimension(760, 190));

        inboxTable.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            int row = inboxTable.getSelectedRow();
            if (row < 0 || row >= inbox.size()) {
                clearPreview();
                return;
            }
            Message m = inbox.get(row);
            showPreview("From: " + m.getSenderLabel(), m);
            if (!m.isRead()) {
                try {
                    service.markRead(m.getId(), me.getId());
                    m.setRead(true);
                    inboxModel.setValueAt("", row, 0);
                } catch (SQLException ignored) {
                    // not critical: it simply stays "New"
                }
            }
        });
        sentTable.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) {
                return;
            }
            int row = sentTable.getSelectedRow();
            if (row < 0 || row >= sent.size()) {
                clearPreview();
                return;
            }
            Message m = sent.get(row);
            showPreview("To: " + m.getRecipientLabel(), m);
        });

        tabs.setFont(TemplateUI.font(Font.BOLD, 14));
        tabs.addTab("Inbox", scroll(inboxTable));
        tabs.addTab("Sent", scroll(sentTable));
        tabs.addChangeListener(e -> {
            reply.setEnabled(tabs.getSelectedIndex() == 0);
            clearPreview();
        });

        // preview card
        previewHeader.setFont(TemplateUI.font(Font.BOLD, 13));
        previewHeader.setForeground(DialogKit.NAVY);
        preview.setEditable(false);
        preview.setLineWrap(true);
        preview.setWrapStyleWord(true);
        preview.setFont(TemplateUI.font(Font.PLAIN, 14));
        preview.setBorder(BorderFactory.createEmptyBorder(8, 10, 8, 10));
        JScrollPane previewScroll = new JScrollPane(preview);
        previewScroll.setBorder(BorderFactory.createLineBorder(DialogKit.LINE));
        previewScroll.setPreferredSize(new Dimension(740, 130));
        JPanel previewCard = DialogKit.card(null);
        previewCard.add(previewHeader, BorderLayout.NORTH);
        previewCard.add(previewScroll, BorderLayout.CENTER);

        JSplitPane split = new JSplitPane(JSplitPane.VERTICAL_SPLIT, tabs, previewCard);
        split.setBorder(null);
        split.setOpaque(false);
        split.setResizeWeight(0.6);

        JButton newMsg = DialogKit.primary("New Message");
        newMsg.addActionListener(e -> onCompose(null, null));
        reply.addActionListener(e -> onReply());
        JButton delete = DialogKit.danger("Delete");
        delete.addActionListener(e -> onDelete());
        JButton refresh = DialogKit.secondary("Refresh");
        refresh.addActionListener(e -> load());
        JButton close = DialogKit.secondary("Close");
        close.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(split),
                DialogKit.footer(null, close, delete, refresh, reply, newMsg));
        DialogKit.escToClose(this);
    }

    private JScrollPane scroll(JTable table) {
        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createLineBorder(DialogKit.LINE));
        return sp;
    }

    private void load() {
        if (me == null) {
            return;
        }
        try {
            inbox = service.inbox(me.getId());
            sent = service.sent(me.getId());

            inboxModel.setRowCount(0);
            for (Message m : inbox) {
                inboxModel.addRow(new Object[]{m.isRead() ? "" : "\u25CF New",
                    m.getSenderLabel(), m.getSubject(), FMT.format(m.getSentAt())});
            }
            sentModel.setRowCount(0);
            for (Message m : sent) {
                sentModel.addRow(new Object[]{m.getRecipientLabel(), m.getSubject(), FMT.format(m.getSentAt())});
            }
            clearPreview();
            tabs.setTitleAt(0, "Inbox (" + inbox.size() + ")");
            tabs.setTitleAt(1, "Sent (" + sent.size() + ")");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load messages: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showPreview(String who, Message m) {
        previewHeader.setText(who + "   \u2022   " + FMT.format(m.getSentAt()) + "   \u2022   " + m.getSubject());
        preview.setText(m.getBody());
        preview.setCaretPosition(0);
    }

    private void clearPreview() {
        previewHeader.setText(" ");
        preview.setText("");
    }

    private void onCompose(Integer replyTo, String subject) {
        ComposeMessageDialog dialog = new ComposeMessageDialog(this, me, replyTo, subject);
        dialog.setVisible(true);
        if (dialog.isSent()) {
            load();
        }
    }

    private void onReply() {
        int row = inboxTable.getSelectedRow();
        if (row < 0 || row >= inbox.size()) {
            JOptionPane.showMessageDialog(this, "Select a message to reply to.", "No Selection",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        Message m = inbox.get(row);
        String subject = m.getSubject().regionMatches(true, 0, "Re:", 0, 3) ? m.getSubject() : "Re: " + m.getSubject();
        onCompose(m.getSenderId(), subject);
    }

    private void onDelete() {
        boolean inInbox = tabs.getSelectedIndex() == 0;
        JTable table = inInbox ? inboxTable : sentTable;
        List<Message> rows = inInbox ? inbox : sent;
        int row = table.getSelectedRow();
        if (row < 0 || row >= rows.size()) {
            JOptionPane.showMessageDialog(this, "Select a message first.", "No Selection",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete this message from your " + (inInbox ? "inbox" : "sent items") + "?",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        try {
            service.delete(rows.get(row).getId(), me.getId());
            load();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}