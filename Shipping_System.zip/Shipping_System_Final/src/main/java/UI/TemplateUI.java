package UI;

import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.Locale;

/**
 * Shared look-and-feel helpers so every dashboard uses the same cards, buttons,
 * headers, tables and status badges.
 */
public final class TemplateUI {

    private TemplateUI() {
    }

    public static final String FONT = "Segoe UI";

    // Semantic colours (text colour; badge backgrounds are a tint of these)
    public static final Color BLUE = new Color(37, 99, 235);
    public static final Color GREEN = new Color(5, 150, 105);
    public static final Color AMBER = new Color(217, 119, 6);
    public static final Color RED = new Color(220, 38, 38);
    public static final Color GRAY = new Color(100, 116, 139);

    public static Font font(int style, int size) {
        return new Font(FONT, style, size);
    }

    public static Color muted() {
        return UIManager.getColor("Label.disabledForeground");
    }

    /**
     * Rounded surface that sits on top of the page background.
     */
    public static JPanel card(LayoutManager layout, int padding) {
        JPanel p = new JPanel(layout);
        p.putClientProperty(FlatClientProperties.STYLE, "arc: 16; background: $Table.background");
        p.setBorder(new EmptyBorder(padding, padding, padding, padding));
        return p;
    }

    /**
     * KPI card: coloured accent bar, small title, big value, optional hint
     * line.
     */
    public static JPanel metricCard(String title, JLabel value, JLabel hint, Color accent) {
        JPanel card = card(new BorderLayout(14, 0), 18);

        JPanel bar = new JPanel();
        bar.putClientProperty(FlatClientProperties.STYLE, "arc: 8");
        bar.setBackground(accent);
        bar.setPreferredSize(new Dimension(5, 0));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(font(Font.PLAIN, 13));
        titleLabel.setForeground(muted());

        value.setFont(font(Font.BOLD, 30));

        JPanel content = new JPanel();
        content.setLayout(new BoxLayout(content, BoxLayout.Y_AXIS));
        content.setOpaque(false);
        content.add(titleLabel);
        content.add(Box.createVerticalStrut(4));
        content.add(value);
        if (hint != null) {
            hint.setFont(font(Font.PLAIN, 12));
            hint.setForeground(muted());
            content.add(Box.createVerticalStrut(2));
            content.add(hint);
        }

        card.add(bar, BorderLayout.WEST);
        card.add(content, BorderLayout.CENTER);
        return card;
    }

    public static JPanel pageHeader(String title, String subtitle, JComponent... actions) {
        JLabel t = new JLabel(title);
        t.setFont(font(Font.BOLD, 26));
        JLabel s = new JLabel(subtitle);
        s.setFont(font(Font.PLAIN, 13));
        s.setForeground(muted());

        JPanel titles = new JPanel();
        titles.setLayout(new BoxLayout(titles, BoxLayout.Y_AXIS));
        titles.setOpaque(false);
        titles.add(t);
        titles.add(Box.createVerticalStrut(4));
        titles.add(s);

        JPanel bar = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        bar.setOpaque(false);
        for (JComponent a : actions) {
            bar.add(a);
        }

        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);
        header.add(titles, BorderLayout.WEST);
        header.add(bar, BorderLayout.EAST);
        return header;
    }

    public static JButton primaryButton(String text) {
        JButton b = new JButton(text);
        b.setMargin(new Insets(8, 16, 8, 16));
        b.putClientProperty(FlatClientProperties.STYLE,
                "background: $Component.accentColor; "
                + "foreground: #ffffff; "
                + "font: bold; "
                + "arc: 12; "
                + "borderWidth: 0; "
                + "focusWidth: 0;");
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    public static JButton secondaryButton(String text) {
        JButton b = new JButton(text);
        b.setMargin(new Insets(8, 16, 8, 16));
        b.putClientProperty(FlatClientProperties.STYLE,
                "arc: 12;");
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }

    /**
     * Card containing a title and a table inside a scroll pane.
     */
    public static JPanel tableCard(String title, JTable table) {
        JLabel label = new JLabel(title);
        label.setFont(font(Font.BOLD, 16));
        label.setBorder(new EmptyBorder(0, 0, 14, 0));

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(null);

        JPanel card = card(new BorderLayout(), 20);
        card.add(label, BorderLayout.NORTH);
        card.add(scroll, BorderLayout.CENTER);
        return card;
    }

    // ------------------------------------------------------------------
    // Helpers for NetBeans Design-view forms: call these AFTER initComponents()
    // to restyle components that were dropped in with the visual editor.
    // ------------------------------------------------------------------
    /**
     * Page background, title bar, title label; hides the old navy stripe.
     */
    public static void stylePage(JPanel page, JPanel titleBar, JLabel title) {
        page.setBackground(UIManager.getColor("Panel.background"));
        titleBar.setBackground(UIManager.getColor("Table.background"));
        title.setFont(font(Font.BOLD, 24));
        title.setForeground(UIManager.getColor("Label.foreground"));

    }

    /**
     * Restyles a card made of a panel + title label + read-only value field.
     */
    public static void styleStatCard(JPanel card, JLabel title, JTextField value, Color accent) {
        card.setBackground(UIManager.getColor("Table.background"));
        title.setText(title.getText().trim());
        title.setFont(font(Font.PLAIN, 14));
        title.setForeground(muted());

        // Make textfield transparent and borderless
        value.setOpaque(false);
        value.setEditable(false);
        value.setFocusable(false);
        value.setBorder(BorderFactory.createEmptyBorder());
        value.setHorizontalAlignment(JTextField.CENTER);
        value.setFont(font(Font.BOLD, 32));
        value.setForeground(accent);
        value.setDisabledTextColor(accent);

        // Completely clear FlatLaf background box and force text color
        String hexColor = String.format("#%02x%02x%02x", accent.getRed(), accent.getGreen(), accent.getBlue());
        value.putClientProperty(FlatClientProperties.STYLE,
                "border: 0,0,0,0; "
                + "background: null; "
                + "disabledBackground: null; "
                + "inactiveBackground: null; "
                + "disabledForeground: " + hexColor + "; "
                + "inactiveForeground: " + hexColor + "; "
                + "foreground: " + hexColor);
    }

    /**
     * Restyles a button from the form (removes the old navy block look).
     */
    public static void styleButton(JButton b, boolean primary) {
        b.setText(b.getText().trim());
        b.setHorizontalAlignment(SwingConstants.CENTER);
        b.setBorder(UIManager.getBorder("Button.border"));
        b.setFont(font(Font.BOLD, 13));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        if (primary) {
            b.putClientProperty(FlatClientProperties.STYLE,
                    "background: $Component.accentColor; foreground: #ffffff;"
                    + "arc: 12; borderWidth: 0; focusWidth: 0");
        } else {
            b.setBackground(UIManager.getColor("Button.background"));
            b.setForeground(UIManager.getColor("Button.foreground"));
            b.putClientProperty(FlatClientProperties.STYLE, "arc: 12");
        }
    }

    /**
     * Section heading above a table.
     */
    public static void styleSection(JLabel label) {
        label.setText(label.getText().trim());
        label.setFont(font(Font.BOLD, 24));
        label.setForeground(UIManager.getColor("Label.foreground"));
    }

    /**
     * Maps a status string to a badge colour.
     */
    public static Color statusColor(String status) {
        String s = status == null ? "" : status.toUpperCase(Locale.ROOT);
        if (has(s, "REJECT", "CANCEL", "TERMINAT", "EXPIRED", "SUSPEND", "FAIL", "DELAY")) {
            return RED;
        }
        if (has(s, "PENDING", "REVIEW", "WAIT")) {
            return AMBER;
        }
        if (has(s, "DELIVER", "COMPLET", "ARRIV")) {
            return BLUE;
        }
        if (has(s, "TRANSIT", "ACTIVE", "APPROVED", "ACCEPT")) {
            return GREEN;
        }
        return GRAY;
    }

    private static boolean has(String s, String... needles) {
        for (String n : needles) {
            if (s.contains(n)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Applies the modern table look: tall rows, horizontal dividers only,
     * padded cells, pill-shaped status badges, right-aligned numeric columns.
     */
    public static void styleTable(JTable table, int statusCol, int... rightAlignedCols) {
        table.setRowHeight(46);
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setGridColor(UIManager.getColor("Component.borderColor"));
        table.setFillsViewportHeight(true);

        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.putClientProperty(FlatClientProperties.STYLE, "height: 40; font: bold");

        table.setDefaultRenderer(Object.class, new CellRenderer(statusCol, rightAlignedCols));
    }

    private static final class CellRenderer extends DefaultTableCellRenderer {

        private final int statusCol;
        private final int[] rightCols;

        CellRenderer(int statusCol, int[] rightCols) {
            this.statusCol = statusCol;
            this.rightCols = rightCols;
        }

        @Override
        public Component getTableCellRendererComponent(JTable t, Object value, boolean selected,
                boolean focus, int row, int col) {
            if (col == statusCol && value != null) {
                JPanel wrap = new JPanel(new GridBagLayout());
                wrap.setBackground(selected ? t.getSelectionBackground() : t.getBackground());
                GridBagConstraints gc = new GridBagConstraints();
                gc.anchor = GridBagConstraints.WEST;
                gc.insets = new Insets(0, 12, 0, 0);
                wrap.add(new Pill(value.toString()), gc);
                return wrap;
            }
            super.getTableCellRendererComponent(t, value, selected, false, row, col);
            setBorder(new EmptyBorder(0, 12, 0, 12));
            boolean right = false;
            for (int c : rightCols) {
                right |= c == col;
            }
            setHorizontalAlignment(right ? SwingConstants.RIGHT : SwingConstants.LEFT);
            return this;
        }
    }

    /**
     * Restyles JComboBox components to match FlatLaf styling (rounded borders,
     * clean focus rings, standard font, and custom padding).
     */
    public static void styleComboBox(JComboBox<?> comboBox) {
        comboBox.setFont(font(Font.PLAIN, 14));
        comboBox.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        comboBox.putClientProperty(FlatClientProperties.STYLE,
                "arc: 10; "
                + "padding: 4,8,4,8; "
                + "focusWidth: 1; "
                + "borderColor: $Component.borderColor;");
    }

    public static void stylePasswordField(JPasswordField passwordField) {
        passwordField.setFont(new Font("SansSerif", Font.PLAIN, 14));
        passwordField.setCursor(Cursor.getPredefinedCursor(Cursor.TEXT_CURSOR));
        passwordField.putClientProperty(FlatClientProperties.STYLE,
                "arc: 10; "
                + "padding: 4,8,4,8; "
                + "focusWidth: 1; "
                + "borderColor: $Component.borderColor; "
                + "showRevealButton: true;"); // Adds the eye icon to toggle password visibility
    }

    /**
     * Restyles JTextField components for search/filter inputs.
     */
    public static void styleTextField(JTextField textField, String placeholder) {
        textField.setFont(font(Font.PLAIN, 14));
        if (placeholder != null && !placeholder.isBlank()) {
            textField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, placeholder);
        }
        textField.putClientProperty(FlatClientProperties.STYLE,
                "arc: 10; "
                + "padding: 4,10,4,10; "
                + "focusWidth: 1; "
                + "borderColor: $Component.borderColor;");
    }

    private static final class Pill extends JLabel {

        private final Color tint;

        Pill(String status) {
            super(status.replace('_', ' ').toUpperCase(Locale.ROOT), SwingConstants.CENTER);
            Color c = statusColor(status);
            this.tint = new Color(c.getRed(), c.getGreen(), c.getBlue(), 38);
            setForeground(c);
            setFont(font(Font.BOLD, 11));
            setBorder(new EmptyBorder(4, 12, 4, 12));
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(tint);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), getHeight(), getHeight());
            g2.dispose();
            super.paintComponent(g);
        }
    }
}
