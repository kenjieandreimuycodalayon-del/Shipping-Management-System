package Presentation;

import Model.PermitReview;
import Service.PortService;
import UI.DialogKit;
import UI.TemplateUI;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.SQLException;

public class PermitReviewDialog extends JDialog {

    public enum Decision {
        NONE, APPROVE, REJECT
    }

    private final PermitReview review;
    private Decision decision = Decision.NONE;
    private BufferedImage permitImage;
    private String previewMessage;

    public PermitReviewDialog(Frame owner, PermitReview review) {
        super(owner, "Permit Application Review", true);
        this.review = review;
        loadPermitImage();
        buildUI();
        setSize(940, 680);
        setResizable(false);
        setLocationRelativeTo(owner);
    }

    public Decision getDecision() {
        return decision;
    }

    private void loadPermitImage() {
        if (!review.isHasDocument()) {
            previewMessage = "No permit document was uploaded.";
            return;
        }
        try {
            byte[] data = new PortService().permitDocument(review.getPermitId());
            permitImage = data != null ? ImageIO.read(new ByteArrayInputStream(data)) : null;
            if (permitImage == null) {
                previewMessage = "Preview not available for this file type.";
            }
        } catch (SQLException | IOException ex) {
            previewMessage = "Could not load document: " + ex.getMessage();
        }
    }

    private void buildUI() {
        JPanel header = DialogKit.header("Permit Application Review",
                "Check the applicant's details against the submitted permit.",
                review.getPermitNo());

        JPanel cards = new JPanel(new GridLayout(1, 2, 20, 0));
        cards.setOpaque(false);
        cards.add(buildInfoCard());
        cards.add(DialogKit.documentCard(this, "Submitted Permit", permitImage, previewMessage,
                "Permit \u2014 " + review.getDocumentName()));

        JButton approve = DialogKit.primary("Approve Port");
        approve.addActionListener(e -> {
            decision = Decision.APPROVE;
            dispose();
        });
        JButton reject = DialogKit.danger("Reject Request");
        reject.addActionListener(e -> {
            decision = Decision.REJECT;
            dispose();
        });
        JButton close = DialogKit.secondary("Close");
        close.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(cards), DialogKit.footer(null, close, reject, approve));
        DialogKit.escToClose(this);
    }

    private JPanel buildInfoCard() {
        JPanel card = DialogKit.card("Applicant Information");

        JPanel rows = DialogKit.form();
        String portCode = review.getPortCode() != null ? review.getPortCode() : "#" + review.getPortId();
        DialogKit.infoRow(rows, 0, "Permit No.", review.getPermitNo());
        DialogKit.infoRow(rows, 1, "Port ID", portCode);
        DialogKit.infoRow(rows, 2, "Company Name", review.getPortName());
        DialogKit.infoRow(rows, 3, "Registered Name", review.getRegisteredName());
        DialogKit.infoRow(rows, 4, "Capability", review.getPrimaryCapability());
        DialogKit.infoRow(rows, 5, "Email", review.getEmail() != null ? review.getEmail() : review.getUsername());
        DialogKit.infoRow(rows, 6, "Date Submitted",
                review.getDateSubmitted() != null ? review.getDateSubmitted().toString() : null);
        String status = review.getStatus() != null ? review.getStatus().name() : null;
        JLabel statusLabel = DialogKit.infoRow(rows, 7, "Status", status);
        if (status != null) {
            statusLabel.setFont(TemplateUI.font(Font.BOLD, 14));
            statusLabel.setForeground(TemplateUI.statusColor(status));
        }
        DialogKit.infoRow(rows, 8, "Document", review.getDocumentName());

        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.add(rows, BorderLayout.NORTH);
        card.add(wrap, BorderLayout.CENTER);
        return card;
    }
}
