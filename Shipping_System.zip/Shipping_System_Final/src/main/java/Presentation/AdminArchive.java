/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Presentation;

import Model.Cargo;
import Model.Port;
import Model.Vessel;
import Service.CargoService;
import Service.PortService;
import Service.VesselService;
import UI.TemplateUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Frame;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 *
 * @author Kenji
 */
public class AdminArchive extends javax.swing.JPanel {

    private final CargoService cargoService = new CargoService();
    private final PortService portService = new PortService();
    private final VesselService vesselService = new VesselService();

    // parallel to the table rows so a selection maps back to a Cargo
    private List<Cargo> currentCargo = new ArrayList<>();

    /**
     * Creates new form AdminArchive
     */
    public AdminArchive() {
        initComponents();
        applyModernStyle();

        // archived cargo can also be RETURNED; labels keep the project's "Recieved" spelling
        comboArch.setModel(new javax.swing.DefaultComboBoxModel<>(
                new String[]{"All", "Recieved", "Returned", "Cancelled"}));
        archTableAdmin.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        archTableAdmin.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) {
                    insManAdmin.doClick();
                }
            }
        });
        comboArch.addActionListener(e -> loadArchive());

        // reload whenever the Archive card is shown so newly finished cargo appears
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentShown(ComponentEvent e) {
                loadArchive();
            }
        });

        loadArchive();
    }

    private String codeOf(Port p, int portId) {
        if (p == null) {
            return "#" + portId;
        }
        return p.getPortCode() != null ? p.getPortCode() : "#" + p.getId();
    }

    private Cargo.Status comboToStatus(String label) {
        if (label == null || "All".equalsIgnoreCase(label)) {
            return null;
        }
        return "Recieved".equals(label) ? Cargo.Status.RECEIVED : Cargo.Status.valueOf(label.toUpperCase());
    }

    private boolean contains(String text, String keyword) {
        return text != null && text.toLowerCase().contains(keyword);
    }
    
    private void applyModernStyle() {
        TemplateUI.stylePage(jPanel2, jPanel3, jLabel1);

        // Explicitly set card surface color and flatlaf styling for roundedPanel5 (Port Permits)
        roundedPanel5.setBackground(UIManager.getColor("Table.background"));
        roundedPanel5.putClientProperty(com.formdev.flatlaf.FlatClientProperties.STYLE, "arc: 16; background: $Table.background");

        TemplateUI.styleTextField(archiveSearchField, "Search...");
        TemplateUI.styleComboBox(comboArch);
        TemplateUI.styleButton(insManAdmin, true);
        TemplateUI.styleButton(refArchiveAdmin, true);
        TemplateUI.styleSection(jLabel1);
        jScrollPane1.setBorder(null);
        TemplateUI.styleTable(archTableAdmin, 4, 2);
    }

    /**
     * Network-wide RECEIVED / RETURNED / CANCELLED cargo, newest first,
     * filtered by the Status combo and the Search box (cargo code, port codes
     * or vessel name).
     */
    private void loadArchive() {
        try {
            Map<Integer, Port> ports = new HashMap<>();
            for (Port p : portService.findAll()) {
                ports.put(p.getId(), p);
            }
            Map<Integer, Vessel> vessels = new HashMap<>();
            for (Vessel v : vesselService.findByStatus(null)) {
                vessels.put(v.getId(), v);
            }

            Cargo.Status status = comboToStatus((String) comboArch.getSelectedItem());
            String keyword = archiveSearchField.getText().trim().toLowerCase();

            List<Cargo> result = new ArrayList<>();
            for (Cargo c : cargoService.archived()) {
                if (status != null && c.getStatus() != status) {
                    continue;
                }
                if (!keyword.isEmpty()) {
                    Vessel v = c.getVesselId() != null ? vessels.get(c.getVesselId()) : null;
                    boolean match = contains(c.getCargoCode(), keyword)
                            || contains(codeOf(ports.get(c.getOriginPortId()), c.getOriginPortId()), keyword)
                            || contains(codeOf(ports.get(c.getDestinationPortId()), c.getDestinationPortId()), keyword)
                            || (v != null && contains(v.getVesselName(), keyword));
                    if (!match) {
                        continue;
                    }
                }
                result.add(c);
            }
            Comparator<Cargo> newestFirst = Comparator
                    .comparing(Cargo::getDateEnded, Comparator.nullsLast(Comparator.<LocalDate>reverseOrder()))
                    .thenComparing(Comparator.comparingInt(Cargo::getId).reversed());
            result.sort(newestFirst);
            currentCargo = result;

            Object[][] data = new Object[currentCargo.size()][6];
            for (int i = 0; i < currentCargo.size(); i++) {
                Cargo c = currentCargo.get(i);
                Vessel v = c.getVesselId() != null ? vessels.get(c.getVesselId()) : null;
                data[i][0] = c.getCargoCode();
                data[i][1] = codeOf(ports.get(c.getOriginPortId()), c.getOriginPortId());
                data[i][2] = codeOf(ports.get(c.getDestinationPortId()), c.getDestinationPortId());
                data[i][3] = v != null ? v.getVesselName() : "\u2014"; // cancelled cargo may never have had a vessel
                data[i][4] = c.getDateEnded();
                data[i][5] = c.getStatus();
            }
            archTableAdmin.setModel(new DefaultTableModel(data,
                    new String[]{"Cargo ID", "Origin Port", "Destination Port", "Assigned Vessel", "Date Ended", "Status"}) {
                @Override
                public boolean isCellEditable(int row, int column) {
                    return false;
                }
            });
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Failed to load archive: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        roundedPanel4 = new JSwing.RoundedPanel();
        jLabel7 = new javax.swing.JLabel();
        archiveSearchField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        comboArch = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        roundedPanel5 = new JSwing.RoundedPanel();
        insManAdmin = new javax.swing.JButton();
        refArchiveAdmin = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        archTableAdmin = new javax.swing.JTable();

        setMaximumSize(new java.awt.Dimension(1060, 650));
        setMinimumSize(new java.awt.Dimension(1060, 650));
        setPreferredSize(new java.awt.Dimension(1060, 650));
        setLayout(new java.awt.BorderLayout());

        jPanel2.setMaximumSize(new java.awt.Dimension(1060, 650));
        jPanel2.setMinimumSize(new java.awt.Dimension(1060, 650));
        jPanel2.setPreferredSize(new java.awt.Dimension(1060, 650));

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Gadugi", 1, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 102));
        jLabel1.setText("Global Logistics Historical Archives");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(80, 80, 80)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 407, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(jLabel1)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        roundedPanel4.setBackground(new java.awt.Color(255, 255, 255));
        roundedPanel4.setMaximumSize(new java.awt.Dimension(323, 75));
        roundedPanel4.setMinimumSize(new java.awt.Dimension(323, 75));

        jLabel7.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 0, 102));
        jLabel7.setText("Search:");

        archiveSearchField.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        archiveSearchField.addActionListener(this::archiveSearchFieldActionPerformed);

        jLabel8.setFont(new java.awt.Font("Gadugi", 1, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 0, 102));
        jLabel8.setText("Status");

        comboArch.setFont(new java.awt.Font("Gadugi", 0, 15)); // NOI18N
        comboArch.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "All", "Recieved", "Cancelled" }));

        javax.swing.GroupLayout roundedPanel4Layout = new javax.swing.GroupLayout(roundedPanel4);
        roundedPanel4.setLayout(roundedPanel4Layout);
        roundedPanel4Layout.setHorizontalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(archiveSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(comboArch, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel4Layout.setVerticalGroup(
            roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel4Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(roundedPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(archiveSearchField, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8)
                    .addComponent(comboArch, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jLabel6.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 0, 102));
        jLabel6.setText("Search & Filter");

        jLabel10.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(0, 0, 102));
        jLabel10.setText("Actions");

        roundedPanel5.setBackground(new java.awt.Color(255, 255, 255));

        insManAdmin.setBackground(new java.awt.Color(0, 0, 102));
        insManAdmin.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        insManAdmin.setForeground(new java.awt.Color(255, 255, 255));
        insManAdmin.setText("                 Inspect Manifest");
        insManAdmin.setBorder(null);
        insManAdmin.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        insManAdmin.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        insManAdmin.addActionListener(this::insManAdminActionPerformed);

        refArchiveAdmin.setBackground(new java.awt.Color(0, 0, 102));
        refArchiveAdmin.setFont(new java.awt.Font("Gadugi", 1, 15)); // NOI18N
        refArchiveAdmin.setForeground(new java.awt.Color(255, 255, 255));
        refArchiveAdmin.setText("                  Refresh Archive");
        refArchiveAdmin.setBorder(null);
        refArchiveAdmin.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        refArchiveAdmin.setHorizontalAlignment(javax.swing.SwingConstants.LEADING);
        refArchiveAdmin.addActionListener(this::refArchiveAdminActionPerformed);

        javax.swing.GroupLayout roundedPanel5Layout = new javax.swing.GroupLayout(roundedPanel5);
        roundedPanel5.setLayout(roundedPanel5Layout);
        roundedPanel5Layout.setHorizontalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(37, 37, 37)
                .addComponent(insManAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(refArchiveAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        roundedPanel5Layout.setVerticalGroup(
            roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(roundedPanel5Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(roundedPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(insManAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(refArchiveAdmin, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12))
        );

        jLabel11.setFont(new java.awt.Font("Gadugi", 1, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(0, 0, 102));
        jLabel11.setText("Cargo Inventory");

        archTableAdmin.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "Cargo ID", "Origin Port", "Destination Port", "Assigned Vessel", "Date Ended", "Status"
            }
        ));
        jScrollPane1.setViewportView(archTableAdmin);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane1)
                            .addComponent(roundedPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(roundedPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(50, 50, 50))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 241, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(roundedPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(24, 24, 24)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 41, Short.MAX_VALUE))
        );

        add(jPanel2, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void archiveSearchFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_archiveSearchFieldActionPerformed
        loadArchive();
    }//GEN-LAST:event_archiveSearchFieldActionPerformed

    private void refArchiveAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refArchiveAdminActionPerformed
        loadArchive();
    }//GEN-LAST:event_refArchiveAdminActionPerformed

    private void insManAdminActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insManAdminActionPerformed
        int row = archTableAdmin.getSelectedRow();
        if (row < 0 || row >= currentCargo.size()) {
            JOptionPane.showMessageDialog(this, "Select a cargo row first.", "No Selection", JOptionPane.WARNING_MESSAGE);
            return;
        }
        InspectManifestDialog dialog = new InspectManifestDialog(
                (Frame) SwingUtilities.getWindowAncestor(this), currentCargo.get(row).getId());
        dialog.setVisible(true);
    }//GEN-LAST:event_insManAdminActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable archTableAdmin;
    private javax.swing.JTextField archiveSearchField;
    private javax.swing.JComboBox<String> comboArch;
    private javax.swing.JButton insManAdmin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton refArchiveAdmin;
    private JSwing.RoundedPanel roundedPanel4;
    private JSwing.RoundedPanel roundedPanel5;
    // End of variables declaration//GEN-END:variables
}
