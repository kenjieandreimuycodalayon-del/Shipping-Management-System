package Service;

import DAO.SystemSettingsDAO;
import Model.SystemSettings;

import java.sql.SQLException;

public class SystemSettingsService {

    private final SystemSettingsDAO settingsDAO = new SystemSettingsDAO();

    public SystemSettings get() throws SQLException {
        return settingsDAO.find();
    }

    /** Admin Settings -> "Global Network System Policy" panel. */
    public void save(SystemSettings settings) throws SQLException {
        settingsDAO.save(settings);
    }
}
