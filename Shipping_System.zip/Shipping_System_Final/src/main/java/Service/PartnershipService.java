package Service;

import DAO.PartnershipDAO;
import DAO.PortDAO;
import Model.Partnership;
import Model.Port;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Every method that changes data takes the ACTING port id, so a port can only
 * touch partnerships it is part of, and only the receiver can accept/reject.
 * Rule violations throw IllegalStateException with a message the UI can show.
 */
public class PartnershipService {

    private final PartnershipDAO partnershipDAO = new PartnershipDAO();
    private final PortDAO portDAO = new PortDAO();

    /**
     * Partnership Management -> "Send Request". port_a = sender, port_b =
     * receiver.
     */
    public int sendRequest(int requestingPortId, int targetPortId, String requestType) throws SQLException {
        if (requestingPortId == targetPortId) {
            throw new IllegalStateException("A port cannot partner with itself.");
        }
        if (requestType == null || requestType.isBlank()) {
            throw new IllegalStateException("Please choose a request type.");
        }
        requireActive(requestingPortId, "Your port must be ACTIVE to send partnership requests.");
        requireActive(targetPortId, "The selected port is not active.");
        if (hasOpenPartnership(requestingPortId, targetPortId)) {
            throw new IllegalStateException(
                    "There is already a pending or active partnership with that port.");
        }

        Partnership p = new Partnership();
        p.setPortAId(requestingPortId);
        p.setPortBId(targetPortId);
        p.setRequestType(requestType);
        p.setStatus(Partnership.Status.PENDING);
        return partnershipDAO.insert(p);
    }

    /**
     * Only the port that RECEIVED the request can accept it.
     */
    public void accept(int actingPortId, int partnershipId) throws SQLException {
        Partnership p = requireParty(actingPortId, partnershipId);
        requireReceiver(actingPortId, p);
        requireActive(p.getPortAId(), "The requesting port is no longer active.");
        if (!partnershipDAO.updateStatus(partnershipId, Partnership.Status.ACTIVE, Partnership.Status.PENDING)) {
            throw new IllegalStateException("This request was already handled.");
        }
    }

    /**
     * Only the port that RECEIVED the request can reject it.
     */
    public void reject(int actingPortId, int partnershipId) throws SQLException {
        Partnership p = requireParty(actingPortId, partnershipId);
        requireReceiver(actingPortId, p);
        if (!partnershipDAO.updateStatus(partnershipId, Partnership.Status.REJECTED, Partnership.Status.PENDING)) {
            throw new IllegalStateException("This request was already handled.");
        }
    }

    /**
     * Either side can terminate an ACTIVE partnership.
     */
    public void terminate(int actingPortId, int partnershipId) throws SQLException {
        requireParty(actingPortId, partnershipId);
        if (!partnershipDAO.updateStatus(partnershipId, Partnership.Status.TERMINATED, Partnership.Status.ACTIVE)) {
            throw new IllegalStateException("Only active partnerships can be terminated.");
        }
    }

    public List<Partnership> activeFor(int portId) throws SQLException {
        return partnershipDAO.findByPortAndStatus(portId, Partnership.Status.ACTIVE);
    }

    /**
     * Both incoming (port_b = me) and outgoing (port_a = me) pending requests.
     */
    public List<Partnership> pendingFor(int portId) throws SQLException {
        return partnershipDAO.findByPortAndStatus(portId, Partnership.Status.PENDING);
    }

    /**
     * Ports this port may send a request to: ACTIVE, not itself, no open
     * partnership yet.
     */
    public List<Port> availableTargets(int myPortId) throws SQLException {
        List<Integer> blocked = new ArrayList<>();
        blocked.add(myPortId);
        for (Partnership p : partnershipDAO.findByPortAndStatus(myPortId, null)) {
            if (isOpen(p)) {
                blocked.add(otherPort(p, myPortId));
            }
        }
        List<Port> result = new ArrayList<>();
        for (Port port : portDAO.findByStatus(Port.Status.ACTIVE)) {
            if (!blocked.contains(port.getId())) {
                result.add(port);
            }
        }
        return result;
    }

    public static int otherPort(Partnership p, int myPortId) {
        return p.getPortAId() == myPortId ? p.getPortBId() : p.getPortAId();
    }

    // ---- helpers ----
    private boolean isOpen(Partnership p) {
        return p.getStatus() == Partnership.Status.PENDING || p.getStatus() == Partnership.Status.ACTIVE;
    }

    private boolean hasOpenPartnership(int a, int b) throws SQLException {
        for (Partnership p : partnershipDAO.findByPortAndStatus(a, null)) {
            if (isOpen(p) && otherPort(p, a) == b) {
                return true;
            }
        }
        return false;
    }

    private void requireActive(int portId, String message) throws SQLException {
        Port port = portDAO.findById(portId);
        if (port == null || port.getStatus() != Port.Status.ACTIVE) {
            throw new IllegalStateException(message);
        }
    }

    private Partnership requireParty(int actingPortId, int partnershipId) throws SQLException {
        Partnership p = partnershipDAO.findById(partnershipId);
        if (p == null) {
            throw new IllegalStateException("Partnership not found.");
        }
        if (p.getPortAId() != actingPortId && p.getPortBId() != actingPortId) {
            throw new IllegalStateException("You are not part of this partnership.");
        }
        return p;
    }

    private void requireReceiver(int actingPortId, Partnership p) {
        if (p.getPortBId() != actingPortId) {
            throw new IllegalStateException("Only the port that received the request can respond to it.");
        }
    }
}
