package Service;

import DAO.PermitApplicationDAO;
import DAO.PortDAO;
import DAO.UserDAO;
import Model.PermitApplication;
import Model.PermitInfo;
import Model.Port;
import Model.SystemSettings;
import Model.User;
import Util.DBConnection;
import Util.IdGenerator;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;

public class RegistrationService {

    private static final int MAX_USERNAME_LENGTH = 50;   // users.username is varchar(50)
    private static final int MAX_EMAIL_LENGTH = 150;     // users.email is varchar(150)
    private static final String USERNAME_PATTERN = "^[A-Za-z0-9._-]{4,50}$";

    private final PortDAO portDAO = new PortDAO();
    private final PermitApplicationDAO permitDAO = new PermitApplicationDAO();
    private final UserDAO userDAO = new UserDAO();

    /**
     * RegisterPanel -> "Register". Port + permit application + PORT login are
     * created in ONE transaction: either all three exist or none do. The permit
     * details (registered name, authority, expiration, last renewal) come from
     * the "Fill Up Information" pop-up and are saved on the port so Permit
     * Profile can show them. Throws IllegalStateException with a user-friendly
     * message for validation problems / duplicate email.
     */
    public int registerPort(String companyName, String usernameInput, String emailInput, String password,
            String capability, PermitInfo permitInfo, String documentName, byte[] documentData) throws SQLException {

        if (permitInfo == null) {
            throw new IllegalStateException("Please fill up your permit information.");
        }
        if (permitInfo.getExpirationDate() == null || !permitInfo.getExpirationDate().isAfter(LocalDate.now())) {
            throw new IllegalStateException("The permit expiration date must be in the future.");
        }

        String username = usernameInput == null ? "" : usernameInput.trim();
        String email = emailInput == null ? "" : emailInput.trim().toLowerCase();

        if (!username.matches(USERNAME_PATTERN)) {
            throw new IllegalStateException("Username must be 4-" + MAX_USERNAME_LENGTH
                    + " characters: letters, numbers, dot, dash or underscore (no spaces).");
        }
        if (email.length() > MAX_EMAIL_LENGTH) {
            throw new IllegalStateException("Email must be " + MAX_EMAIL_LENGTH + " characters or fewer.");
        }
        if (userDAO.findByUsername(username) != null) {
            throw new IllegalStateException("That username is already taken.");
        }
        // email must be unique too, including older accounts whose username IS their email
        if (userDAO.findByEmail(email) != null || userDAO.findByUsername(email) != null) {
            throw new IllegalStateException("An account with this email already exists.");
        }

        // new ports start with the network-wide defaults instead of 0
        SystemSettings settings = new SystemSettingsService().get();

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);
            try {
                Port port = new Port();
                port.setPortName(companyName);
                port.setRegisteredName(permitInfo.getRegisteredName());
                port.setPrimaryCapability(capability);
                port.setPermitAuthority(permitInfo.getPermitAuthority());
                port.setExpirationDate(permitInfo.getExpirationDate());
                port.setLastRenewal(permitInfo.getLastRenewal()); // null = first-time permit
                port.setStatus(Port.Status.PENDING);
                port.setSubmittedDate(LocalDate.now());
                if (settings != null) {
                    port.setDispatchLimit(settings.getMaxQueuePerPort());
                    port.setCargoItemLimit(settings.getMaxCargoPerItem());
                }
                int portId = portDAO.insert(conn, port);
                if (portId < 0) {
                    throw new SQLException("Port insert returned no id.");
                }
                portDAO.updatePortCode(conn, portId, IdGenerator.portCode(companyName, portId));

                PermitApplication app = new PermitApplication();
                app.setPortId(portId);
                app.setDateSubmitted(LocalDate.now());
                app.setStatus(PermitApplication.Status.PENDING);
                app.setDocumentName(documentName);
                app.setDocumentData(documentData);
                int permitId = permitDAO.insert(conn, app);
                if (permitId < 0) {
                    throw new SQLException("Permit insert returned no id.");
                }
                String permitNo = IdGenerator.permitNo(permitId);
                permitDAO.updatePermitNo(conn, permitId, permitNo);
                portDAO.updatePermitNo(conn, portId, permitNo); // keep ports.permit_no in sync

                User user = new User();
                user.setUsername(username);      // was: the email
                user.setPasswordHash(password);  // TODO BCrypt before production
                user.setFullName(companyName);
                user.setEmail(email);            // was: username

                user.setRole(User.Role.PORT);
                user.setPortId(portId);
                userDAO.insert(conn, user);

                conn.commit();
                return portId;
            } catch (SQLException | RuntimeException ex) {
                conn.rollback();
                // 1062 = duplicate key: two people registering the same email at once
                if (ex instanceof SQLException && ((SQLException) ex).getErrorCode() == 1062) {
                    throw new IllegalStateException("That username or email is already taken.");
                }
                throw ex;
            }
        }
    }
}
