package Util;

import Model.Cargo;

import java.time.Year;

public final class IdGenerator {

    private IdGenerator() {
    }

    /** e.g. "Davao City Port", id 2 -> "LSP-DCP-00002"; "Manila Port", id 12 -> "LSP-MAN-00012" */
    public static String portCode(String portName, int portId) {
        return String.format("LSP-%s-%05d", abbreviate(portName), portId);
    }

    /** e.g. OUTBOUND cargo, id 123 -> "LSC-OB-2026-000123" (bill-of-lading style) */
    public static String cargoCode(Cargo.Direction direction, int cargoId) {
        String dir = direction == Cargo.Direction.OUTBOUND ? "OB" : "IB";
        return String.format("LSC-%s-%d-%06d", dir, Year.now().getValue(), cargoId);
    }

    /** e.g. permit application id 45 -> "LSC-PMT-2026-00045" */
    public static String permitNo(int permitApplicationId) {
        return String.format("LSC-PMT-%d-%05d", Year.now().getValue(), permitApplicationId);
    }

    public static String partnershipCode(int partnershipId) {
        return String.format("PTN-%06d", partnershipId);
    }

    public static String vesselRegistryCode(int vesselId) {
        return String.format("LSC-V-%06d", vesselId);
    }

    /**
     * 3+ words -> initials of the first three words ("Davao City Port" -> DCP).
     * 1-2 words -> first three letters of the first word ("Manila Port" -> MAN).
     * Always exactly 3 chars, padded with X.
     */
    private static String abbreviate(String name) {
        if (name == null) {
            return "XXX";
        }
        String cleaned = name.trim().toUpperCase().replaceAll("[^A-Z ]", "").trim();
        if (cleaned.isEmpty()) {
            return "XXX";
        }
        String[] words = cleaned.split("\\s+");
        StringBuilder sb = new StringBuilder();
        if (words.length >= 3) {
            for (int i = 0; i < 3; i++) {
                sb.append(words[i].charAt(0));
            }
        } else {
            sb.append(words[0]);
        }
        while (sb.length() < 3) {
            sb.append('X');
        }
        return sb.substring(0, 3);
    }
}