package Model;

public class CargoProduct {

    private int id;
    private int cargoId;
    private String productName;
    private double quantity;
    private String unit;

    public CargoProduct() {
    }

    public CargoProduct(String productName, double quantity, String unit) {
        this.productName = productName;
        this.quantity = quantity;
        this.unit = unit;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getCargoId() { return cargoId; }
    public void setCargoId(int cargoId) { this.cargoId = cargoId; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public double getQuantity() { return quantity; }
    public void setQuantity(double quantity) { this.quantity = quantity; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }
}
