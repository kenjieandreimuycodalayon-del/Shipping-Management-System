package DAO;

import Model.CargoProduct;
import Util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CargoProductDAO {

    public void insert(int cargoId, CargoProduct product) throws SQLException {
        String sql = "INSERT INTO cargo_products (cargo_id, product_name, quantity, unit) VALUES (?,?,?,?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cargoId);
            ps.setString(2, product.getProductName());
            ps.setDouble(3, product.getQuantity());
            ps.setString(4, product.getUnit());
            ps.executeUpdate();
        }
    }

    public void deleteAllForCargo(int cargoId) throws SQLException {
        String sql = "DELETE FROM cargo_products WHERE cargo_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cargoId);
            ps.executeUpdate();
        }
    }

    public int countForCargo(int cargoId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM cargo_products WHERE cargo_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cargoId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    public List<CargoProduct> findByCargoId(int cargoId) throws SQLException {
        String sql = "SELECT * FROM cargo_products WHERE cargo_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, cargoId);
            try (ResultSet rs = ps.executeQuery()) {
                List<CargoProduct> results = new ArrayList<>();
                while (rs.next()) {
                    CargoProduct cp = new CargoProduct();
                    cp.setId(rs.getInt("id"));
                    cp.setCargoId(rs.getInt("cargo_id"));
                    cp.setProductName(rs.getString("product_name"));
                    cp.setQuantity(rs.getDouble("quantity"));
                    cp.setUnit(rs.getString("unit"));
                    results.add(cp);
                }
                return results;
            }
        }
    }
}
