package Presentation;

import Model.Port;
import Service.PortService;
import UI.DialogKit;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.sql.SQLException;

/**
 * Backs PortManagement -> "Add Port". Registers the port and its first permit
 * application, then shows the generated port code and permit number (both real
 * DB values, not display fiction) before closing.
 */
public class AddPortDialog extends JDialog {

    private final JTextField portNameField = new JTextField();
    private final JTextField registeredNameField = new JTextField();
    private final JComboBox<String> capabilityBox = new JComboBox<>(new String[]{
        "Select capability...",
        "Container Handling",
        "Bulk Cargo",
        "Liquid Bulk / Tankers",
        "General Cargo",
        "Roll-on/Roll-off (RoRo)",
        "Refrigerated Cargo",
        "Passenger / Ferry"
    });
    private final JTextField dispatchLimitField = new JTextField();
    private final JTextField cargoLimitField = new JTextField();

    private final PortService portService = new PortService();
    private boolean succeeded = false;

    public AddPortDialog(Frame owner) {
        super(owner, "Add Port", true);
        buildUI();
        DialogKit.finish(this, owner, 540);
    }

    private void buildUI() {
        JPanel header = DialogKit.header("Register a New Port",
                "A permit application is created automatically.", null);

        dispatchLimitField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Whole number");
        cargoLimitField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "Whole number");

        JPanel form = DialogKit.form();
        DialogKit.addField(form, 0, 0, 2, "Port Name *", portNameField);
        DialogKit.addField(form, 1, 0, 2, "Registered Name", registeredNameField);
        DialogKit.addField(form, 2, 0, 2, "Primary Capability", capabilityBox);
        DialogKit.addField(form, 3, 0, 1, "Dispatch Limit", dispatchLimitField);
        DialogKit.addField(form, 3, 1, 1, "Cargo Item Limit", cargoLimitField);

        JPanel card = DialogKit.card(null);
        card.add(form, BorderLayout.CENTER);

        JButton submit = DialogKit.primary("Register Port");
        submit.addActionListener(e -> onSubmit());
        JButton cancel = DialogKit.secondary("Cancel");
        cancel.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(card), DialogKit.footer(null, cancel, submit));
        DialogKit.escToClose(this);
        getRootPane().setDefaultButton(submit);
    }

    private void onSubmit() {
        String name = portNameField.getText().trim();
        if (name.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Port Name is required.", "Validation", JOptionPane.WARNING_MESSAGE);
            portNameField.requestFocusInWindow();
            return;
        }
        int dispatchLimit, cargoLimit;
        try {
            dispatchLimit = Integer.parseInt(dispatchLimitField.getText().trim());
            cargoLimit = Integer.parseInt(cargoLimitField.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Dispatch Limit and Cargo Item Limit must be whole numbers.",
                    "Validation", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Port port = new Port();
        port.setPortName(name);
        port.setRegisteredName(registeredNameField.getText().trim());
        port.setPrimaryCapability(capabilityBox.getSelectedIndex() == 0 ? "" : (String) capabilityBox.getSelectedItem());
        port.setDispatchLimit(dispatchLimit);
        port.setCargoItemLimit(cargoLimit);

        try {
            portService.registerPort(port);
            succeeded = true;
            JOptionPane.showMessageDialog(this,
                    "Port registered.\n\nPort Code: " + port.getPortCode()
                    + "\nPermit No: " + port.getPermitNo()
                    + "\n\nStatus is PENDING until the permit is approved in Pending Approvals.",
                    "Success", JOptionPane.INFORMATION_MESSAGE);
            dispose();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public boolean isSucceeded() {
        return succeeded;
    }
}
