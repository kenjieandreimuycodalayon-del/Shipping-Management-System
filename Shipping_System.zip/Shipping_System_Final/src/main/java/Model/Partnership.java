package Model;

import java.time.LocalDate;

public class Partnership {

    // EXPIRED exists in the DB enum; without it Status.valueOf() would throw on such rows
    public enum Status {
        PENDING, ACTIVE, REJECTED, TERMINATED, EXPIRED
    }

    private int id;
    private int portAId;   // the port that SENT the request
    private int portBId;   // the port that RECEIVED the request
    private String requestType;
    private Status status;
    private LocalDate connectedSince;

    public Partnership() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPortAId() {
        return portAId;
    }

    public void setPortAId(int portAId) {
        this.portAId = portAId;
    }

    public int getPortBId() {
        return portBId;
    }

    public void setPortBId(int portBId) {
        this.portBId = portBId;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public LocalDate getConnectedSince() {
        return connectedSince;
    }

    public void setConnectedSince(LocalDate connectedSince) {
        this.connectedSince = connectedSince;
    }
}
