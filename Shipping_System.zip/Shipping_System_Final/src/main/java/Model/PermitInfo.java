package Model;

import java.time.LocalDate;

/** Permit details a port types in while registering (copied from its permit). */
public class PermitInfo {

    private String registeredName;
    private String permitAuthority;
    private LocalDate expirationDate;
    private LocalDate lastRenewal; // null on a first-time permit

    public PermitInfo() {
    }

    public String getRegisteredName() { return registeredName; }
    public void setRegisteredName(String registeredName) { this.registeredName = registeredName; }

    public String getPermitAuthority() { return permitAuthority; }
    public void setPermitAuthority(String permitAuthority) { this.permitAuthority = permitAuthority; }

    public LocalDate getExpirationDate() { return expirationDate; }
    public void setExpirationDate(LocalDate expirationDate) { this.expirationDate = expirationDate; }

    public LocalDate getLastRenewal() { return lastRenewal; }
    public void setLastRenewal(LocalDate lastRenewal) { this.lastRenewal = lastRenewal; }
}