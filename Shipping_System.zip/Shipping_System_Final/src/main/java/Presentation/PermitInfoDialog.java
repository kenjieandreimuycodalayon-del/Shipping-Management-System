package Presentation;

import Model.PermitInfo;
import UI.DialogKit;
import UI.TemplateUI;
import com.formdev.flatlaf.FlatClientProperties;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Frame;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

/**
 * Backs RegisterPanel -> "Fill Up Information". It only collects and checks the
 * input; RegisterPanel keeps the result and passes it to RegistrationService.
 * Last Renewal may be blank (first-time permit).
 */
public class PermitInfoDialog extends JDialog {

    private static final int MAX_TEXT_LENGTH = 150; // ports.registered_name / permit_authority are varchar(150)

    private final JTextField registeredNameField = new JTextField(22);
    private final JTextField authorityField = new JTextField(22);
    private final JTextField expirationField = new JTextField(22);
    private final JTextField renewalField = new JTextField(22);

    private PermitInfo permitInfo;
    private boolean confirmed = false;

    /**
     * @param defaultRegisteredName pre-filled when nothing was entered yet
     * @param existing previously entered info (re-opening the dialog), or null
     */
    public PermitInfoDialog(Frame owner, String defaultRegisteredName, PermitInfo existing) {
        super(owner, "Permit Information", true);
        buildUI();
        prefill(defaultRegisteredName, existing);
        DialogKit.finish(this, owner, 560);
    }

    private void buildUI() {
        JPanel header = DialogKit.header("Permit Information",
                "Copy these details exactly as they appear on your permit.", null);

        expirationField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "yyyy-MM-dd");
        renewalField.putClientProperty(FlatClientProperties.PLACEHOLDER_TEXT, "yyyy-MM-dd");

        JPanel form = DialogKit.form();
        DialogKit.addField(form, 0, 0, 2, "Registered Name", registeredNameField);
        DialogKit.addField(form, 1, 0, 2, "Permit Authority", authorityField);
        DialogKit.addField(form, 2, 0, 1, "Expiration Date", expirationField);
        DialogKit.addField(form, 2, 1, 1, "Last Renewal (optional)", renewalField);

        JLabel hint = new JLabel("Leave Last Renewal blank if this is your first permit.");
        hint.setFont(TemplateUI.font(Font.PLAIN, 12));
        hint.setForeground(DialogKit.MUTED);

        JPanel card = DialogKit.card(null);
        card.add(form, BorderLayout.CENTER);
        card.add(hint, BorderLayout.SOUTH);

        JButton submit = DialogKit.primary("Save Information");
        submit.addActionListener(e -> onSubmit());
        JButton cancel = DialogKit.secondary("Cancel");
        cancel.addActionListener(e -> dispose());

        DialogKit.assemble(this, header, DialogKit.body(card), DialogKit.footer(null, cancel, submit));
        DialogKit.escToClose(this);
        getRootPane().setDefaultButton(submit);
    }

    private void prefill(String defaultRegisteredName, PermitInfo existing) {
        if (existing != null) {
            registeredNameField.setText(existing.getRegisteredName());
            authorityField.setText(existing.getPermitAuthority());
            expirationField.setText(existing.getExpirationDate() != null ? existing.getExpirationDate().toString() : "");
            renewalField.setText(existing.getLastRenewal() != null ? existing.getLastRenewal().toString() : "");
        } else {
            registeredNameField.setText(defaultRegisteredName != null ? defaultRegisteredName : "");
        }
    }

    private void warn(String message) {
        JOptionPane.showMessageDialog(this, message, "Validation", JOptionPane.WARNING_MESSAGE);
    }

    private void onSubmit() {
        String registeredName = registeredNameField.getText().trim();
        String authority = authorityField.getText().trim();
        if (registeredName.isEmpty()) {
            warn("Registered Name is required.");
            return;
        }
        if (authority.isEmpty()) {
            warn("Permit Authority is required.");
            return;
        }
        if (registeredName.length() > MAX_TEXT_LENGTH || authority.length() > MAX_TEXT_LENGTH) {
            warn("Registered Name and Permit Authority must be " + MAX_TEXT_LENGTH + " characters or fewer.");
            return;
        }

        LocalDate expiration;
        try {
            expiration = LocalDate.parse(expirationField.getText().trim());
        } catch (DateTimeParseException ex) {
            warn("Expiration Date must be in the format yyyy-MM-dd (e.g. 2027-10-15).");
            return;
        }
        if (!expiration.isAfter(LocalDate.now())) {
            warn("Expiration Date must be in the future. An expired permit cannot be registered.");
            return;
        }

        LocalDate renewal = null;
        String renewalText = renewalField.getText().trim();
        if (!renewalText.isEmpty()) {
            try {
                renewal = LocalDate.parse(renewalText);
            } catch (DateTimeParseException ex) {
                warn("Last Renewal must be in the format yyyy-MM-dd, or left blank for a first-time permit.");
                return;
            }
            if (renewal.isAfter(LocalDate.now())) {
                warn("Last Renewal cannot be in the future.");
                return;
            }
            if (!renewal.isBefore(expiration)) {
                warn("Last Renewal must be earlier than the Expiration Date.");
                return;
            }
        }

        PermitInfo info = new PermitInfo();
        info.setRegisteredName(registeredName);
        info.setPermitAuthority(authority);
        info.setExpirationDate(expiration);
        info.setLastRenewal(renewal);
        permitInfo = info;
        confirmed = true;
        dispose();
    }

    public boolean isConfirmed() {
        return confirmed;
    }

    public PermitInfo getPermitInfo() {
        return permitInfo;
    }
}
